#ifndef TIMER_H
#define TIMER_H

#include <stdio.h>
#include "gd32f30x.h"
#include "leds_app.h"

void timer2_config(uint8_t nvic_irq_pre_priority, uint8_t nvic_irq_sub_priority);

#endif
