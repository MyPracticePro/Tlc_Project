#include "uart.h"

static rcu_periph_enum COM_CLK[COMn] = {TYW_COM0_CLK, TYW_COM1_CLK};
static uint32_t COM_TX_PIN[COMn] = {TYW_COM0_TX_PIN, TYW_COM1_TX_PIN};
static uint32_t COM_RX_PIN[COMn] = {TYW_COM0_RX_PIN, TYW_COM1_RX_PIN};
static uint32_t COM_GPIO_PORT[COMn] = {TYW_COM0_GPIO_PORT, TYW_COM1_GPIO_PORT};
static rcu_periph_enum COM_GPIO_CLK[COMn] = {TYW_COM0_GPIO_CLK, TYW_COM1_GPIO_CLK};
static uint8_t COM_IRQn[COMn] = {TYW_COM0_IRQn, TYW_COM1_IRQn};
uint8_t  USART_RX_BUF[USART_REC_LEN];
uint16_t USART_RX_STA;

/*!
    \brief      configure COM port
    \param[in]  com: COM on the board
      \arg        TYW_COM0: COM0 on the board
      \arg        TYW_COM1: COM1 on the board
    \param[out] none
    \retval     none
*/
void tyw_com_init(uint32_t com, uint8_t nvic_irq_pre_priority, uint8_t nvic_irq_sub_priority)
{
    uint32_t com_id = 0U;
    if(TYW_COM0 == com){
        com_id = 0U;
    }else if(TYW_COM1 == com){
        com_id = 1U;
    }
    
    /* enable GPIO clock */
    rcu_periph_clock_enable(COM_GPIO_CLK[com_id]);

    /* enable USART clock */
    rcu_periph_clock_enable(COM_CLK[com_id]);

    /* connect port to USARTx_Tx */
    gpio_init(COM_GPIO_PORT[com_id], GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, COM_TX_PIN[com_id]);

    /* connect port to USARTx_Rx */
    gpio_init(COM_GPIO_PORT[com_id], GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, COM_RX_PIN[com_id]);

    /* NVIC configure */
    nvic_irq_enable(COM_IRQn[com_id], nvic_irq_pre_priority, nvic_irq_sub_priority);

    /* USART configure */
    usart_deinit(com);
    usart_stop_bit_set(com, USART_STB_1BIT);
    usart_baudrate_set(com, 115200U);
    usart_receive_config(com, USART_RECEIVE_ENABLE);
    usart_transmit_config(com, USART_TRANSMIT_ENABLE);
    usart_enable(com);
}

/*!
    \brief      this function handles USART RBNE interrupt request and TBE interrupt request
    \param[in]  none
    \param[out] none
    \retval     none
*/
void USART0_IRQHandler(void)
{
    uint8_t Res;

    if (RESET != usart_interrupt_flag_get(USART0, USART_INT_FLAG_RBNE)){
        /* receive data */
        Res = usart_data_receive(USART0);

        if ((USART_RX_STA&0x8000) == 0)
        {
            if (USART_RX_STA & 0x4000)
            {
                if (Res != 0x0A)
                    USART_RX_STA = 0;
                else
                    USART_RX_STA |= 0x8000;
            }
            else
            {
                if (Res == 0x0D)
                    USART_RX_STA |= 0x4000;
                else
                {
                    USART_RX_BUF[USART_RX_STA&0X3FFF] = Res;
                    USART_RX_STA++;
                    if (USART_RX_STA > (USART_REC_LEN-1))
                        USART_RX_STA = 0;
                }
            }
        }
    }
}

/* retarget the C library printf function to the USART */
int fputc(int ch, FILE *f)
{
    usart_data_transmit(TYW_COM0, (uint8_t)ch);
    while(RESET == usart_flag_get(TYW_COM0, USART_FLAG_TBE));

    return ch;
}
