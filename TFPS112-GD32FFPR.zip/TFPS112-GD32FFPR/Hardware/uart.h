#ifndef UART_H
#define UART_H

#include <stdio.h>
#include "gd32f30x.h"

#define USART_REC_LEN               300

#define COMn                        2U

#define TYW_COM0                   USART0
#define TYW_COM0_CLK               RCU_USART0
#define TYW_COM0_TX_PIN            GPIO_PIN_9
#define TYW_COM0_RX_PIN            GPIO_PIN_10
#define TYW_COM0_GPIO_PORT         GPIOA
#define TYW_COM0_GPIO_CLK          RCU_GPIOA
#define TYW_COM0_IRQn              USART0_IRQn

#define TYW_COM1                   USART1
#define TYW_COM1_CLK               RCU_USART1
#define TYW_COM1_TX_PIN            GPIO_PIN_2
#define TYW_COM1_RX_PIN            GPIO_PIN_3
#define TYW_COM1_GPIO_PORT         GPIOA
#define TYW_COM1_GPIO_CLK          RCU_GPIOA
#define TYW_COM1_IRQn              USART1_IRQn

extern uint8_t USART_RX_BUF[USART_REC_LEN];
extern uint16_t USART_RX_STA;

void tyw_com_init(uint32_t com, uint8_t nvic_irq_pre_priority, uint8_t nvic_irq_sub_priority);

#endif
