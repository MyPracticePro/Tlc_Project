# TFPS112-GD32FFPR
An application code of TFPS112 sensor based on GD32FFPR.
