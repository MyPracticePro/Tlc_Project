// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : dmac_drv.c
// Version      : V0.1
//NOTE          :MCCʹ����DMAC1���жϣ������ʹ��MCC�������ֻ��ʹ��DMAC1�Ĳ�ѯ��ʽ������DMAC2�����ڸ�����
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "dma.h"
#include "spi.h"
#include "ssi.h"
#include "debug.h"
#include "syscfg.h"



//DMA_CHANNEL_REG *m_dma_channel[4];//global struct variable for for Channel registers
//DMA_CONTROL_REG *m_dma_control;//global struct variable for for DMAC registers
volatile UINT32 dma_isr_flag =0;
volatile UINT32 dma_isr_errflag = 0;
static DMA_LLI g_dma_lli_rx;

/*DMA channel base address*/
DMA_CHANNEL_REG *m_dma_channel[DMAC_CHNUM] = {(DMA_CHANNEL_REG *)(DMA1_BASE_ADDR        ),(DMA_CHANNEL_REG *)(DMA1_BASE_ADDR + 0x58 ),\
													  (DMA_CHANNEL_REG *)(DMA1_BASE_ADDR + 0xB0 ),(DMA_CHANNEL_REG *)(DMA1_BASE_ADDR + 0x108)};//global struct variable for for Channel registers
/*DMA config base address */
DMA_CONTROL_REG *m_dma_control = (DMA_CONTROL_REG*)(DMA1_BASE_ADDR+0x2C0);//global struct variable for for DMAC registers

/*******************************************************************************
* Function Name  : DMA1_IRQHandler
* Description    : dma2�жϴ�������
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void DMA1_IRQHandler(void)
{
	//complet int
	if(m_dma_control->DMA_STATTFR & 0x0f)//dma done
	{
#ifdef SSI_DMA_INT
		SSI_DMA_ISR();
#endif
	}

	if(m_dma_control->DMA_STATERR & 0x0f)//dma error
	{
		dma_isr_errflag = m_dma_control->DMA_STATERR & 0x0f;
		m_dma_control->DMA_CLRERR = dma_isr_errflag;
	}
	
  m_dma_control->DMA_CLRTFR = m_dma_control->DMA_STATTFR;
	m_dma_control->DMA_CLRBLOCK=m_dma_control->DMA_STATBLOCK;
	m_dma_control->DMA_CLRSRC=m_dma_control->DMA_STATSRC;
	m_dma_control->DMA_CLRDST=m_dma_control->DMA_STATDST;
	m_dma_control->DMA_CLRERR=m_dma_control->DMA_STATERR;
}
//#endif														
/*******************************************************************************
* Function Name  : DMA2_IRQHandler
* Description    : dma2�жϴ�������
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/

void DMA2_IRQHandler(void)
{
	//complet int
	if(m_dma_control->DMA_STATTFR & 0x0f)//dma done
	{
#ifdef SSI_DMA_INT
		SSI_DMA_ISR();
#endif
	}

	if(m_dma_control->DMA_STATERR & 0x0f)//dma error
	{
		dma_isr_errflag = m_dma_control->DMA_STATERR & 0x0f;
		m_dma_control->DMA_CLRERR = dma_isr_errflag;
	}
	
  m_dma_control->DMA_CLRTFR = m_dma_control->DMA_STATTFR;
	m_dma_control->DMA_CLRBLOCK=m_dma_control->DMA_STATBLOCK;
	m_dma_control->DMA_CLRSRC=m_dma_control->DMA_STATSRC;
	m_dma_control->DMA_CLRDST=m_dma_control->DMA_STATDST;
	m_dma_control->DMA_CLRERR=m_dma_control->DMA_STATERR;
}


/*******************************************************************************
* Function Name  : DMA_REG_Init
* Description    : DMA�Ĵ�����ʼ��
* Input          : - dmac_base_addr: DMA����ַ
*
* Output         : None
* Return         : None
******************************************************************************/
void DMA_REG_Init(UINT32 dmac_base_addr)
{
	m_dma_control    = (DMA_CONTROL_REG*)(dmac_base_addr+0x2c0);
	m_dma_channel[0] = (DMA_CHANNEL_REG*)(dmac_base_addr);
	m_dma_channel[1] = (DMA_CHANNEL_REG*)(dmac_base_addr+0x58);
	m_dma_channel[2] = (DMA_CHANNEL_REG*)(dmac_base_addr+0xB0);
	m_dma_channel[3] = (DMA_CHANNEL_REG*)(dmac_base_addr+0x108);

	m_dma_control->DMA_CONFIG = 0x01;
}

void DMA_ADC_Tran(UINT8 channel, UINT32 dest,UINT32 length)
{
	m_dma_control->DMA_CONFIG = 1;
	m_dma_channel[channel]->DMA_SADDR = 0x4002004c;
	m_dma_channel[channel]->DMA_DADDR = dest;
	m_dma_channel[channel]->DMA_CTRL = SNOCHG|DIEC|P2M_DMA|DWIDTH_W|SWIDTH_W;
	m_dma_channel[channel]->DMA_CTRL_HIGH = length;
	
	m_dma_channel[channel]->DMA_CFG = 0;
	m_dma_channel[channel]->DMA_CFG_HIGH = 6<<7;
	
	m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(channel);
	m_dma_control->DMA_CHEN = CHANNEL_ENABLE(channel);
}

void DMA_DAC_Tran(UINT8 channel, UINT32 src,UINT32 length)
{
	//m_dma_control->DMA_CONFIG = 1;
	m_dma_channel[channel]->DMA_SADDR = src;
	m_dma_channel[channel]->DMA_DADDR = 0x40021004;
	m_dma_channel[channel]->DMA_CTRL = SIEC|DNOCHG|M2P_DMA|DWIDTH_B|SWIDTH_B|INTEN;
	m_dma_channel[channel]->DMA_CTRL_HIGH = length;
	
	m_dma_channel[channel]->DMA_CFG = 0;
	m_dma_channel[channel]->DMA_CFG_HIGH = DST_PER_DAC;
	
	m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(channel);
	m_dma_control->DMA_CHEN = CHANNEL_WRITE_ENABLE(channel)|CHANNEL_ENABLE(channel);
}
void DMA_dis(UINT8 n)
{
	m_dma_channel[n]->DMA_CFG|=1<<8;
	m_dma_control->DMA_CHEN |=CHANNEL_WRITE_ENABLE(n);
	m_dma_control->DMA_CHEN &=~CHANNEL_ENABLE(n);
	m_dma_channel[n]->DMA_CFG&=~(1<<8);
	m_dma_control->DMA_CONFIG=~1;	
}
void dma_lli_reg_init(UINT8 n,DMA_LLI *dma_lli)
{
	m_dma_control->DMA_CONFIG = 1;
	
	m_dma_channel[n]->DMA_SADDR = dma_lli->src_addr;
	m_dma_channel[n]->DMA_DADDR = dma_lli->dst_addr;
	m_dma_channel[n]->DMA_LLP = (unsigned int)dma_lli;
	m_dma_channel[n]->DMA_CTRL = dma_lli->control0;
	m_dma_channel[n]->DMA_CTRL_HIGH =  dma_lli->len ;
	
	m_dma_channel[n]->DMA_CFG = 0;
	m_dma_channel[n]->DMA_CFG_HIGH = 8<<11;
	
	m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(n);
	m_dma_control->DMA_CHEN =CHANNEL_WRITE_ENABLE(n)|CHANNEL_ENABLE(n);

}

/*******************************************************************************
* Function Name  : dma_m2mtran
* Description    : dma���ͺ���
* Input          : - channel: ͨ����
*				   - width: ���ݿ���
*				   - src �� ��ʼ��ַ
*				   - dest �� Ŀ�ĵ�ַ
*				   - length �� �������ݳ���
*
* Output         : None
* Return         : FALSE - ʧ��
*                  TRUE  - �ɹ�
******************************************************************************/
bool dma_m2mtran(UINT8 channel,UINT8 width,UINT32 src, UINT32 dest,UINT32 length)
{
	UINT32 bitwidth = 0;
	if(width == WIDTH_BYTE)
	{
		bitwidth = DWIDTH_B|SWIDTH_B;
	}
	else if(width == WIDTH_HALFWORD)
	{
		bitwidth = DWIDTH_HW|SWIDTH_HW;
		if(length & 1)
		{
			return FALSE;
		}
		length >>= 1;
	}
	else
	{
		bitwidth = DWIDTH_W|SWIDTH_W;
		if(length & 3)
		{
			return FALSE;
		}
		length >>= 2;
	}
	if(length > 0xFFF)
	{
		return FALSE;
	}
	m_dma_control->DMA_CONFIG = 1;

	m_dma_channel[channel]->DMA_SADDR = src;
	m_dma_channel[channel]->DMA_DADDR = dest;
	m_dma_channel[channel]->DMA_CTRL = DIEC|SIEC|bitwidth|DBSIZE_4|SBSIZE_4;
	m_dma_channel[channel]->DMA_CTRL_HIGH = (length&0x00000FFF) ;  //��󳤶�Ϊ0x0FFF

	//enable dma channel
	m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(channel);
	m_dma_control->DMA_CHEN |= CHANNEL_WRITE_ENABLE(channel)|CHANNEL_ENABLE(channel);

	while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(channel)) != CHANNEL_STAT(channel));

	m_dma_control->DMA_CLRTFR = CHANNEL_STAT(channel);

	m_dma_control->DMA_CHEN = 0;
	m_dma_control->DMA_CONFIG = 0;

	return TRUE;
}

/*******************************************************************************
* Function Name  : dma_channle_stop
* Description    : ֹͣDMAͨ������
* Input          : -n     ��dmaͨ����
*
* Output         : None
* Return         : None
******************************************************************************/
void dma_channle_stop(DMA_CHANNEL n)
{
	/*suspend channel*/
	m_dma_channel[n]->DMA_CFG |= (1<<8);
	/*waite FIFO empty*/
	while(((m_dma_channel[n]->DMA_CFG) & (1 << 9)) == 0);
	/*disable channel*/
	m_dma_control->DMA_CHEN =(( m_dma_control->DMA_CHEN|CHANNEL_WRITE_ENABLE(n))&(~CHANNEL_ENABLE(n)));
	/*clear suspend channel*/
	m_dma_channel[n]->DMA_CFG &= ~(1<<8);
}

/*******************************************************************************
* Function Name  : dma_getLength
* Description    : ��ȡDMA�����������ݳ���
* Input          : -n     ��dmaͨ����
*
* Output         : None
* Return         : ��ǰ�������ݳ���
******************************************************************************/
UINT32  dma_getLength(DMA_CHANNEL n)
{
	UINT32 addr;

	addr = m_dma_channel[n]->DMA_DADDR;

	return (addr - g_dma_lli_rx.dst_addr);
}


static void dma_reg_init(UINT32 dma_base_addr)
{
	UINT8 n = 0;
	UINT32 ch_addr[4] = {0x0000, 0x0058, 0x00b0, 0x0108};

	m_dma_control = (DMA_CONTROL_REG*)(dma_base_addr+0x2c0);

	for(n =0; n<4; n++)
	{
		m_dma_channel[n] = (DMA_CHANNEL_REG*)(dma_base_addr+ch_addr[n]);
	}
}

/*******************************************************************************
* Function Name  : DMA_Init
* Description    : DMA��ʼ��
* Input          : UINT32 dma_base_addr 
*
* Output         : None
* Return         : None
******************************************************************************/
void DMA_Init(UINT32 dma_base_addr)
{
	dma_reg_init(dma_base_addr);
}

