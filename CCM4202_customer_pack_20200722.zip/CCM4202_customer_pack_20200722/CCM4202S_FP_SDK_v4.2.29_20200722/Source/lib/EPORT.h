/*
 * EPORT.h
 *
 *  Created on: 2016��9��22��
 *      
 */

#ifndef EPORT_H_
#define EPORT_H_
#include "CCM_Types.h"
#include "type.h"
#include "memmap.h"


/*Below code added by Jefferson, at 08/21/19 10:31 AM*/
typedef enum
{
	/*EPORT0*/
	EPORT_PIN0 = 0,
	EPORT_PIN1,
	EPORT_PIN2,
	EPORT_PIN3,
	EPORT_PIN4,
	EPORT_PIN5,
	EPORT_PIN6,
	EPORT_PIN7,

	/*EPORT1*/
	EPORT_PIN8,
	EPORT_PIN9,
	EPORT_PIN10,
	EPORT_PIN11,
	EPORT_PIN12,
	EPORT_PIN13,
	EPORT_PIN14,
	EPORT_PIN15,
	
		/*EPORT2*/
	EPORT_PIN16,
	EPORT_PIN17,
	EPORT_PIN18,
	EPORT_PIN19,
	EPORT_PIN20,
	EPORT_PIN21,
	EPORT_PIN22,
	EPORT_PIN23,
	
		/*EPORT3*/
	EPORT_PIN24,
	EPORT_PIN25,
	EPORT_PIN26,
	EPORT_PIN27,
	EPORT_PIN28,
	EPORT_PIN29,
	EPORT_PIN30,
	EPORT_PIN31,
	
		/*EPORT4*/
	EPORT_PIN32,
	EPORT_PIN33,
	EPORT_PIN34,
	EPORT_PIN35,
	EPORT_PIN36,
	EPORT_PIN37,
	EPORT_PIN38,
	EPORT_PIN39,

}EPORT_PINx;

#define IS_EPORT_PINx(PIN) (((PIN) == EPORT_PIN0) || \
		                    ((PIN) == EPORT_PIN1) || \
		                    ((PIN) == EPORT_PIN2) || \
		                    ((PIN) == EPORT_PIN3) || \
		                    ((PIN) == EPORT_PIN4) || \
		                    ((PIN) == EPORT_PIN5) || \
		                    ((PIN) == EPORT_PIN6) || \
												((PIN) == EPORT_PIN7) || \
		                    ((PIN) == EPORT_PIN8) || \
		                    ((PIN) == EPORT_PIN9) || \
		                    ((PIN) == EPORT_PIN10)|| \
		                    ((PIN) == EPORT_PIN11)|| \
		                    ((PIN) == EPORT_PIN12)|| \
												((PIN) == EPORT_PIN13)|| \
		                    ((PIN) == EPORT_PIN14)|| \
		                    ((PIN) == EPORT_PIN15)|| \
												((PIN) == EPORT_PIN16)|| \
		                    ((PIN) == EPORT_PIN17)|| \
		                    ((PIN) == EPORT_PIN18)|| \
		                    ((PIN) == EPORT_PIN19)|| \
		                    ((PIN) == EPORT_PIN20)|| \
												((PIN) == EPORT_PIN21)|| \
		                    ((PIN) == EPORT_PIN22)|| \
		                    ((PIN) == EPORT_PIN23)|| \
												((PIN) == EPORT_PIN24)|| \
		                    ((PIN) == EPORT_PIN25)|| \
		                    ((PIN) == EPORT_PIN26)|| \
		                    ((PIN) == EPORT_PIN27)|| \
		                    ((PIN) == EPORT_PIN28)|| \
												((PIN) == EPORT_PIN29)|| \
		                    ((PIN) == EPORT_PIN30)|| \
		                    ((PIN) == EPORT_PIN31)|| \
												((PIN) == EPORT_PIN32)|| \
		                    ((PIN) == EPORT_PIN33)|| \
		                    ((PIN) == EPORT_PIN34)|| \
		                    ((PIN) == EPORT_PIN35)|| \
		                    ((PIN) == EPORT_PIN36)|| \
												((PIN) == EPORT_PIN37)|| \
		                    ((PIN) == EPORT_PIN38)|| \
		                    ((PIN) == EPORT_PIN39)   )

#define IS_EPORT_INT_MODE(MODE) (((MODE) == LOW_LEVEL_INT) || \
		                             ((MODE) == HIGH_LEVEL_INT) || \
		                             ((MODE) == RISING_EDGE_INT) || \
		                             ((MODE) == FALLING_EDGE_INT) || \
                                 ((MODE) == RISING_FALLING_EDGE_INT))






typedef struct
{
	__IO unsigned short EPPAR;  //0x00
	__IO unsigned char  EPIER;  //0x02
	__IO unsigned char  EPDDR;  //0x03
	__IO unsigned char  EPPDR;  //0x04
	__IO unsigned char  EPDR;   //0x05
	__IO unsigned char  EPPUER; //0x06
	__IO unsigned char  EPFR;   //0x07
	__IO unsigned char  EPODER; //0x08
	__IO unsigned char  EPLPR;  //0x09

}EPORT_TypeDef;

typedef enum
{
    LOW_LEVEL_INT = 0,
    HIGH_LEVEL_INT,
    RISING_EDGE_INT,
    FALLING_EDGE_INT,
    RISING_FALLING_EDGE_INT,

}EPORT_INT_MODE;


#define EPORT_REG_STR   ((EPORT_TypeDef *)(EPORT_BASE_ADDR))
#define EPORT1_REG_STR  ((EPORT_TypeDef *)(EPORT1_BASE_ADDR))
#define EPORT2_REG_STR  ((EPORT_TypeDef *)(EPORT2_BASE_ADDR))
#define EPORT3_REG_STR  ((EPORT_TypeDef *)(EPORT3_BASE_ADDR))
#define EPORT4_REG_STR  ((EPORT_TypeDef *)(EPORT4_BASE_ADDR))



/********************************* End *****************************************/





typedef struct{
	VU16 EPPAR;         //EPORT Pin Assignment Register
	VU8  EPIER;         //EPORT Interrupt Enable Register
	VU8  EPDDR;         //EPORT Data Direction Register
	VU8  EPPDR;         //EPORT Pin Data Register
	VU8  EPDR;          //EPORT Data Register
	VU8  EPPUER;        //EPORT Pin Pull-up enable Register
	VU8  EPFR;          //EPORT Flag Register
	VU8  EPODER;        //EPORT Open Drain Register
	VU8  EPLPR;         //EPORT Level Polarity Register
}EPORT_t;

typedef enum{
	EPORT_HIGH_LEVEL_TRIGGER,
	EPORT_LOW_LEVEL_TRIGGER,
	EPORT_RISING_EDGE_TRIGGER,
	EPORT_FALLING_EDGE_TRIGGER,
	EPORT_BOTH_EDGE_TRIGGER
}EPORT_TriggerMode_t;

typedef struct{
	EPORT_TriggerMode_t TriggerMode;
	U8 DirectionOutput;
	U8 EnablePullup;
	U8 OpenDrain;
}EPORT_ControlConfig_t;

void EPORT_PinControlConfig(EPORT_t *eport, U8 pin, EPORT_ControlConfig_t *config);
void EPORT_EnableInterrupt(EPORT_t *eport, U8 pin);
void EPORT_DisableInterrupt(EPORT_t *eport, U8 pin);
void EPORT_ClearInterrupt(EPORT_t *eport, U8 pin);
U8 EPORT_IsInterrupt(EPORT_t *eport, U8 pin);
U8 EPORT_ReadPort(EPORT_t *eport);
void EPORT_WritePort(EPORT_t *eport, U8 port_level);
U8 EPORT_ReadPin(EPORT_t *eport, U8 pin);
void EPORT_WritePin(EPORT_t *eport, U8 pin, U8 level);
INT8 EPORT_ReadGpioData(EPORT_PINx GpioNo);
INT8 EPORT_ConfigGpio(EPORT_PINx GpioNo, UINT8 GpioDir);
void EPORT_Init(EPORT_PINx PINx,EPORT_INT_MODE IntMode);

#endif /* EPORT_H_ */
