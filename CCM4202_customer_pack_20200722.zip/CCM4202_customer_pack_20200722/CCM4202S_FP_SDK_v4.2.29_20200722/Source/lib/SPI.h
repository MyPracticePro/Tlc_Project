/*
 * SPI.h
 *
 *  Created on: 2016��9��14��
 *      
 */

#ifndef SPI_H_
#define SPI_H_
#include "CCM_Types.h"
#include "type.h"

/* Below some defines added by Jefferson, at 08/21/19 10:24 AM */
#pragma anon_unions
typedef struct
{
	__IO unsigned char SPIBR;//0x00
	__IO unsigned char SPIFR;//0x01
	__IO unsigned char SPICR1;//0x02
	__IO unsigned char SPICR2;//0x03

	__IO unsigned char SPIRXFTOCTR;//0x04
	__IO unsigned char SPITXFTOCTR;//0x05
	__IO unsigned char SPITXFCR;//0x06
	__IO unsigned char SPIRXFCR;//0x07

	__IO unsigned char SPIASCDR;//0x08
	__IO unsigned char SPIBSCDR;//0x09
	__IO unsigned char SPIDDR;//0x0a
	__IO unsigned char SPIPURD;//0x0b

	__IO unsigned char SPITCNTM   ;//0x0c
	__IO unsigned char SPITCNTH   ;//0x0d
	__IO unsigned char SPIPORT   ;//0x0e
	__IO unsigned char SPITCNTL   ;//0x0f

	__IO unsigned char SPIIRSP   ;//0x010
	     unsigned char RESERVED1[1];//0x11
	__IO unsigned char SPIDR   ;//0x12
	__IO unsigned char SPIDRH   ;//0x13

	__IO unsigned char SPIRXFSR ;//0x14
	__IO unsigned char SPITXFSR ;//0x15
	union
	{
		__IO unsigned short SPISRHW;//0x16
		struct
		{
			__IO unsigned char SPISR;//0x16
			__IO unsigned char SPISRH;//0x17
		};
	};

	__IO unsigned char SPIFDCR ;//0x18
	__IO unsigned char SPIICR ;//0x19
	__IO unsigned char SPIDMACR ;//0x1a
	__IO unsigned char SPIDMATHR ;//0x1b

	__IO unsigned char SPIRXFDBGR ;//0x1c
	__IO unsigned char SPITXFDBGR ;//0x1e

}SPI_TypeDef;
#define SPI1_REG_STR		((SPI_TypeDef *)(SPI1_BASE_ADDR))
#define SPI2_REG_STR		((SPI_TypeDef *)(SPI2_BASE_ADDR))
#define SPI3_REG_STR		((SPI_TypeDef *)(SPI3_BASE_ADDR))


/*SPISR macros*/
#define SPISR_TXFTO_MASK	        (0x8000)
#define SPISR_TXFOVF_MASK			(0x4000)
#define SPISR_TXFUDF_MASK			(0x2000)
#define SPISR_TXFSER_MASK	       	(0x1000)
#define SPISR_RXFTO_MASK			(0x0800)
#define SPISR_RXFOVF_MASK			(0x0400)
#define SPISR_RXFUDF_MASK			(0x0200)
#define SPISR_RXFSER_MASK			(0x0100)
#define SPISR_SPIF_MASK				(0x0080)
#define SPISR_FLOST_MASK			(0x0040)
#define SPISR_EOTF_MASK				(0x0020)
#define SPISR_MODF_MASK				(0x0010)
#define SPISR_TXFFULL_MASK			(0x0008)
#define SPISR_TXFEMP_MASK			(0x0004)
#define SPISR_RXFFULL_MASK			(0x0002)
#define SPISR_RXFEMP_MASK			(0x0001)

/*SPIICR macros*/
#define SPIICR_FLOSTIE_MASK			(0x40)
#define SPIICR_MODFIE_MASK			(0x10)


#define SPI_CS_L(x)		    do{x->SPIPORT &= 0xF7;}while(0)
#define SPI_CS_H(x)		    do{x->SPIPORT |= 0x08;}while(0)


/* SPI Init structure definition */
typedef struct
{

  UINT8 SPI_Direction;
  UINT8 SPI_Mode;
  UINT8 SPI_DataSize;
  UINT8 SPI_CPOL;//SPI����ʱ��ʱ���ź�SCLK�ĵ�ƽ��1:����ʱ�ߵ�ƽ; 0:����ʱ�͵�ƽ��
  UINT8 SPI_CPHA;//SPI��SCLK�ڼ������ؿ�ʼ������0:��һ�����ؿ�ʼ; 1:�ڶ������ؿ�ʼ��
  UINT8 SPI_BaudRatePrescaler;//SPI Baud Rate
  UINT8 SPI_FirstBit;//LSB-First Enable Bit
  UINT8 SPI_CRCPolynomial;

}SPI_InitTypeDef;


typedef enum
{
    SPI_MISO = 0,
    SPI_MOSI,
    SPI_SCK,
    SPI_SS
}SPI_PINx;


/* SPI data direction mode */
#define SPI_Direction_2Lines_FullDuplex ((UINT8)0x00)
#define SPI_Direction_1Line_RxOrTx      ((UINT8)0x01)

/* SPI data size */
#define SPI_DataSize_16b             (0x0f)
#define SPI_DataSize_8b              (0x07)

/* SPI Clock Polarity */
#define SPI_CPOL_Low                    ((UINT8)0x00)
#define SPI_CPOL_High                   ((UINT8)0x08)

/* SPI Clock Phase */
#define SPI_CPHA_1Edge                  ((UINT16)0x00)
#define SPI_CPHA_2Edge                  ((UINT16)0x04)

/* SPI BaudRate Prescaler  */
#define SPI_BaudRatePrescaler_2         (0x00)
#define SPI_BaudRatePrescaler_4         (0x01)
#define SPI_BaudRatePrescaler_6         (0x20)
#define SPI_BaudRatePrescaler_8         (0x02)
#define SPI_BaudRatePrescaler_10        (0x40)
#define SPI_BaudRatePrescaler_20        (0x41)
#define SPI_BaudRatePrescaler_40        (0x42)
#define SPI_BaudRatePrescaler_64        (0x05)
#define SPI_BaudRatePrescaler_256       (0x07)

/* SPI MSB/LSB transmission */
#define SPI_FirstBit_MSB                ((UINT8)0x00)
#define SPI_FirstBit_LSB                ((UINT8)0x01)

/* SPI master/slave mode */
#define SPI_Mode_Master                 ((UINT8)0x10)
#define SPI_Mode_Slave                  ((UINT8)0x00)

/*SPITXFCR macros*/
#define SPITXFCR_TXFCLR_MASK        (0x80)
#define SPITXFCR_TXFOVIE_MASK       (0x40)
#define SPITXFCR_TXFUDIE_MASK       (0x20)
#define SPITXFCR_TXFSTHIE_MASK      (0x10)
#define SPITXFCR_TXFSTH_MASK		(0x0f)

/*SPIRXFCR macros*/
#define SPIRXFCR_RXFCLR_MASK        (0x80)
#define SPIRXFCR_RXFOVIE_MASK       (0x40)
#define SPIRXFCR_RXFUDIE_MASK       (0x20)
#define SPIRXFCR_RXFSTHIE_MASK      (0x10)
#define SPIRXFCR_RXFSTH_MASK		(0x0f)

/*SPIFR macros*/
#define SPIFR_CONT_MASK			(0x80)
#define SPIFR_GTE_MASK			(0x40)
#define SPIFR_LBM_MASK			(0x20)
#define SPIFR_FFSEL_MASK		(0x10)
#define SPIFR_FMSZ_MASK			(0x0f)
#define FMSZ4_16(len)			(len-1)

/*Data regiter access mode macros*/
#define SPI_BYTE				(0x01)
#define SPI_HALFWORD			(0x00)

/*SPICR1 marcos*/
#define SPICR1_SPIE_MASK			(0x80)
#define SPICR1_SPE_MASK				(0x40)
#define SPICR1_SWOM_MASK			(0x20)
#define SPICR1_MSTR_MASK			(0x10)
#define SPICR1_CPOL_MASK			(0x08)
#define SPICR1_CPHA_MASK			(0x04)
#define SPICR1_SSOE_MASK			(0x02)
#define SPICR1_LSBFE_MASK			(0x01)
#define SPICR1_CLEAR_MASK           (0x00)

#define SPI_ENABLE                  (0x40)

/*SPIDDR macros*/
#define SPIDDR_SS_MASK				(0x08)
#define SPIDDR_SCK_MASK				(0x04)
#define SPIDDR_MOSI_MASK			(0x02)
#define SPIDDR_MISO_MASK			(0x01)

/*SPIPORT macros*/
#define SPIPORT_SS_MASK				(0x08)
#define SPIPORT_SCK_MASK			(0x04)
#define SPIPORT_MOSI_MASK			(0x02)
#define SPIPORT_MISO_MASK			(0x01)

/****************************** End ************************************/




typedef struct {
    VU8  BR;            //SPI Baud Rate Register
    VU8  FR;            //SPI Frame Register
    VU8  CR1;           //SPI Control Register 1
    VU8  CR2;           //SPI Control Register 2
    VU8  RXFTOCTR;      //SPI RX FIFO Timeout Counter Register
    VU8  TXFTOCTR;      //SPI TX FIFO Timeout Counter Register
    VU8  RXFCR;         //SPI RX FIFO Control Register
    VU8  TXFCR;         //SPI TX FIFO Control Register
    VU8  ASCDR;         //SPI After SCK Delay Register
    VU8  BSCDR;         //SPI Before SCK Delay Register
    VU8  DDR;           //SPI Port Data Direction Register
    VU8  PURD;          //SPI Pullup and Reduced Drive Register
    VU8  TCNT_M;        //SPI Transmit Counter Register Mid
    VU8  TCNT_H;        //SPI Transmit Counter Register High
    VU8  PORT;          //SPI Port Data Register
    VU8  TCNT_L;        //SPI Transmit Counter Register Low
    VU8  IRSP;          //Interrupt Register of SS Pin
    VU8  Reserved_11;
    VU8  DR_L;          //SPI Data Register Low
    VU8  DR_H;          //SPI Data Register High
    VU8  RXFSR;         //SPI RX FIFO Status Register
    VU8  TXFSR;         //SPI TX FIFO Status Register
    VU8  SR_L;          //SPI Status Register Low
    VU8  SR_H;          //SPI Status Register High
    VU8  FDCR;          //SPI FIFO Debug Control Register
    VU8  ICR;           //SPI Interrupt Control Register
    VU8  DMACR;         //SPI DMA Control Register
    VU8  DMATHR;        //SPI DMA Threshold Register
    VU8  RXFDBGR;       //SPI RX FIFO Debug Register
    VU8  Reserved_1D;
    VU8  TXFDBGR;       //SPI TX FIFO Debug Register
}SPI_t;


typedef struct{
    U8 Stop_In_Doze;
    U8 Serial_Pin_Control;
    U8 WireOR_Mode;
    U8 MasterMode;
    U8 CPOL;
    U8 CPHA;
    U8 SSOuput_Enable;
    U8 LSB_First;
    U8 Frame_Bits;
}SPI_ControlConfig_t;

typedef struct{
    U8 CS_Keep_Low;
    U8 GuardTime_Enable;
    U8 GuardTime_PreBits;
    U8 GuardTime_Bits;
    U8 LoopBack_Mode;
    U8 TI_Frame_Format;
}SPI_FrameConfig_t;

typedef struct{
    U8 TX_DMA_Enable;
    U8 TX_DMA_Threshold;
    U8 RX_DMA_Enable;
    U8 RX_DMA_Threshold;
}SPI_DMAConfig_t;

typedef struct{
    U8 HighSpeedMode_Enable;
    U8 PinSwitch_Enable;
    U8 SamplePointDelay;
    U8 Polldown_Enable;
    U8 Pollup_Enable;
}SPI_PinConfig_t;

typedef enum{
    PIN_MISO  = 0,
    PIN_MOSI  = 1,
    PIN_SCK   = 2,
    PIN_SS    = 3,
}SPI_Pin_t;

typedef struct{
    U8 GPIO_Prior_Normal;
    U8 Direction_Output;
}SPI_PinIOConfig_t;

typedef enum{
    SPI_MODE_FAULT,
    SPI_END_OF_TRANS,
    SPI_FRAME_LOST,
}SPI_Interrupt_t;

typedef enum{
    SS_HIGH_LEVEL_TRIGGER   = 0x08,
    SS_LOW_LEVEL_TRIGGER    = 0x00,
    SS_RISING_EDGE_TRIGGER  = 0x01,
    SS_FALLING_EDGE_TRIGGER = 0x02,
    SS_BOTH_EDGE_TRIGGER    = 0x03,
}SPI_SSPinTrigger_t;

typedef struct{
    U8 Timeout_Enable;
    U8 Timeout_Count;
    U8 Service_Threshold;
}SPI_FIFOConfig_t;

typedef enum{
    TIMEOUT_INTERRUPT,
    OVERFLOW_INTERRUPT,
    UNDERFLOW_INTERRUPT,
    THRESHOLD_INTERRUPT,
}SPI_FIFO_Interrupt_t;

typedef struct{
    U8 Before_SCK_Delay_Enable;
    U8 Pre_Before_SCK_Delay_Bits;
    U8 Before_SCK_Delay_Bits;//Before_SCK_Delay = (Pre_Before_SCK_Delay_Bits + 1) * 2 ^ (Before_SCK_Delay_Bits + 1)
    U8 After_SCK_Delay_Enable;
    U8 Pre_After_SCK_Delay_Bits;
    U8 After_SCK_Delay_Bits;//After_SCK_Delay = (Pre_After_SCK_Delay_Bits + 1) * 2 ^ (After_SCK_Delay_Bits + 1)
}SPI_SCKDelayConfig_t;



void SPI_ControlConfig(SPI_t *spi, SPI_ControlConfig_t *config);
void SPI_FrameConfig(SPI_t *spi, SPI_FrameConfig_t *config);
void SPI_SetTransCount(SPI_t *spi, U32 count);
void SPI_DMAConfig(SPI_t *spi, SPI_DMAConfig_t *config);
void SPI_SetBaudrate(SPI_t *spi, U8 sppr, U8 spr);
U16 SPI_ReadData(SPI_t *spi);
void SPI_WriteData(SPI_t *spi, U16 data);
U8 SPI_ReadByte(SPI_t *spi);
void SPI_WriteByte(SPI_t *spi, U8 data);
void SPI_Enable(SPI_t *spi);
void SPI_Disable(SPI_t *spi);

void SPI_PinConfig(SPI_t *spi, SPI_PinConfig_t *config);
void SPI_PinIOConfig(SPI_t *spi, SPI_Pin_t pin, SPI_PinIOConfig_t *config);
void SPI_WritePin(SPI_t *spi, SPI_Pin_t pin, U8 level);
U8 SPI_ReadPin(SPI_t *spi, SPI_Pin_t pin);

void SPI_EnableInterrupt(SPI_t *spi, SPI_Interrupt_t intp);
void SPI_DisableInterrupt(SPI_t *spi, SPI_Interrupt_t intp);
U8 SPI_QueryInterrupt(SPI_t *spi, SPI_Interrupt_t intp);
void SPI_ClearInterrupt(SPI_t *spi, SPI_Interrupt_t intp);
U8 SPI_QuerySPIFinish(SPI_t *spi);

void SPI_SetSSPinTrigger(SPI_t *spi, SPI_SSPinTrigger_t trigger);
void SPI_EnableSSPinInterrupt(SPI_t *spi);
void SPI_DisableSSPinInterrupt(SPI_t *spi);
U8 SPI_QuerySSPinInterrupt(SPI_t *spi);
U8 SPI_ReadSSPinLevel(SPI_t *spi);

U8 SPI_GetTXFIFOPos(SPI_t *spi);
U8 SPI_GetRXFIFOPos(SPI_t *spi);
U8 SPI_GetTXFIFOCount(SPI_t *spi);
U8 SPI_GetRXFIFOCount(SPI_t *spi);
U8 SPI_DebugReadTXFIFO(SPI_t *spi, U8 pos);
U8 SPI_DebugReadRXFIFO(SPI_t *spi, U8 pos);

void SPI_TXFIFOConfig(SPI_t *spi, SPI_FIFOConfig_t *config);
U8 SPI_QueryTXFIFOInterrupt(SPI_t *spi, SPI_FIFO_Interrupt_t intp);
void SPI_EnableTXFIFOInterrupt(SPI_t *spi, SPI_FIFO_Interrupt_t intp);
void SPI_DisableTXFIFOInterrupt(SPI_t *spi, SPI_FIFO_Interrupt_t intp);
void SPI_ResetTXFIFO(SPI_t *spi);
U8 SPI_IsTXFIFO_Full(SPI_t *spi);
U8 SPI_IsTXFIFO_Empty(SPI_t *spi);

void SPI_RXFIFOConfig(SPI_t *spi, SPI_FIFOConfig_t *config);
U8 SPI_QueryRXFIFOInterrupt(SPI_t *spi, SPI_FIFO_Interrupt_t intp);
void SPI_EnableRXFIFOInterrupt(SPI_t *spi, SPI_FIFO_Interrupt_t intp);
void SPI_DisableRXFIFOInterrupt(SPI_t *spi, SPI_FIFO_Interrupt_t intp);
void SPI_ResetRXFIFO(SPI_t *spi);
U8 SPI_IsRXFIFO_Full(SPI_t *spi);
U8 SPI_IsRXFIFO_Empty(SPI_t *spi);

void SPI_SCKDelayConfig(SPI_t *spi, SPI_SCKDelayConfig_t *config);
void SPI_StructInit(UINT8 mode,SPI_InitTypeDef* SPI_InitStruct);
void SPI_Init(SPI_TypeDef* SPIx, SPI_InitTypeDef* SPI_InitStruct);

#endif /* SPI_H_ */
