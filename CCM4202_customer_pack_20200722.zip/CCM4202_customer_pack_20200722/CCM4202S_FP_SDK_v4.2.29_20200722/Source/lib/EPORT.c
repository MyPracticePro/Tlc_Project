/*
 * EPORT.c
 *
 *  Created on: 2016��9��22��
 *      
 */
#include "EPORT.h"
#include "debug.h"

void EPORT_PinControlConfig(EPORT_t *eport, U8 pin, EPORT_ControlConfig_t *config)
{
	U8 shift;

	pin &= 0x7;
	shift = pin << 1;

	switch(config->TriggerMode){
	case EPORT_HIGH_LEVEL_TRIGGER:
		eport->EPPAR = (eport->EPPAR & (~(3 << shift)));
		eport->EPLPR |= (1 << pin);
		break;
	case EPORT_LOW_LEVEL_TRIGGER:
		eport->EPPAR = (eport->EPPAR & (~(3 << shift)));
		eport->EPLPR &= ~(1 << pin);
		break;
	case EPORT_RISING_EDGE_TRIGGER:
		eport->EPPAR = (eport->EPPAR & (~(3 << shift))) | (1 << shift);
		break;
	case EPORT_FALLING_EDGE_TRIGGER:
		eport->EPPAR = (eport->EPPAR & (~(3 << shift))) | (2 << shift);
		break;
	case EPORT_BOTH_EDGE_TRIGGER:
		eport->EPPAR = (eport->EPPAR & (~(3 << shift))) | (3 << shift);
		break;
	}

	if (config->DirectionOutput){
		eport->EPDDR |= (1 << pin);
	}else{
		eport->EPDDR &= ~(1 << pin);
	}

	if (config->EnablePullup){
		eport->EPPUER |= (1 << pin);
	}else{
		eport->EPPUER &= ~(1 << pin);
	}

	if (config->OpenDrain){
		eport->EPODER |= (1 << pin);
	}else{
		eport->EPODER &= ~(1 << pin);
	}
}

void EPORT_EnableInterrupt(EPORT_t *eport, U8 pin)
{
	eport->EPIER |= (1 << (pin & 0x7));
}

void EPORT_DisableInterrupt(EPORT_t *eport, U8 pin)
{
	eport->EPIER &= ~(1 << (pin & 0x7));
}

void EPORT_ClearInterrupt(EPORT_t *eport, U8 pin)
{
	eport->EPFR |= (1 << (pin & 0x7));
}

U8 EPORT_IsInterrupt(EPORT_t *eport, U8 pin)
{
	return ((eport->EPFR >> (pin & 0x7)) & 1);
}

U8 EPORT_ReadPort(EPORT_t *eport)
{
	return eport->EPPDR;
}

void EPORT_WritePort(EPORT_t *eport, U8 port_level)
{
	eport->EPDR = port_level;
}

U8 EPORT_ReadPin(EPORT_t *eport, U8 pin)
{
	return ((eport->EPPDR >> (pin & 0x7)) & 1);
}

void EPORT_WritePin(EPORT_t *eport, U8 pin, U8 level)
{
	if (level){
		eport->EPDR |= (1 << (pin & 0x7));
	}else{
		eport->EPDR &= ~(1 << (pin & 0x7));
	}
}



/* Below code added by Jefferson at 08/21/19 10:30 AM*/

/*******************************************************************************
* Function Name  : EPORT_ReadGpioData
* Description    : ��ȡEPORT_PINx��Ӧ���ŵĵ�ƽ
* Input          : - EPORT_PINx: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*
* Output         : None
* Return         : Bit_SET:�ߵ�ƽ  Bit_RESET���͵�ƽ 
******************************************************************************/
INT8 EPORT_ReadGpioData(EPORT_PINx GpioNo)
{
	INT8  bitstatus = 0x00;

	assert_param(IS_EPORT_PINx(GpioNo));

	if (GpioNo > EPORT_PIN39)
		return -1;
	if((GpioNo >>3) == 0)
	{
		//		EPORTx->EPDDR &= ~(1<<(GpioNo - EPORT_PIN0));//xukai20181209ʵ��Ӧ���У�������Ϊ���ʱ��Ҳ�п��ܶ�ȡ��ƽ״̬���������ﲻ������Ϊ���롣
		bitstatus = EPORT_REG_STR->EPPDR;
		if (bitstatus&(Bit_SET<<(GpioNo - EPORT_PIN0)))
		{
			return Bit_SET;
		}
		else
		{
			return Bit_RESET;
		}

	}
	else if((GpioNo >>3) == 1)
	{
		//EPORT1->EPDDR &= ~(1<<(GpioNo - EPORT_PIN8));//xukai20181209ʵ��Ӧ���У�������Ϊ���ʱ��Ҳ�п��ܶ�ȡ��ƽ״̬���������ﲻ������Ϊ���롣
		bitstatus = EPORT1_REG_STR->EPPDR;
		if (bitstatus&(Bit_SET<<(GpioNo - EPORT_PIN8)))
		{
			return Bit_SET;
		}
		else
		{
			return Bit_RESET;
		}
	}
	else if((GpioNo >>3) == 2)
	{
		//EPORT2->EPDDR &= ~(1<<(GpioNo - EPORT_PIN16));//xukai20181209ʵ��Ӧ���У�������Ϊ���ʱ��Ҳ�п��ܶ�ȡ��ƽ״̬���������ﲻ������Ϊ���롣
		bitstatus = EPORT2_REG_STR->EPPDR;
		if (bitstatus&(Bit_SET<<(GpioNo - EPORT_PIN16)))
		{
			return Bit_SET;
		}
		else
		{
			return Bit_RESET;
		}
	}
	else if((GpioNo >>3) == 3)
	{
		//EPORT3->EPDDR &= ~(1<<(GpioNo - EPORT_PIN24));//xukai20181209ʵ��Ӧ���У�������Ϊ���ʱ��Ҳ�п��ܶ�ȡ��ƽ״̬���������ﲻ������Ϊ���롣
		bitstatus = EPORT3_REG_STR->EPPDR;
		if (bitstatus&(Bit_SET<<(GpioNo - EPORT_PIN24)))
		{
			return Bit_SET;
		}
		else
		{
			return Bit_RESET;
		}
	}
	else
	{
		//EPORT4->EPDDR &= ~(1<<(GpioNo - EPORT_PIN32));//xukai20181209ʵ��Ӧ���У�������Ϊ���ʱ��Ҳ�п��ܶ�ȡ��ƽ״̬���������ﲻ������Ϊ���롣
		bitstatus = EPORT4_REG_STR->EPPDR;
		if (bitstatus&(Bit_SET<<(GpioNo - EPORT_PIN32)))
		{
			return Bit_SET;
		}
		else
		{
			return Bit_RESET;
		}
	}

}



/*******************************************************************************
* Function Name  : EPORT_ConfigGpio
* Description    : EPORT���ó�GPIO��;
* Input          : - EPORT_PINx: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*                  - GpioDir������GPIO����   GPIO_OUTPUT�����  GPIO_INPUT������
*
* Output         : None
* Return         : None
******************************************************************************/
INT8 EPORT_ConfigGpio(EPORT_PINx GpioNo, UINT8 GpioDir)
{
	//UINT32 temp = 0x01;
	assert_param(IS_EPORT_PINx(GpioNo));
	assert_param(IS_GPIO_DIR_BIT(GpioDir));

	if (GpioNo > EPORT_PIN39)
	{
		return -1;
	}
	
	if ((GpioNo >= EPORT_PIN9) && (GpioNo <= EPORT_PIN11))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 0);
	}

	if ((GpioNo >= EPORT_PIN14) && (GpioNo <= EPORT_PIN15))
	{
		*(volatile unsigned int *)(0x4000001c) &= ~(1 << 1);
	}
	
	if ((GpioNo >= EPORT_PIN38) && (GpioNo <= EPORT_PIN39))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 2);
	}
	
	if ((GpioNo >= EPORT_PIN6) && (GpioNo <= EPORT_PIN7))
	{
		*(volatile unsigned int *)(0x4000001c) &= ~(1 << 4);
	}
	
	if ((GpioNo >= EPORT_PIN32) && (GpioNo <= EPORT_PIN37))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 7);
	}

	if ((GpioNo >= EPORT_PIN26) && (GpioNo <= EPORT_PIN31))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 12);
	}
	
	if ((GpioNo >= EPORT_PIN22) && (GpioNo <= EPORT_PIN25))
	{
		*(volatile unsigned int *)(0x40000044) &= ~((uint32_t)0xf << 28);
		*(volatile unsigned int *)(0x4000001c) |= (1 << 13);
	}
	
	if ((GpioNo >= EPORT_PIN18) && (GpioNo <= EPORT_PIN21))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 14);
	}
	
	if ((GpioNo >= EPORT_PIN16) && (GpioNo <= EPORT_PIN17))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 15);
	}
	
	if (GpioDir == GPIO_INPUT)//EPORT_EPDDR
	{
		if((GpioNo >>3) == 0)
		{
			EPORT_REG_STR->EPDDR &= ~(1<<GpioNo- EPORT_PIN0);
		}
		else if((GpioNo >>3) == 1)
		{
			EPORT1_REG_STR->EPDDR &= ~(1<<(GpioNo - EPORT_PIN8));
		}
		else if((GpioNo >>3) == 2)
		{
			EPORT2_REG_STR->EPDDR &= ~(1<<(GpioNo - EPORT_PIN16));
		}
		else if((GpioNo >>3) == 3)
		{
			EPORT3_REG_STR->EPDDR &= ~(1<<(GpioNo - EPORT_PIN24));
		}
		else
		{
			EPORT4_REG_STR->EPDDR &= ~(1<<(GpioNo - EPORT_PIN32));
		}
	}
	else
	{
		if((GpioNo >>3) == 0)
		{
			EPORT_REG_STR->EPDDR |= (1<<GpioNo- EPORT_PIN0);
		}
		else if((GpioNo >>3) == 1)
		{
			EPORT1_REG_STR->EPDDR |= (1<<(GpioNo - EPORT_PIN8));
		}
		else if((GpioNo >>3) == 2)
		{
			EPORT2_REG_STR->EPDDR |= (1<<(GpioNo - EPORT_PIN16));
		}
		else if((GpioNo >>3) == 3)
		{
			EPORT3_REG_STR->EPDDR |= (1<<(GpioNo - EPORT_PIN24));
		}
		else
		{
			EPORT4_REG_STR->EPDDR |= (1<<(GpioNo - EPORT_PIN32));
		}
	}
	return 0;
}



/*******************************************************************************
* Function Name  : EPORT_ITTypeConfig
* Description    : ����EPORT_PINx�ŵ��жϴ�����ʽ����ʹ���ж�
* Input          : - EPORT_PINx: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*                  - IntMode:�жϴ�����ʽ
*                            LOW_LEVEL_INT: �͵�ƽ����
*                            HIGH_LEVEL_INT: �ߵ�ƽ����
*                            RISING_EDGE_INT:�����ش���
*                            FALLING_EDGE_INT:�½��ش���
*                            RISING_FALLING_EDGE_INT:�����ػ��½��ش���
*
* Output         : None
* Return         : None
******************************************************************************/
void EPORT_ITTypeConfig( EPORT_PINx IntNo, EPORT_INT_MODE IntMode)
{
	assert_param(IS_EPORT_PINx(IntNo));
	assert_param(IS_EPORT_INT_MODE(IntMode));

	if (IntNo > EPORT_PIN39)
		return;
	
	if ((IntNo >= EPORT_PIN9) && (IntNo <= EPORT_PIN11))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 0);
	}

	if ((IntNo >= EPORT_PIN14) && (IntNo <= EPORT_PIN15))
	{
		*(volatile unsigned int *)(0x4000001c) &= ~(1 << 1);
	}
	
	if ((IntNo >= EPORT_PIN38) && (IntNo <= EPORT_PIN39))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 2);
	}
	
	if ((IntNo >= EPORT_PIN6) && (IntNo <= EPORT_PIN7))
	{
		*(volatile unsigned int *)(0x4000001c) &= ~(1 << 4);
	}
	
	if ((IntNo >= EPORT_PIN32) && (IntNo <= EPORT_PIN37))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 7);
	}

	if ((IntNo >= EPORT_PIN26) && (IntNo <= EPORT_PIN31))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 12);
	}
	
	if ((IntNo >= EPORT_PIN22) && (IntNo <= EPORT_PIN25))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 13);
	}
	
	if ((IntNo >= EPORT_PIN18) && (IntNo <= EPORT_PIN21))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 14);
	}
	
	if ((IntNo >= EPORT_PIN16) && (IntNo <= EPORT_PIN17))
	{
		*(volatile unsigned int *)(0x4000001c) |= (1 << 15);
	}

	if((IntNo >>3) == 0)
	{
		EPORT_REG_STR->EPDDR &= ~(0x01<<(IntNo - EPORT_PIN0));		//����
	}
	else if((IntNo >>3) == 1)
	{
		EPORT1_REG_STR->EPDDR &= ~(0x01<<(IntNo - EPORT_PIN8));		//����
	}
	else if((IntNo >>3) == 2)
	{
		EPORT2_REG_STR->EPDDR &= ~(0x01<<(IntNo - EPORT_PIN16));		//����
	}
	else if((IntNo >>3) == 3)
	{
		EPORT3_REG_STR->EPDDR &= ~(0x01<<(IntNo - EPORT_PIN24));		//����
	}
	else
	{
		EPORT4_REG_STR->EPDDR &= ~(0x01<<(IntNo - EPORT_PIN32));		//����
	}

	switch (IntMode)
	{
		case LOW_LEVEL_INT:			//�͵�ƽ����
		{
			if((IntNo >>3) == 0)
			{
				EPORT_REG_STR->EPPAR &= ~(0x0003<<((IntNo-EPORT_PIN0)*2));
			}
			else if((IntNo >>3) == 1)
			{
				EPORT1_REG_STR->EPPAR &= ~(0x0003<<((IntNo-EPORT_PIN8)*2));
			}
			else if((IntNo >>3) == 2)
			{
				EPORT2_REG_STR->EPPAR &= ~(0x0003<<((IntNo-EPORT_PIN16)*2));
			}
			else if((IntNo >>3) == 3)
			{
				EPORT3_REG_STR->EPPAR &= ~(0x0003<<((IntNo-EPORT_PIN24)*2));
			}
			else
			{
				EPORT4_REG_STR->EPPAR &= ~(0x0003<<((IntNo-EPORT_PIN32)*2));
			}
			break;
		}
		case HIGH_LEVEL_INT:			//�ߵ�ƽ����
		{
			if((IntNo >>3) == 0)
			{
				EPORT_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN0)*2));
				EPORT_REG_STR->EPLPR |= (0x01<<(IntNo - EPORT_PIN0));
			}
			else if((IntNo >>3) == 1)
			{
				EPORT1_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN8)*2));
				EPORT1_REG_STR->EPLPR |= (0x01<<(IntNo - EPORT_PIN8));
			}
			else if((IntNo >>3) == 2)
			{
				EPORT2_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN16)*2));
				EPORT2_REG_STR->EPLPR |= (0x01<<(IntNo - EPORT_PIN16));
			}
			else if((IntNo >>3) == 3)
			{
				EPORT3_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN24)*2));
				EPORT3_REG_STR->EPLPR |= (0x01<<(IntNo - EPORT_PIN24));
			}
			else
			{
				EPORT4_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN32)*2));
				EPORT4_REG_STR->EPLPR |= (0x01<<(IntNo - EPORT_PIN32));
			}
			break;
		}
		case RISING_EDGE_INT:			//�����ش���
		{
			if((IntNo >>3) == 0)
			{
				EPORT_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN0)*2));
				EPORT_REG_STR->EPPAR |= (0x0001<<((IntNo - EPORT_PIN0)*2));
			}
			else if((IntNo >>3) == 1)
			{
				EPORT1_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN8)*2));
				EPORT1_REG_STR->EPPAR |= (0x0001<<((IntNo - EPORT_PIN8)*2));
			}
			else if((IntNo >>3) == 2)
			{
				EPORT2_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN16)*2));
				EPORT2_REG_STR->EPPAR |= (0x0001<<((IntNo - EPORT_PIN16)*2));
			}
			else if((IntNo >>3) == 3)
			{
				EPORT3_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN24)*2));
				EPORT3_REG_STR->EPPAR |= (0x0001<<((IntNo - EPORT_PIN24)*2));
			}
			else
			{
				EPORT4_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN32)*2));
				EPORT4_REG_STR->EPPAR |= (0x0001<<((IntNo - EPORT_PIN32)*2));
			}
			break;
		}
		case FALLING_EDGE_INT:			//�½��ش���
		{
			if((IntNo >>3) == 0)
			{
				EPORT_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN0)*2));
				EPORT_REG_STR->EPPAR |= (0x0002<<((IntNo - EPORT_PIN0)*2));
			}
			else if((IntNo >>3) == 1)
			{
				EPORT1_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN8)*2));
				EPORT1_REG_STR->EPPAR |= (0x0002<<((IntNo - EPORT_PIN8)*2));
			}
			else if((IntNo >>3) == 2)
			{
				EPORT2_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN16)*2));
				EPORT2_REG_STR->EPPAR |= (0x0002<<((IntNo - EPORT_PIN16)*2));
			}
			else if((IntNo >>3) == 3)
			{
				EPORT3_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN24)*2));
				EPORT3_REG_STR->EPPAR |= (0x0002<<((IntNo - EPORT_PIN24)*2));
			}
			else
			{
				EPORT4_REG_STR->EPPAR &= ~(0x0003<<((IntNo - EPORT_PIN32)*2));
				EPORT4_REG_STR->EPPAR |= (0x0002<<((IntNo - EPORT_PIN32)*2));
			}
			break;
		}
		case RISING_FALLING_EDGE_INT:			//�����غ��½��ض�����
		{
			if((IntNo >>3) == 0)
			{
				EPORT_REG_STR->EPPAR |= (0x0003<<((IntNo - EPORT_PIN0)*2));
			}
			else if((IntNo >>3) == 1)
			{
				EPORT1_REG_STR->EPPAR |= (0x0003<<((IntNo - EPORT_PIN8)*2));
			}
			else if((IntNo >>3) == 2)
			{
				EPORT2_REG_STR->EPPAR |= (0x0003<<((IntNo - EPORT_PIN16)*2));
			}
			else if((IntNo >>3) == 3)
			{
				EPORT3_REG_STR->EPPAR |= (0x0003<<((IntNo - EPORT_PIN24)*2));
			}
			else
			{
				EPORT4_REG_STR->EPPAR |= (0x0003<<((IntNo - EPORT_PIN32)*2));
			}
			break;
		}
		default:
		{
			break;
		}
	}
	//ʹ���ж�
	if((IntNo >>3) == 0)
	{
		EPORT_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN0));
	}
	else if((IntNo >>3) == 1)
	{
		EPORT1_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN8));
	}
	else if((IntNo >>3) == 1)
	{
		EPORT2_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN16));
	}
	else if((IntNo >>3) == 1)
	{
		EPORT3_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN24));
	}
	else
	{
		EPORT4_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN32));
	}
}



/*******************************************************************************
* Function Name  : EPORT_ITConfig
* Description    : EPORT�ж�ʹ�ܿ���
* Input          : - EPORT_PINx: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*                  - NewState��new state of the specified EPORT interrupts.
*                              This parameter can be: ENABLE or DISABLE.
*
* Output         : None
* Return         : None
******************************************************************************/
void EPORT_ITConfig(EPORT_PINx IntNo, FunctionalState NewState)
{
	assert_param(IS_EPORT_PINx(IntNo));
	assert_param(IS_FUNCTIONAL_STATE(NewState));
	
	if (IntNo > EPORT_PIN39)
		return;
	
	if (NewState != DISABLE)
	{
		if((IntNo >>3) == 0)
		{
			EPORT_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN0));		//ʹ���ж�
		}
		else if((IntNo >>3) == 1)
		{
			EPORT1_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN8));		//ʹ���ж�
		}
		else if((IntNo >>3) == 2)
		{
			EPORT2_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN16));		//ʹ���ж�
		}
		else if((IntNo >>3) == 3)
		{
			EPORT3_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN24));		//ʹ���ж�
		}
		else
		{
			EPORT4_REG_STR->EPIER |= (0x01<<(IntNo - EPORT_PIN32));		//ʹ���ж�
		}
	}
	else
	{
		if((IntNo >>3) == 0)
		{
			EPORT_REG_STR->EPIER &= ~(0x01<<(IntNo - EPORT_PIN0));		//disable�ж�
		}
		else if((IntNo >>3) == 1)
		{
			EPORT1_REG_STR->EPIER &= ~(0x01<<(IntNo - EPORT_PIN8));		//disable�ж�
		}
		else if((IntNo >>3) == 2)
		{
			EPORT2_REG_STR->EPIER &= ~(0x01<<(IntNo - EPORT_PIN16));		//disable�ж�
		}
		else if((IntNo >>3) == 3)
		{
			EPORT3_REG_STR->EPIER &= ~(0x01<<(IntNo - EPORT_PIN24));		//disable�ж�
		}
		else
		{
			EPORT4_REG_STR->EPIER &= ~(0x01<<(IntNo - EPORT_PIN32));		//disable�ж�
		}
	}
}




/*******************************************************************************
* Function Name  : EPORT_Init
* Description    : EPORT��ʼ��
* Input          : -PINx   �ж����ź�
*                  -IntMode �ж�ģʽ
*
* Output         : None
* Return         : None
******************************************************************************/
void EPORT_Init(EPORT_PINx PINx,EPORT_INT_MODE IntMode)
{

	if(((PINx>>3) == 0) ||((PINx>>3) == 2)) //EPORT0 �� EPORT2
	{
		NVIC_Init(3, 3, (EPORT0_0_IRQn) + (PINx&7), 2);
	}
	else
	{
		NVIC_Init(3, 3, (EPORT1_0_IRQn) + (PINx&7), 2);
	}
	
	EPORT_ITTypeConfig(PINx, IntMode);
	EPORT_ITConfig(PINx, ENABLE);
}




