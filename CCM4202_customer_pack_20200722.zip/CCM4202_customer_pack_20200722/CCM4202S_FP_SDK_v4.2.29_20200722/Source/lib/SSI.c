// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : ssi_drv.c
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#include "delay.h"
#include "debug.h"
#include "common.h"
#include "dma.h"
#include "delay.h"
#include "SSI.h"
//#include "syscfg.h"

extern DMA_CONTROL_REG *m_dma_control;
extern DMA_CHANNEL_REG *m_dma_channel[DMAC_CHNUM];

volatile int dma_int =0;

//����SSIģ��
void SSI_Enable(SSI_TypeDef *SSIx)
{
    SSIx->SSI_SSIENR = 0x01;
}

//ֹͣSSIģ��
void SSI_Disable(SSI_TypeDef *SSIx)
{
	while(SSIx->SSI_SR&SR_BUSY){;}
    SSIx->SSI_SSIENR = 0x00;
}

void SSI_Check_Idle(SSI_TypeDef *SSIx)
{
	while((SSIx->SSI_SR & SR_TFE)!=SR_TFE){;}
	while(SSIx->SSI_SR&SR_BUSY){;}
}
	
void SSI_Init(SSI_TypeDef *SSIx, SSI_Config_t ssi_config)
{
	 while(SSIx->SSI_SR&SR_BUSY){;}
	
   SSI_Disable(SSIx);
		 
		 
	 SSIx->SSI_CTRLR1 = 0x00;
	 SSIx->SSI_CTRLR0 =  ssi_config.Frame_Bits 
												| (ssi_config.CPHA << 8) 
												| (ssi_config.CPOL << 9);
	 SSIx->SSI_BAUDR = ssi_config.BaudRate_Pre;
	 SSIx->SSI_TXFTLR = 0x00;
	 SSIx->SSI_RXFTLR = 0x00;
	 SSIx->SSI_SPI_CTRLR0 = ssi_config.Wait_Cycle << 11
													| ssi_config.Ins_Lens << 8;
	 SSIx->SSI_IMR = 0x00;
	 SSIx->SSI_DMATDLR = ssi_config.TX_Data_Level;
	 SSIx->SSI_DMACR = 0x00;	 

	 SSI_Enable(SSIx);
}

void SSI_Standard_Init(SSI_TypeDef *SSIx)
{
//	SSI_Config_t ssi_config = {0, };

////	SPI_Disable(SPI_FLASH_PERIPHERALS);
//	ssi_config.CPOL = 0;
//	ssi_config.CPHA = 0;
//	ssi_config.Frame_Bits = 7;			//8-bit data lens
//	ssi_config.Wait_Cycle = 0x10;		//wait cycle between cmd & data
//	ssi_config.BaudRate_Pre = (U16)SSIx->SSI_BAUDR;
//	ssi_config.Ins_Lens = 0;
//	ssi_config.TX_Data_Level = 4;
//	
//	SSI_Init(SSIx, ssi_config);
		if(SSIx==SSI2)	
	{
			*(volatile unsigned int *)(0x4000001c) |=0x18;;
	}
		while(SSIx->SSI_SR&SR_BUSY){;}

	SSIx->SSI_SSIENR = 0x00;
	SSIx->SSI_CTRLR1 = 0x00;
	SSIx->SSI_CTRLR0 =  0x07;
	SSIx->SSI_BAUDR = 0x06;
	SSIx->SSI_TXFTLR = 0x00;
	SSIx->SSI_RXFTLR = 0x00;
	SSIx->SSI_SPI_CTRLR0 = 0x8000;
	SSIx->SSI_IMR = 0x00;
	SSIx->SSI_SSIENR = 0x01;	
	
}

/*******************************************************************************
* Function Name  : SSI_DMA_ISR
* Description    : SSI �ж���Ӧ����
* Input          : None
* Output         : None
* Return         : None
******************************************************************************/
void SSI_DMA_ISR(void)
{
	if(m_dma_control->DMA_STATTFR&0x01) dma_int=1;
	if(m_dma_control->DMA_STATTFR&0x02) dma_int=2;
	if(m_dma_control->DMA_STATTFR&0x04) dma_int=3;
	if(m_dma_control->DMA_STATTFR&0x08) dma_int=4;
}

/*******************************************************************************
* Function Name  : SSI_EFlash_Set_Read_Para
* Description    : SSI EFlash ���ö�����
* Input          : - SSIx: SSI ����ַ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_Set_Read_Para(SSI_TypeDef *SSIx)
{
	volatile unsigned char temp;

	SSI_Disable(SSIx);
	SSIx->SSI_CTRLR1 = 0x00;
	SSIx->SSI_CTRLR0 = 0x00800407;
	SSIx->SSI_SPI_CTRLR0 = 0x40000202|(6<<11);
	SSIx->SSI_BAUDR =  0x10;
	SSIx->SSI_IMR = 0x00;
	SSI_Enable(SSIx);

	SSIx->SSI_DR=SET_READ_PARA_CMD;
	SSIx->SSI_DR=0x21; //0x21;

	__asm("nop");
	__asm("nop");
	__asm("nop");
		
//	while((SSIx->SSI_SR&SR_BUSY)==0x00){;}
	while((SSIx->SSI_SR&SR_TFE)!=SR_TFE){;}

	while(SSIx->SSI_SR&SR_BUSY){;}

	while(SSIx->SSI_SR&SR_RFNE)
	{
		temp=SSIx->SSI_DR;
	}		
}	

/*******************************************************************************
* Function Name  : Read_ID_Test
* Description    : ��ȡSSI Flash ID  
* Input          : - SSIx: SSI ����ַ
* Output         : None
* Return         : None
******************************************************************************/
unsigned short Read_ID_Test(SSI_TypeDef *SSIx)
{
	int i;
	volatile unsigned short ID;

	SSIx->SSI_DR=READ_ID_CMD;
	SSIx->SSI_DR=0x00;
	SSIx->SSI_DR=0x00;
	SSIx->SSI_DR=0x00;

	SSIx->SSI_DR=DUMMY_BYTE;
	SSIx->SSI_DR=DUMMY_BYTE;	

	__asm("nop");
	__asm("nop");
	__asm("nop");

	while((SSIx->SSI_SR&SR_TFE)!=SR_TFE){;}
	while(SSIx->SSI_SR&SR_BUSY){;}

	for(i=0; i<4; i++)
	{
		ID=SSIx->SSI_DR;
	}	 

	ID = SSIx->SSI_DR;
	ID |= SSIx->SSI_DR << 8;

//	printf("ID: 0x%04x\r\n", ID);
	
	return ID;
}	
 
/*******************************************************************************
* Function Name  : SSI_EFlash_Read
* Description    : ��SSI Flash ����  
* Input          : - SSIx: SSI ����ַ
*								 ��- addr�����ݵ�ַ
*								 ��- buf �����ݻ���
*								 ��- num �����ݳ���
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_Read(SSI_TypeDef *SSIx, unsigned int addr, unsigned char *buf, int num)
{   
	volatile unsigned char temp;
	int i=0,j=0;
	int dataFlag=0, txnum;

	txnum=num;
	SSIx->SSI_DR = READ_CMD;
	SSIx->SSI_DR = (addr>>16)&0xff;
	SSIx->SSI_DR = (addr>>8)&0xff;
	SSIx->SSI_DR = (addr>>0)&0xff;
	
//	__asm("nop");
//	__asm("nop");
//	__asm("nop");
//	

	while(num>0)
	{
		if( (SSIx->SSI_SR&SR_TFNF)&&(txnum>0) )
		{
			SSIx->SSI_DR=DUMMY_BYTE;
			txnum--;
		}	 
			 
		if(SSIx->SSI_SR&SR_RFNE)
		{
			if( (dataFlag==0)&&(j<4) )
			{
				 temp=SSIx->SSI_DR;
				 j++;
			}	
			else if( (dataFlag==0)&&(j==4) )
			{
				 dataFlag=1;
			}	
			else
			{
				 *(buf+i)=SSIx->SSI_DR;
				 i++;
				 num--;
			}					
		}		 
	 
	}
	while(SSIx->SSI_SR&SR_BUSY){;}
}	

/*******************************************************************************
* Function Name  : SSI_EFlash_Get_Status1
* Description    : ��ȡSSI Flash ״̬1 
* Input          : - SSIx: SSI ����ַ
* Output         : None
* Return         : None
******************************************************************************/
unsigned char SSI_EFlash_Get_Status1(SSI_TypeDef *SSIx)
{ 
	volatile unsigned char retVal;

	SSIx->SSI_DR=GET_SAT1_CMD;
	SSIx->SSI_DR=DUMMY_BYTE;	
	
	__asm("nop");
	__asm("nop");
	__asm("nop");

	while((SSIx->SSI_SR&SR_TFE)!=SR_TFE){;}

	while(SSIx->SSI_SR&SR_BUSY){;}

	while(SSIx->SSI_SR&SR_RFNE)
	{
		retVal=SSIx->SSI_DR;
	}	

	return retVal;
}	

/*******************************************************************************
* Function Name  : SSI_EFlash_Write_Enable
* Description    : SSI Flashдʹ�� 
* Input          : - SSIx: SSI ����ַ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_Write_Enable(SSI_TypeDef *SSIx)
{
	volatile unsigned char status;
	volatile unsigned char temp;
	
	if((SSI_EFlash_Get_Status1(SSIx)&0x02) == 0)
	{
		SSIx->SSI_DR=WRITE_EN_CMD;
	
		__asm("nop");
		__asm("nop");
		__asm("nop");
		
		while((SSIx->SSI_SR&SR_TFE)==0x00){;}
			
		while(SSIx->SSI_SR&SR_BUSY){;}
		
		while(SSIx->SSI_SR&SR_RFNE)
		{
				temp=SSIx->SSI_DR;//���fifo
		}	
		
		do
		{
			status=SSI_EFlash_Get_Status1(SSIx);		 
		}while(status&0x01);
	}
}	


/*******************************************************************************
* Function Name  : SSI_EFlash_Write_Enable
* Description    : SSI Flashдʹ�� 
* Input          : - SSIx: SSI ����ַ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_Write_Disable(SSI_TypeDef *SSIx)
{
	volatile unsigned char status;
	volatile unsigned char temp;
	
	if((SSI_EFlash_Get_Status1(SSIx)&0x02) == 0x02)
	{
		SSIx->SSI_DR=WRITE_DIS_CMD;
	
		__asm("nop");
		__asm("nop");
		__asm("nop");
		
		while((SSIx->SSI_SR&SR_TFE)==0x00){;}
			
		while(SSIx->SSI_SR&SR_BUSY){;}
		
		while(SSIx->SSI_SR&SR_RFNE)
		{
				temp=SSIx->SSI_DR;//���fifo
		}	
		
		do
		{
			status=SSI_EFlash_Get_Status1(SSIx);		 
		}while(status&0x01);
	}
}	

/*******************************************************************************
* Function Name  : SSI_EFlash_Write_Enable
* Description    : ����SSI Flash 
* Input          : - SSIx: SSI ����ַ
* Input          : - addr: ������ַ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_Sector_Erase(SSI_TypeDef *SSIx, unsigned int addr)
{
	volatile unsigned char status;
	volatile unsigned char temp;

	SSIx->SSI_DR=SECT_ERASE_CMD;
	SSIx->SSI_DR=(addr>>16)&0xff;
	SSIx->SSI_DR=(addr>>8)&0xff;
	SSIx->SSI_DR=(addr>>0)&0xff;

	__asm("nop");
	__asm("nop");
	__asm("nop");

	while((SSIx->SSI_SR&SR_TFE)==0x00){;}

	while(SSIx->SSI_SR&SR_BUSY){;}

	while(SSIx->SSI_SR&SR_RFNE)
	{
			temp=SSIx->SSI_DR;//���fifo
	}

	do
	{
	 status=SSI_EFlash_Get_Status1(SSIx);
	 //printf("status: 0x%02x\r\n", status);
	}while(status&0x01);
}


/*******************************************************************************
* Function Name  : SSI_QUAD_Init
* Description    : SSI QUAD ��ʼ��
* Input          : - SSIx      : SSI ����ַ
*								 ��- read      ����д��־
*								 ��- num       ������֡
*								 ��- waitCycles���ȴ�ʱ��
* Output         : None
* Return         : None
******************************************************************************/
void SSI_QUAD_Init(SSI_TypeDef *SSIx, int read, int num, int waitCycles)
{
	 while(SSIx->SSI_SR&SR_BUSY){;}
	
   SSIx->SSI_SSIENR = 0x00;
	 SSIx->SSI_CTRLR1 = num;
	 if(read)
	 {
	    SSIx->SSI_CTRLR0 = 0x00800807;
	 }
   else
   {		 
	    SSIx->SSI_CTRLR0 = 0x00800407;
	 }
	 SSIx->SSI_BAUDR =  0x08;
	 if(read)
	 {
	    SSIx->SSI_TXFTLR = 0x00000000;
	    SSIx->SSI_RXFTLR = 0x7;	 
	 }
   else
   {		 
	    SSIx->SSI_TXFTLR = 0x00000000;
	    SSIx->SSI_RXFTLR = 0x00;
	 }	 
   SSIx->SSI_SPI_CTRLR0 = 0x40000218|(waitCycles<<11);
	 SSIx->SSI_IMR = 0x00;
	 SSIx->SSI_SSIENR = 0x01;
}


/*******************************************************************************
* Function Name  : SSI_DUAL_Init
* Description    : SSI DUAL ��ʼ��
* Input          : - SSIx      : SSI ����ַ
*								 ��- read      ����д��־
*								 ��- num       ������֡
*								 ��- waitCycles���ȴ�ʱ��
* Output         : None
* Return         : None
******************************************************************************/
void SSI_DUAL_Init(SSI_TypeDef *SSIx, int read, int num, int waitCycles)
{
	 while(SSIx->SSI_SR&SR_BUSY){;}
	
   SSIx->SSI_SSIENR = 0x00;
	 SSIx->SSI_CTRLR1 = num;
	 if(read)
	 {
	    SSIx->SSI_CTRLR0 = 0x00400807;
	 }
   else
   {		 
	    SSIx->SSI_CTRLR0 = 0x00400407;
	 }
	 SSIx->SSI_BAUDR =  0x08;
	 if(read)
	 {
	    SSIx->SSI_TXFTLR = 0x00010000;
	    SSIx->SSI_RXFTLR = 0x7;	 
	 }
   else
   {		 
	    SSIx->SSI_TXFTLR = 0x00000000;
	    SSIx->SSI_RXFTLR = 0x00;
	 }	 
   SSIx->SSI_SPI_CTRLR0 = 0x40000218|(waitCycles<<11);
	 SSIx->SSI_IMR = 0x00;
	 SSIx->SSI_SSIENR = 0x01;
}

/*******************************************************************************
* Function Name  : SSI_EFlash_Program
* Description    : SSI Flash д����  
* Input          : - SSIx: SSI ����ַ
*								 ��- addr�����ݵ�ַ
*								 ��- buf �����ݻ���
*								 ��- num �����ݳ���
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_Program(SSI_TypeDef *SSIx, unsigned int addr, unsigned char *buf, int num)
{
	volatile unsigned char temp;
	volatile unsigned char status;
	
	SSIx->SSI_DR=PAGE_PROG_CMD;
	SSIx->SSI_DR=(addr>>16)&0xff;
	SSIx->SSI_DR=(addr>>8)&0xff;
	SSIx->SSI_DR=(addr>>0)&0xff;
	 
#ifdef INTERRUPT_TEST
	 SSIx->SSI_IMR=0x01;
#endif	 

	while(num>0)
	{	
	if(SSIx->SSI_SR&SR_TFNF)
	{
		 SSIx->SSI_DR=*buf;
		 buf++;
		 num--; 
	}	

	if(SSIx->SSI_SR&SR_RFNE)
	{
		 temp=SSIx->SSI_DR;
	}	
	}	


	while(SSIx->SSI_SR&SR_BUSY){;}
	 

	while(SSIx->SSI_SR&SR_RFNE)
	{
		 temp=SSIx->SSI_DR;
	}

	SSI_Check_Idle(SSIx);

	do
	{
	 status=SSI_EFlash_Get_Status1(SSIx);
	}while(status&0x01);
}	

/*******************************************************************************
* Function Name  : SSI_EFlash_Get_Status2
* Description    : ��ȡSSI Flash ״̬2 
* Input          : - SSIx: SSI ����ַ
* Output         : None
* Return         : None
******************************************************************************/
unsigned char SSI_EFlash_Get_Status2(SSI_TypeDef *SSIx)
{ 
	volatile unsigned char retVal;
		
	SSIx->SSI_DR=GET_SAT2_CMD;
	SSIx->SSI_DR=DUMMY_BYTE;
	
	__asm("nop");
	__asm("nop");
	__asm("nop");
		
	while((SSIx->SSI_SR&SR_TFE)!=SR_TFE){;}

	while(SSIx->SSI_SR&SR_BUSY){}
	
	 while(SSIx->SSI_SR&SR_RFNE)
	 {
			retVal=SSIx->SSI_DR;
	 }	
	
	 return retVal;
}	

/*******************************************************************************
* Function Name  : SSI_EFlash_Prog_Status2
* Description    : ����SSI Flash ״̬2 
* Input          : - SSIx: SSI ����ַ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_Prog_Status2(SSI_TypeDef *SSIx, unsigned char val)
{
	volatile unsigned char status;
	volatile unsigned char retVal;

	SSIx->SSI_DR=PROG_STA2_CMD;
	SSIx->SSI_DR=val;

	__asm("nop");
	__asm("nop");
	__asm("nop");

	while((SSIx->SSI_SR&SR_TFE)!=SR_TFE){;}
	while(SSIx->SSI_SR&SR_BUSY){;}

	while(SSIx->SSI_SR&SR_RFNE)
	{
		retVal=SSIx->SSI_DR;
	}	

	do
	{
	 status=SSI_EFlash_Get_Status1(SSIx);		 
	}while(status&1);
}

/*******************************************************************************
* Function Name  : SSI_STD_DMA_Trig
* Description    : ����SSI STD DMA  
* Input          : - SSIx   : SSI ����ַ
*								 ��- cmd    ������ָ��
*								 ��- addr   ����ַ
*								 ��- dmaConf�����䷽ʽ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_STD_DMA_Trig(SSI_TypeDef *SSIx, unsigned cmd, unsigned int addr, int dmaConf)
{
	SSIx->SSI_DMACR = 0;
	
	SSIx->SSI_DR=cmd;
	SSIx->SSI_DR=(addr>>16)&0xff;
	SSIx->SSI_DR=(addr>>8)&0xff;
	SSIx->SSI_DR=(addr>>0)&0xff;

	SSIx->SSI_DMACR=dmaConf;
}


/*******************************************************************************
* Function Name  : SSI_QUAD_DMA_Trig
* Description    : ����SSI QUAD DMA  
* Input          : - SSIx   : SSI ����ַ
*								 ��- cmd    ������ָ��
*								 ��- addr   ����ַ
*								 ��- dmaConf�����䷽ʽ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_QUAD_DMA_Trig(SSI_TypeDef *SSIx, unsigned cmd, unsigned int addr, int dmaConf)
{
	SSIx->SSI_DMACR = 0;
	
	SSIx->SSI_DR=cmd;
	SSIx->SSI_DR=addr;

	SSIx->SSI_DMACR=dmaConf;	 
}	

/*******************************************************************************
* Function Name  : SSI_DUAL_DMA_Trig
* Description    : ����SSI QUAD DMA  
* Input          : - SSIx   : SSI ����ַ
*								 ��- cmd    ������ָ��
*								 ��- addr   ����ַ
*								 ��- dmaConf�����䷽ʽ
* Output         : None
* Return         : None
******************************************************************************/
void SSI_DUAL_DMA_Trig(SSI_TypeDef *SSIx, unsigned cmd, unsigned int addr, int dmaConf)
{
	SSIx->SSI_DMACR = 0;
	
	SSIx->SSI_DR=cmd;
	SSIx->SSI_DR=addr;

	SSIx->SSI_DMACR=dmaConf;	 
}

/*******************************************************************************
* Function Name  : SSI_QUAD_DMA_Read
* Description    : spi dma���պ���
* Input          : - SPIx: SPI ����ַ
*                - dma_ch: DMA channel
*				          - pread: �������ݵ�ַ
*                  - addr: spi flash��ַ
*				        - length �� �������ݳ���
*				        - binten : �Ƿ����ж�ģʽ
*
* Output         : None
* Return         : None
******************************************************************************/
void SSI_QUAD_DMA_Read(SSI_TypeDef *SSIx,int dma_ch, UINT8* pread, UINT32 addr, UINT32 length, BOOL binten)
{
	m_dma_control->DMA_CONFIG = 1;
	//Rx
	m_dma_channel[dma_ch]->DMA_SADDR = (UINT32)&SSIx->SSI_DR;
	m_dma_channel[dma_ch]->DMA_DADDR = (UINT32)pread;
	if(binten == TRUE)
	{
		m_dma_channel[dma_ch]->DMA_CTRL = INTEN|DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
	}
	else
	{
		m_dma_channel[dma_ch]->DMA_CTRL = DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
	}
	m_dma_channel[dma_ch]->DMA_CTRL_HIGH = length ;  //��󳤶�Ϊ0x0FFF
	m_dma_channel[dma_ch]->DMA_CFG = (HS_SEL_SRC_HARD);
	if(SSIx == SSI1)
	{
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = SRC_PER_SPI_RX(2);
	}
	else if(SSIx == SSI2)
	{
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = SRC_PER_SPI_RX(5);
	}
	else
	{
		printf("unknown SSIx\r\n");
		while(1)
		{
			;
		}	
	}
	//enable dma channel
	if(binten == TRUE)
	{	
	   m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(dma_ch);
	}	
	m_dma_control->DMA_CHEN = CHANNEL_WRITE_ENABLE(dma_ch)|CHANNEL_ENABLE(dma_ch);
	//printf("1m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);
	
	SSI_QUAD_DMA_Trig(SSIx, QUAD_READ_CMD, addr, DMACR_RDMAE);
	
	if(binten == TRUE)
	{
			while(1)
			{
				if(dma_int == CHANNEL_STAT(dma_ch) )
				{
					dma_int = 0;
					break;
				}
			}
	}	 
	else
	{
		while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch)) != CHANNEL_STAT(dma_ch));    		
		m_dma_control->DMA_CLRTFR =  m_dma_control->DMA_STATTFR;
	}	 

	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch))
	{
	   ;
	}	
	m_dma_control->DMA_CHEN = 0;
	m_dma_control->DMA_CONFIG = 0;
	
}

/*******************************************************************************
* Function Name  : SSI_DUAL_DMA_Read
* Description    : spi dma���պ���
* Input          : - SPIx: SPI ����ַ
*                - dma_ch: DMA channel
*				          - pread: �������ݵ�ַ
*                  - addr: spi flash��ַ
*				        - length �� �������ݳ���
*				        - binten : �Ƿ����ж�ģʽ
*
* Output         : None
* Return         : None
******************************************************************************/
void SSI_DUAL_DMA_Read(SSI_TypeDef *SSIx,int dma_ch, UINT8* pread, UINT32 addr, UINT32 length, BOOL binten)
{
	u32 mod;
	u32 loop;
	u32 i;
	DMA_LLI dma_lli[8];

	loop = length / 4092;
	mod = length % 4092;

	if(mod != 0)
		loop++;

	for(i = 0; i < loop; i++)
	{
		dma_lli[i].src_addr = (UINT32)&SSIx->SSI_DR;
		dma_lli[i].dst_addr = (U32)(pread + 4092 * i);

		if(i == (loop - 1))
		{
			dma_lli[i].next_lli = 0;
			dma_lli[i].len = mod;
			if(binten == TRUE)
			{
				dma_lli[i].control0 = INTEN|DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
			}
			else
			{
				dma_lli[i].control0 = DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
			}
		}
		else
		{
			dma_lli[i].next_lli = (u32)&dma_lli[i + 1];
			dma_lli[i].len = 4092;
			if(binten == TRUE)
			{
				dma_lli[i].control0 = INTEN|DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B|LLP_SRC_EN|LLP_DST_EN;
			}
			else
			{
				dma_lli[i].control0 = DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B|LLP_SRC_EN|LLP_DST_EN;
			}
		}
	}
	
	m_dma_control->DMA_CONFIG = 1;
	//Rx
	m_dma_channel[dma_ch]->DMA_SADDR = dma_lli[0].src_addr;
	m_dma_channel[dma_ch]->DMA_DADDR = dma_lli[0].dst_addr;
	m_dma_channel[dma_ch]->DMA_LLP = (UINT32)&dma_lli[0];
	m_dma_channel[dma_ch]->DMA_CTRL = dma_lli[0].control0;
	m_dma_channel[dma_ch]->DMA_CTRL_HIGH =  dma_lli[0].len;

	m_dma_channel[dma_ch]->DMA_CFG = (HS_SEL_SRC_HARD);
	if(SSIx == SSI1)
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = SRC_PER_SPI_RX(2);
	else
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = SRC_PER_SPI_RX(5);

	//enable dma channel
	if(binten == TRUE)
	{	
	   m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(dma_ch);
	}	
	m_dma_control->DMA_CHEN = CHANNEL_WRITE_ENABLE(dma_ch)|CHANNEL_ENABLE(dma_ch);
	//printf("1m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);
	
	SSI_QUAD_DMA_Trig(SSIx, DUAL_READ_CMD, addr, DMACR_RDMAE);
	
	if(binten == TRUE)
	{
			while(1)
			{
				if(dma_int == CHANNEL_STAT(dma_ch) )
				{
					dma_int = 0;
					break;
				}
			}
	}	 
	else
	{
		while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch)) != CHANNEL_STAT(dma_ch));    		
		m_dma_control->DMA_CLRTFR =  m_dma_control->DMA_STATTFR;
	}	 

	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch))
	{
	   ;
	}	
	m_dma_control->DMA_CHEN = 0;
	m_dma_control->DMA_CONFIG = 0;
	
	SSIx->SSI_DMACR = 0x00;
}

/*******************************************************************************
* Function Name  : SSI_EFlash_QUAD_Program
* Description    : SSI Flash QUAD ��ʽд����  
* Input          : - SSIx: SSI ����ַ
*								 ��- addr�����ݵ�ַ
*								 ��- buf �����ݻ���
*								 ��- num �����ݳ���
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_QUAD_Program(SSI_TypeDef *SSIx, unsigned int addr, unsigned char *buf, int num)
{
	volatile unsigned char temp;
	volatile unsigned char status;

	SSI_QUAD_Init(SSIx, 0, num-1, 8);

	SSIx->SSI_DR=QUAD_PROG_CMD;
	SSIx->SSI_DR=addr;

	while(num>0)
	{
	 if(SSIx->SSI_SR&SR_TFNF)
	 {
		 SSIx->SSI_DR=*buf;
		 buf++;
		 num--; 
	 }	

	 if(SSIx->SSI_SR&SR_RFNE)
	 {
		 temp=SSIx->SSI_DR;
	 }	
	}	

	while(SSIx->SSI_SR&SR_BUSY){;}

	while(SSIx->SSI_SR&SR_RFNE)
	{
		 temp=SSIx->SSI_DR;
	}	
	
	SSI_Check_Idle(SSIx);

	SSI_Standard_Init(SSIx);
	do
	{
	 status=SSI_EFlash_Get_Status1(SSIx);
	}while(status&0x01);	
}

/*******************************************************************************
* Function Name  : SSI_EFlash_QUAD_Read
* Description    : SSI Flash QUAD ��ʽ������  
* Input          : - SSIx: SSI ����ַ
*								 ��- addr�����ݵ�ַ
*								 ��- buf �����ݻ���
*								 ��- num �����ݳ���
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_QUAD_Read(SSI_TypeDef *SSIx, unsigned int addr, unsigned char *buf, int num)
{
	volatile unsigned char temp;
	volatile unsigned char status;
	int i=0;

	SSI_QUAD_Init(SSIx, 1, num-1, 8);

	SSIx->SSI_DR=QUAD_READ_CMD;
	SSIx->SSI_DR=addr;
	
	__asm("nop");
	__asm("nop");
	__asm("nop");

	while((SSIx->SSI_SR&SR_TFE)!=SR_TFE){;}

	while( ((num>0)&&(SSIx->SSI_SR&SR_BUSY))||(SSIx->SSI_SR&SR_RFNE) )
	{
		if(SSIx->SSI_SR&SR_RFNE)
		{
				*(buf+i)=SSIx->SSI_DR;
				i++;
				num--;
		}	
	}
	
	SSI_Standard_Init(SSIx);
}


/*******************************************************************************
* Function Name  : SSI_EFlash_DUAL_Read
* Description    : SSI Flash DUAL ��ʽ������  
* Input          : - SSIx: SSI ����ַ
*								 ��- addr�����ݵ�ַ
*								 ��- buf �����ݻ���
*								 ��- num �����ݳ���
* Output         : None
* Return         : None
******************************************************************************/
void SSI_EFlash_DUAL_Read(SSI_TypeDef *SSIx, unsigned int addr, unsigned char *buf, int num)
{
	volatile unsigned char temp;
	volatile unsigned char status;
	int i=0;

	SSI_DUAL_Init(SSIx, 1, num-1, 8);

	SSIx->SSI_DR=DUAL_READ_CMD;
	SSIx->SSI_DR=addr;
	
	__asm("nop");
	__asm("nop");
	__asm("nop");

	while((SSIx->SSI_SR&SR_TFE)!=SR_TFE){;}

	while( ((num>0)&&(SSIx->SSI_SR&SR_BUSY))||(SSIx->SSI_SR&SR_RFNE) )
	{
		if(SSIx->SSI_SR&SR_RFNE)
		{
				*(buf+i)=SSIx->SSI_DR;
				i++;
				num--;
		}	
	}

	SSI_Standard_Init(SSIx);
}


/*******************************************************************************
* Function Name  : SSI_QUAD_DMA_Send
* Description    : spi dma���ͺ���
* Input          : - SPIx: SPI ����ַ
*                - dma_ch: DMA channel
*				          - psend: �������ݵ�ַ
*                  _ addr: SPI flash��ַ
*				         - length�� �������ݳ���
*				         - binten: �Ƿ����ж�ģʽ
*
* Output         : None
* Return         : None
******************************************************************************/
void SSI_QUAD_DMA_Send(SSI_TypeDef *SSIx,int dma_ch, UINT8* psend, UINT32 addr, UINT32 length, BOOL binten)
{

		m_dma_control->DMA_CONFIG = 1;
		//Tx
		m_dma_channel[dma_ch]->DMA_SADDR = (UINT32)psend;
		m_dma_channel[dma_ch]->DMA_DADDR = (UINT32)&(SSIx->SSI_DR);

		if(binten == TRUE)
		{
			m_dma_channel[dma_ch]->DMA_CTRL = INTEN|DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B;
			//m_dma_channel[dma_ch]->DMA_CTRL = INTEN|DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B|SBSIZE_4|DBSIZE_4;
		}
		else
		{
			m_dma_channel[dma_ch]->DMA_CTRL = DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B;
		}
		m_dma_channel[dma_ch]->DMA_CTRL_HIGH = length ;  //��󳤶�Ϊ0x0FFF
		m_dma_channel[dma_ch]->DMA_CFG = (HS_SEL_DST_HARD);
		if(SSIx == SSI1)
		{
			m_dma_channel[dma_ch]->DMA_CFG_HIGH = DST_PER_SPI_TX(3);
		}
		else if(SSIx == SSI2)
		{
			m_dma_channel[dma_ch]->DMA_CFG_HIGH = DST_PER_SPI_TX(2);
		}
		else
		{
//			printf("unknown SSIx\r\n");
			while(1)
			{
				;
			}	
		}
		//enable dma channel
		if(binten == TRUE)
		{	
			 m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(dma_ch);
		}	
		
		//SSI_QUAD_DMA_Trig(SSIx, QUAD_PROG_CMD, addr, DMACR_TDMAE);
		
		m_dma_control->DMA_CHEN = (CHANNEL_WRITE_ENABLE(dma_ch)|CHANNEL_ENABLE(dma_ch));
		//printf("1m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);
		
		SSI_QUAD_DMA_Trig(SSIx, QUAD_PROG_CMD, addr, DMACR_TDMAE);
		if(binten == TRUE)
		{
			while(1)
			{
				if(dma_int == CHANNEL_STAT(dma_ch) )
				{
					dma_int = 0;
					break;
				}
			}
		}
		else
		{
			while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch)) != CHANNEL_STAT(dma_ch));
			//printf("2m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);
			
			m_dma_control->DMA_CLRTFR =  m_dma_control->DMA_STATTFR;
			//printf("3m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);

		}

		while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch)){;}
		m_dma_control->DMA_CHEN = 0;
		m_dma_control->DMA_CONFIG = 0;		
}

/*******************************************************************************
* Function Name  : SSI_STD_DMA_Send
* Description    : spi dma���ͺ���
* Input          : - SPIx: SPI ����ַ
*                - dma_ch: DMA channel
*				          - psend: �������ݵ�ַ
*                  _ addr: SPI flash��ַ
*				         - length�� �������ݳ���
*				         - binten: �Ƿ����ж�ģʽ
*
* Output         : None
* Return         : None
******************************************************************************/
#if 0
void SSI_STD_DMA_Send(SSI_TypeDef *SSIx,int dma_ch, UINT8* psend, UINT32 addr, UINT32 length, BOOL binten)
{
	unsigned char temp;

	m_dma_control->DMA_CONFIG = 1;
	//Tx
	m_dma_channel[dma_ch]->DMA_SADDR = (UINT32)psend;
	m_dma_channel[dma_ch]->DMA_DADDR = (UINT32)&SSIx->SSI_DR;
	if(binten == TRUE)
	{
		m_dma_channel[dma_ch]->DMA_CTRL = INTEN|DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B;
	}
	else
	{
		m_dma_channel[dma_ch]->DMA_CTRL = DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B;
	}
	m_dma_channel[dma_ch]->DMA_CTRL_HIGH = length ;  //��󳤶�Ϊ0x0FFF
	m_dma_channel[dma_ch]->DMA_CFG = (HS_SEL_DST_HARD);

	m_dma_channel[dma_ch]->DMA_CFG_HIGH = DST_PER_SPI_TX(3);
	
	//Rx
	m_dma_channel[dma_ch + 1]->DMA_SADDR = (UINT32)&SSIx->SSI_DR;
	m_dma_channel[dma_ch + 1]->DMA_DADDR = (UINT32)&temp;
	if(binten == TRUE)
	{
		m_dma_channel[dma_ch + 1]->DMA_CTRL = INTEN|DNOCHG|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
	}
	else
	{
		m_dma_channel[dma_ch + 1]->DMA_CTRL = DNOCHG|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
	}
	m_dma_channel[dma_ch + 1]->DMA_CTRL_HIGH = length + 4;  //��󳤶�Ϊ0x0FFF
	m_dma_channel[dma_ch + 1]->DMA_CFG = (HS_SEL_DST_HARD);

	m_dma_channel[dma_ch + 1]->DMA_CFG_HIGH = SRC_PER_SPI_RX(2);

	//enable dma channel
	if(binten == TRUE)
	{
	   m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(dma_ch);				//TX
		 m_dma_control->DMA_MASKTFR |= CHANNEL_UMASK(dma_ch + 1);		//RX
	}	
	m_dma_control->DMA_CHEN |= (CHANNEL_WRITE_ENABLE(dma_ch + 1)|CHANNEL_ENABLE(dma_ch + 1));	//RX EN
	SSI_STD_DMA_Trig(SSIx, PAGE_PROG_CMD, addr, DMACR_TDMAE | DMACR_RDMAE);										//SSI1 DMA REQ EN
	m_dma_control->DMA_CHEN = (CHANNEL_WRITE_ENABLE(dma_ch)|CHANNEL_ENABLE(dma_ch));					//TX EN

	if(binten == TRUE)
	{
		while(1)
		{
			if(dma_int == CHANNEL_STAT(dma_ch) )
			{
				dma_int = 0;
				break;
			}
		}
	}
	else
	{
		while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch)) != CHANNEL_STAT(dma_ch));
		while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch + 1)) != CHANNEL_STAT(dma_ch + 1));
	
		m_dma_control->DMA_CLRTFR =  m_dma_control->DMA_STATTFR;
	}

	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch)){;}
	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch + 1)){;}
	m_dma_control->DMA_CHEN = 0;
	m_dma_control->DMA_CONFIG = 0;

	SSIx->SSI_DMACR = 0x00;
}
#endif

void SSI_STD_DMA_Send(SSI_TypeDef *SSIx,int dma_ch, UINT8* psend, UINT32 addr, UINT32 length, BOOL binten)
{
//	unsigned char status;
	

	m_dma_control->DMA_CONFIG = 1;
	//Tx
	m_dma_channel[dma_ch]->DMA_SADDR = (UINT32)psend;
	m_dma_channel[dma_ch]->DMA_DADDR = (UINT32)&SSIx->SSI_DR;
	if(binten == TRUE)
	{
		m_dma_channel[dma_ch]->DMA_CTRL = INTEN|DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B|SBSIZE_4|DBSIZE_4;
	}
	else
	{
		m_dma_channel[dma_ch]->DMA_CTRL = DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B|SBSIZE_4|DBSIZE_4;
	}
	m_dma_channel[dma_ch]->DMA_CTRL_HIGH = length ;  //��󳤶�Ϊ0x0FFF
	m_dma_channel[dma_ch]->DMA_CFG = (HS_SEL_DST_HARD);
	if(SSIx == SSI1)
	{
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = DST_PER_SPI_TX(3);
	}
	else if(SSIx == SSI2)
	{
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = DST_PER_SPI_TX(2);
	}
	else
	{
		printf("unknown SSIx\r\n");
		while(1){;}
	}
	//enable dma channel
	if(binten == TRUE)
	{	
	   m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(dma_ch);
	}	
	m_dma_control->DMA_CHEN = (CHANNEL_WRITE_ENABLE(dma_ch)|CHANNEL_ENABLE(dma_ch));
	//printf("1m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);
	
	SSI_STD_DMA_Trig(SSIx, PAGE_PROG_CMD, addr, DMACR_TDMAE);

	if(binten == TRUE)
	{
		while(1)
		{
			if(dma_int == CHANNEL_STAT(dma_ch) )
			{
				dma_int = 0;
				break;
			}
		}
	}
	else
	{
		//delay(0x1000);
		while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch)) != CHANNEL_STAT(dma_ch));
    //printf("2m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);
		
		m_dma_control->DMA_CLRTFR =  m_dma_control->DMA_STATTFR;
		//printf("3m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);

	}
	
	
	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch)){;}
	m_dma_control->DMA_CHEN = 0;
	m_dma_control->DMA_CONFIG = 0;
	SSIx->SSI_DMACR = 0;

}


/*******************************************************************************
* Function Name  : SSI_STD_DMA_Read
* Description    : spi dma���պ���
* Input          : - SPIx: SPI ����ַ
*                - dma_ch: DMA channel
*				          - pread: �������ݵ�ַ
*                  - addr: spi flash��ַ
*				        - length �� �������ݳ���
*				        - binten : �Ƿ����ж�ģʽ
*
* Output         : None
* Return         : None
******************************************************************************/
#if 0
void SSI_STD_DMA_Read(SSI_TypeDef *SSIx,int dma_ch, UINT8* pread, UINT32 addr, UINT32 length, BOOL binten)
{
	unsigned char temp;
	unsigned char tempr[4] = {0, };
	DMA_LLI dma_lli[8];

	//DMA EN
	m_dma_control->DMA_CONFIG = 1;
	
	//DMA link0
	dma_lli[0].src_addr=(UINT32)&SSIx->SSI_DR;
	dma_lli[0].dst_addr=(UINT32)&tempr;
	dma_lli[0].next_lli=(UINT32)&dma_lli[1];
	if(binten == TRUE)
	{
		dma_lli[0].control0=INTEN|DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B|LLP_SRC_EN|LLP_DST_EN;
	}
	else
	{
		dma_lli[0].control0=DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B|LLP_SRC_EN|LLP_DST_EN;
	}
	dma_lli[0].len=4;
	
	//DMA link1
	dma_lli[1].src_addr=(UINT32)&SSIx->SSI_DR;
	dma_lli[1].dst_addr=(UINT32)pread;
	dma_lli[1].next_lli=0;
	if(binten == TRUE)
	{
		dma_lli[1].control0=INTEN|DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B|LLP_SRC_EN|LLP_DST_EN;
	}
	else
	{
		dma_lli[1].control0=DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B|LLP_SRC_EN|LLP_DST_EN;
	}
	dma_lli[1].len=length;

	//Rx
	m_dma_channel[dma_ch]->DMA_SADDR = dma_lli[0].src_addr;
	m_dma_channel[dma_ch]->DMA_DADDR = dma_lli[0].dst_addr;
	m_dma_channel[dma_ch]->DMA_LLP = (UINT32)&dma_lli[0];
	m_dma_channel[dma_ch]->DMA_CTRL = dma_lli[0].control0;
	m_dma_channel[dma_ch]->DMA_CTRL_HIGH =  dma_lli[0].len;

	m_dma_channel[dma_ch]->DMA_CFG = (HS_SEL_SRC_HARD);
	m_dma_channel[dma_ch]->DMA_CFG_HIGH = SRC_PER_SPI_RX(2);
	
	//Tx
	m_dma_channel[dma_ch + 1]->DMA_SADDR = (UINT32)&temp;
	m_dma_channel[dma_ch + 1]->DMA_DADDR = (UINT32)&SSIx->SSI_DR;
	if(binten == TRUE)
	{
		m_dma_channel[dma_ch + 1]->DMA_CTRL = INTEN|DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B;
	}
	else
	{
		m_dma_channel[dma_ch + 1]->DMA_CTRL = DNOCHG|SIEC|M2P_DMA|DWIDTH_B|SWIDTH_B;
	}
	m_dma_channel[dma_ch + 1]->DMA_CTRL_HIGH = length;  //��󳤶�Ϊ0x0FFF
	m_dma_channel[dma_ch + 1]->DMA_CFG = (HS_SEL_DST_HARD);

	m_dma_channel[dma_ch + 1]->DMA_CFG_HIGH = DST_PER_SPI_TX(3);

	//enable dma interupt. channel
	if(binten == TRUE)
	{	
	   m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(dma_ch);
	   m_dma_control->DMA_MASKTFR |= CHANNEL_UMASK(dma_ch + 1);
	}

	//Rx DMA en
	m_dma_control->DMA_CHEN = (CHANNEL_WRITE_ENABLE(dma_ch)|CHANNEL_ENABLE(dma_ch));

  SSI_STD_DMA_Trig(SSIx, READ_CMD, addr, DMACR_TDMAE | DMACR_RDMAE);

	//Tx DMA en
	m_dma_control->DMA_CHEN |= (CHANNEL_WRITE_ENABLE(dma_ch + 1)|CHANNEL_ENABLE(dma_ch + 1));

	while(SSIx->SSI_SR&SR_BUSY){;}
	 
	if(binten == TRUE)
	{
		while(1)
		{
			if(dma_int == CHANNEL_STAT(dma_ch) )
			{
				dma_int = 0;
				break;
			}
		}
	}
	else
	{
		while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch)) != CHANNEL_STAT(dma_ch));    		
		while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch + 1)) != CHANNEL_STAT(dma_ch + 1));    		
		m_dma_control->DMA_CLRTFR =  m_dma_control->DMA_STATTFR;
	}	 

	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch)){;}
	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch + 1)){;}
	m_dma_control->DMA_CHEN = 0;
	m_dma_control->DMA_CONFIG = 0;

	SSIx->SSI_DMACR = 0x00;
}
#endif

void SSI_STD_DMA_Read(SSI_TypeDef *SSIx,int dma_ch, UINT8* pread, UINT32 addr, UINT32 length, BOOL binten)
{
//	unsigned char status;
	int num2;
	
	m_dma_control->DMA_CONFIG = 1;
	//Rx
	m_dma_channel[dma_ch]->DMA_SADDR = (UINT32)&SSIx->SSI_DR;
	m_dma_channel[dma_ch]->DMA_DADDR = (UINT32)pread;
	if(binten == TRUE)
	{
		m_dma_channel[dma_ch]->DMA_CTRL = INTEN|DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
	}
	else
	{
		m_dma_channel[dma_ch]->DMA_CTRL = DIEC|SNOCHG|P2M_DMA|DWIDTH_B|SWIDTH_B;
	}
	m_dma_channel[dma_ch]->DMA_CTRL_HIGH = length+4 ;  //��󳤶�Ϊ0x0FFF
	m_dma_channel[dma_ch]->DMA_CFG = (HS_SEL_SRC_HARD);
	if(SSIx == SSI1)
	{
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = SRC_PER_SPI_RX(2);
	}
	else if(SSIx == SSI2)
	{
		m_dma_channel[dma_ch]->DMA_CFG_HIGH = SRC_PER_SPI_RX(5);
	}
	else
	{
		printf("unknown SSIx\r\n");
		while(1){;}
	}
	//enable dma channel
	if(binten == TRUE)
	{	
	   m_dma_control->DMA_MASKTFR = CHANNEL_UMASK(dma_ch);
	}	
	m_dma_control->DMA_CHEN = (CHANNEL_WRITE_ENABLE(dma_ch)|CHANNEL_ENABLE(dma_ch));
	//printf("1m_dma_control->DMA_RAWTFR: 0x%08x\r\n", m_dma_control->DMA_RAWTFR);
	

	 num2=length;
   SSI_STD_DMA_Trig(SSIx, READ_CMD, addr, DMACR_RDMAE);

   while(num2)
   {	
	   while( (SSIx->SSI_SR&SR_TFNF)&&(num2>0) )
	   {	
			  SSIx->SSI_DR=DUMMY_BYTE;
			  num2--;	
				while(0);
	   }
   }		 
 	 
	 while(SSIx->SSI_SR&SR_BUSY){;}
	 
	 if(binten == TRUE)
	 {
			while(1)
			{
				if(dma_int == CHANNEL_STAT(dma_ch) )
				{
					dma_int = 0;
					break;
				}
			}			
			
	 }	 
	 else
	 {			
		  while((m_dma_control->DMA_RAWTFR & CHANNEL_STAT(dma_ch)) != CHANNEL_STAT(dma_ch));    		
		  m_dma_control->DMA_CLRTFR =  m_dma_control->DMA_STATTFR;
	 }	 

	while(m_dma_control->DMA_CHEN & CHANNEL_STAT(dma_ch)){;}
	m_dma_control->DMA_CHEN = 0;
	m_dma_control->DMA_CONFIG = 0;
	SSIx->SSI_DMACR = 0;
}


