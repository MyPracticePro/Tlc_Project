#include "Debug.h"
#include <stdio.h>
#include <stdarg.h>
#include<string.h>

volatile USARTypDef	Debug_Tag ;

#define DEBUG_SCI SCI2

void debugInit(U32 baudrate)
{
	SCI_ControlConfig_t cfg;

	cfg.Loop_Mode = 0;
	cfg.WireOR_Mode = 0;
	cfg.Input_Tied_To_TXD = 0;
	cfg.Use_9_DataBit = 0;
	cfg.AddrMark_Wake = 0;
	cfg.Idle_Line_Type = 0;
	cfg.Parity_Enable = 0;
	cfg.Odd_Parity = 0;
	cfg.Send_Break_Frame = 0;
	cfg.Stop_In_Doze = 0;

	SCI_SetBaudrate(&DEBUG_SCI, SYS_CLOCK / 2, baudrate);
	SCI_ControlConfig(&DEBUG_SCI, &cfg);
	SCI_DisableInterrupt(&DEBUG_SCI,
			     SCI_INT_TRANSMIT | SCI_INT_TRANSMIT_COMPLETE |
			     SCI_INT_RECEIVE  | SCI_INT_IDLE_LINE);
	SCI_EnableTransmit(&DEBUG_SCI);
	SCI_EnableReceive(&DEBUG_SCI);
	SCI_EnableInterrupt(&DEBUG_SCI,
			    SCI_INT_RECEIVE);

#if USART_REC_MODE==REC_STOP_MODE
	Debug_Tag .rx_seek = 0;
	Debug_Tag .rx_size = 0;
	Debug_Tag .rx_stat |= RX_BUF_E;
	memset((U8*)&Debug_Tag ,0,sizeof(USARTypDef));
#endif

}

void debugPrint(const char *fmt, ...)
{
	S32 ret, i;
	U8 tmp_buf[512];

	va_list args;
	va_start(args, fmt);
	ret = vsprintf((char *)tmp_buf, fmt, args);
	va_end(args);
	for(i = 0; i < ret; i++){
		while(!SCI_IsTransmitRegEmpty(&DEBUG_SCI));
		SCI_WriteData(&DEBUG_SCI, tmp_buf[i]);
	}
}


U8   debugReadByte(S32 *ch)
{

	U8	res=0;
	//判断是否为“空”
	asm("psrclr ie");
	if(!(Debug_Tag.rx_stat&RX_BUF_E))
	{
		*ch = Debug_Tag.rx_buf[Debug_Tag.rx_seek];
		Debug_Tag.rx_seek++;
		Debug_Tag.rx_seek = Debug_Tag.rx_seek&RX_MASK;
		if(Debug_Tag.rx_size == Debug_Tag.rx_seek)
		{
			Debug_Tag.rx_stat |= RX_BUF_E;
		}
		Debug_Tag.rx_stat &= ~RX_BUF_F;
		res=1;
	}
	else
	{
		*ch=-1;
	}

	asm("psrset ie");
	return res;
}


void debugISR(void)
{
	U8 res;
	if (SCI_IsReceiveRegFull(&DEBUG_SCI))
	{
		res = SCI_ReadData(&DEBUG_SCI);
		asm("psrclr ie");
		if(!(Debug_Tag.rx_stat&RX_BUF_F))
		{
			Debug_Tag.rx_buf[Debug_Tag.rx_size] = res;
			Debug_Tag.rx_size++;
			Debug_Tag.rx_size = Debug_Tag.rx_size&RX_MASK;

			if(Debug_Tag.rx_size == Debug_Tag.rx_seek)
			{
				Debug_Tag.rx_stat |= RX_BUF_F;
			}
			Debug_Tag.rx_stat &= ~RX_BUF_E;
		}
		asm("psrset ie");
	}
}



