#include "Sensor.h"
#include <string.h>

#define MA_DUMMY_BYTE         0xFF
#define MA_READLINE_CMD       0x70
#define MA_READFRAME_CMD      0x78

static  uint8_t  g_sensor_spi = 3;

static SPI_t  *sensor_spi = &SPI2;
static int sensor_spi_edmac = EDMAC_PN_SPI3;

void sensorInit(void)
{
	SPI_FrameConfig_t frame_config;
	SPI_ControlConfig_t control_config;
	SPI_PinIOConfig_t pin_io_config;

	//*((U32* )(0x63f04000+0x002c))|=0x40000000;
	//*((U32* )(0x43f04000+0x002c))|=0x40000000;


    

	switch (g_sensor_spi) {
	case 1:
		sensor_spi = &SPI1;
		sensor_spi_edmac = EDMAC_PN_SPI1;
		break;
	case 2:
		sensor_spi = &SPI2;
		sensor_spi_edmac = EDMAC_PN_SPI2;
		break;
	case 3:
		sensor_spi = &SPI3;
		sensor_spi_edmac = EDMAC_PN_SPI3;
		break;
	}

	SPI_Disable(sensor_spi);

	frame_config.CS_Keep_Low = 0;
	frame_config.GuardTime_Enable = 0;
	frame_config.GuardTime_PreBits = 0;
	frame_config.GuardTime_Bits = 0;
	frame_config.LoopBack_Mode = 0;
	frame_config.TI_Frame_Format = 0;
	SPI_FrameConfig(sensor_spi, &frame_config);

	control_config.Stop_In_Doze = 1;
	control_config.Serial_Pin_Control = 0;
	control_config.WireOR_Mode = 0;
	control_config.MasterMode = 1;
	control_config.CPOL = 0;
	control_config.CPHA = 0;
	control_config.SSOuput_Enable = 0;
	control_config.LSB_First = 0;
	control_config.Frame_Bits = 7;
	SPI_ControlConfig(sensor_spi, &control_config);

	SPI_SetBaudrate(sensor_spi, 0, 3);

	pin_io_config.GPIO_Prior_Normal = 0;
	pin_io_config.Direction_Output = 1;
	SPI_PinIOConfig(sensor_spi, PIN_SS, &pin_io_config);
	SPI_PinIOConfig(sensor_spi, PIN_SCK, &pin_io_config);
	SPI_PinIOConfig(sensor_spi, PIN_MOSI, &pin_io_config);
	pin_io_config.Direction_Output = 0;
	SPI_PinIOConfig(sensor_spi, PIN_MISO, &pin_io_config);
	SPI_WritePin(sensor_spi, PIN_SS, 1);

	SPI_ResetTXFIFO(sensor_spi);
	SPI_ResetRXFIFO(sensor_spi);

	SPI_Enable(sensor_spi);
}


#if ( SPI_EDMA_ENABLE	==	(1) )//spi use edma

void sensorSetMode(U8 mode)
{
#if SPI_SWITCH_ON
	if(Spi_Mode!=SPI_SENSOR_MODE)
	{
		 sensorInit();
		 Spi_Mode=SPI_SENSOR_MODE;
	}
#endif
	U32 out_buf = mode, in_buf = 0;
	EDMAC_ControlConfig_t config;

	config.Transfer_Num = 1;
	config.Compare_Enable = 0;
	config.Compare_Skip = 0;
	config.Preload_Disable = 0;
	config.Transfer_Type = EDMAC_TTYPE_SRAM_PERI_TO_SRAM;
	config.Peripheral_Num = sensor_spi_edmac;
	config.Out_Buff_Inc_Disable = 0;
	config.In_Buff_Inc_Disable  = 0;
	config.Out_Buff = (U8 *)(&out_buf);
	config.In_Buff = (U8 *)(&in_buf);

	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
	SPI_WritePin(sensor_spi, PIN_SS, 0);
	EDMAC_ControlConfig(&EDMA, EDMAC_CHANNEL0, &config);
	EDMAC_Enable(&EDMA, EDMAC_CHANNEL0);
	while(!EDMAC_IsDone(&EDMA, EDMAC_CHANNEL0));
	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
	SPI_WritePin(sensor_spi, PIN_SS, 1);
}

void sensorRWReg(U8 addr, U8 w_data, U8 *old_data, U8 *new_data)
{
#if SPI_SWITCH_ON
	if(Spi_Mode!=SPI_SENSOR_MODE)
	{
		 sensorInit();
		 Spi_Mode=SPI_SENSOR_MODE;
	}
#endif
	U8 out_buf[4], in_buf[4];
	EDMAC_ControlConfig_t config;

	out_buf[0] = addr;
	out_buf[1] = w_data;
	out_buf[2] = MA_DUMMY_BYTE;
	out_buf[3] = MA_DUMMY_BYTE;
	config.Transfer_Num = 4;
	config.Compare_Enable = 0;
	config.Compare_Skip = 0;
	config.Preload_Disable = 0;
	config.Transfer_Type = EDMAC_TTYPE_SRAM_PERI_TO_SRAM;
	config.Peripheral_Num = sensor_spi_edmac;
	config.Out_Buff_Inc_Disable = 0;
	config.In_Buff_Inc_Disable  = 0;
	config.Out_Buff = out_buf;
	config.In_Buff = in_buf;

	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
	SPI_WritePin(sensor_spi, PIN_SS, 0);
	EDMAC_ControlConfig(&EDMA, EDMAC_CHANNEL0, &config);
	EDMAC_Enable(&EDMA, EDMAC_CHANNEL0);
	while(!EDMAC_IsDone(&EDMA, EDMAC_CHANNEL0));
	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
	SPI_WritePin(sensor_spi, PIN_SS, 1);

	if (old_data){
		*old_data = in_buf[2];
	}
	if (new_data){
		*new_data = in_buf[3];
	}
}

void sensorReadLine(U8 *buff, U32 len)
{
#if SPI_SWITCH_ON
	if(Spi_Mode!=SPI_SENSOR_MODE)
	{
		 sensorInit();
		 Spi_Mode=SPI_SENSOR_MODE;
	}
#endif
	U32 dummy = MA_READLINE_CMD | 0xFFFFFF00;
	EDMAC_ControlConfig_t config;

	config.Compare_Enable = 0;
	config.Compare_Skip = 0;
	config.Preload_Disable = 0;
	config.Transfer_Type = EDMAC_TTYPE_SRAM_PERI_TO_SRAM;
	config.Peripheral_Num = sensor_spi_edmac;
	config.Out_Buff_Inc_Disable = 1;
	config.In_Buff_Inc_Disable  = 0;
	config.Out_Buff = (U8 *)(&dummy);
	config.In_Buff = buff;

	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
	SPI_WritePin(sensor_spi, PIN_SS, 0);
	config.Transfer_Num = 2;
	EDMAC_ControlConfig(&EDMA, EDMAC_CHANNEL0, &config);
	EDMAC_Enable(&EDMA, EDMAC_CHANNEL0);
	while(!EDMAC_IsDone(&EDMA, EDMAC_CHANNEL0));
	config.Transfer_Num = len;
	EDMAC_ControlConfig(&EDMA, EDMAC_CHANNEL0, &config);
	while(!EDMAC_IsDone(&EDMA, EDMAC_CHANNEL0));
	SPI_WritePin(sensor_spi, PIN_SS, 1);
	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
}

void sensorReadFrame(U8 *buff, U32 len)
{
#if SPI_SWITCH_ON
	if(Spi_Mode!=SPI_SENSOR_MODE)
	{
		 sensorInit();
		 Spi_Mode=SPI_SENSOR_MODE;
	}
#endif
	U8 dummy = MA_READFRAME_CMD;
	EDMAC_ControlConfig_t config;

	config.Compare_Enable = 0;
	config.Compare_Skip = 0;
	config.Preload_Disable = 0;
	config.Transfer_Type = EDMAC_TTYPE_SRAM_PERI_TO_SRAM;
	config.Peripheral_Num = sensor_spi_edmac;
	config.Out_Buff_Inc_Disable = 1;
	config.In_Buff_Inc_Disable  = 0;
	config.Out_Buff = (U8 *)(&dummy);
	config.In_Buff = buff;

	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
	SPI_WritePin(sensor_spi, PIN_SS, 0);
	config.Transfer_Num = 2;
	EDMAC_ControlConfig(&EDMA, EDMAC_CHANNEL0, &config);
	EDMAC_Enable(&EDMA, EDMAC_CHANNEL0);
	while(!EDMAC_IsDone(&EDMA, EDMAC_CHANNEL0));
	config.Transfer_Num = len;
	EDMAC_ControlConfig(&EDMA, EDMAC_CHANNEL0, &config);
	while(!EDMAC_IsDone(&EDMA, EDMAC_CHANNEL0));
	SPI_WritePin(sensor_spi, PIN_SS, 1);
	EDMAC_Disable(&EDMA, EDMAC_CHANNEL0);
}

#else


inline U8 sensorRWByte(U8 data)
{
	while(!SPI_IsTXFIFO_Empty(sensor_spi));
	SPI_WriteByte(sensor_spi, data);
	while(SPI_IsRXFIFO_Empty(sensor_spi));
	return SPI_ReadByte(sensor_spi);
}


void sensorSetMode(U8 mode)
{
	SPI_WritePin(sensor_spi, PIN_SS, 0);
	Sensor_RWByte(mode);
	SPI_WritePin(sensor_spi, PIN_SS, 1);
}


void sensorRWReg(U8 addr, U8 w_data, U8 *old_data, U8 *new_data)
{
	U8 tmp;

	SPI_WritePin(sensor_spi, PIN_SS, 0);

	while(!SPI_IsTXFIFO_Empty(sensor_spi));
	SPI_WriteByte(sensor_spi, addr);
	SPI_WriteByte(sensor_spi, w_data);
	SPI_WriteByte(sensor_spi, MA_DUMMY_BYTE);
	SPI_WriteByte(sensor_spi, MA_DUMMY_BYTE);

	while(SPI_IsRXFIFO_Empty(sensor_spi));
	tmp = SPI_ReadByte(sensor_spi);

	while(SPI_IsRXFIFO_Empty(sensor_spi));
	tmp = SPI_ReadByte(sensor_spi);

	while(SPI_IsRXFIFO_Empty(sensor_spi));
	tmp = SPI_ReadByte(sensor_spi);
	if (old_data) *old_data = tmp;

	while(SPI_IsRXFIFO_Empty(sensor_spi));
	tmp = SPI_ReadByte(sensor_spi);
	if (new_data) *new_data = tmp;

	SPI_WritePin(sensor_spi, PIN_SS, 1);
}

void sensorReadLine(U8 *buff, U32 len)
{
	SPI_WritePin(sensor_spi, PIN_SS, 0);

	Sensor_RWByte(MA_READLINE_CMD);
	Sensor_RWByte(MA_DUMMY_BYTE);

	while(len--){
		*buff++ = Sensor_RWByte(MA_DUMMY_BYTE);
	}

	SPI_WritePin(sensor_spi, PIN_SS, 1);
}

void sensorReadFrame(U8 *buff, U32 len)
{
	SPI_WritePin(sensor_spi, PIN_SS, 0);

	Sensor_RWByte(MA_READFRAME_CMD);
	Sensor_RWByte(MA_DUMMY_BYTE);

	while(len--){
		while(!SPI_IsTXFIFO_Empty(sensor_spi));
		SPI_WriteByte(sensor_spi, MA_DUMMY_BYTE);
		while(SPI_IsRXFIFO_Empty(sensor_spi));
		*buff++ =  SPI_ReadByte(sensor_spi);
	}

	SPI_WritePin(sensor_spi, PIN_SS, 1);
}

#endif
