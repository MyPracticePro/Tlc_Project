/*
 * ClockAndPower.c
 *
 *  Created on: 2016��9��14��
 *      
 */
#include "ClockAndPower.h"
#include "Cache.h"
#include "clk_switch.h"
#include "CPM.h"
#include "sys.h"
#include "cache.h"

void CPM_SysClkSelect(U32 sys_sel, U32 div);
void CPM_Vref_Trim(unsigned int trim_value);
static void cpm_set_sysclk_div(U32 div);
UINT32 IPS_Clk_Op(UINT32 div_op, UINT32 op_data);
UINT32 Get_Sys_Clock(void);

void clockInit(void)
{
//trim 160M��ʱ��
#if SYS_CLK_TRIM_108M
	CPM_OSC_Switch(OSC_108M_HZ);		
#endif
#if SYS_CLK_TRIM_120M
	CPM_OSC_Switch(OSC_120M_HZ);
#elif SYS_CLK_TRIM_150M
	CPM_OSC_Switch(OSC_150M_HZ);
#elif SYS_CLK_TRIM_160M
	CPM_OSC_Switch(OSC_160M_HZ); //ϵͳʱ��160M����2��Ƶ
#endif
	
	//����ϵͳʱ��
	CPM_SysClkSelect(SYSCLK_OSC160M, 1);
	
	//����IPSʱ�ӵķ�Ƶϵ��������Ϊ0
	IPS_Clk_Op(UPDATA_DIVIDER, 1); 
	
	// get system clock
	g_sys_clk = Get_Sys_Clock();	
	
	//get ips clock
	g_ips_clk = g_sys_clk / (IPS_Clk_Op(GET_NOW_DIVIDER, 0) + 1);	

	CPM.SYSCGTCR = DMAC1_GTE
									| DMAC2_GTE
									| CRC0_GTE
									| CRC1_GTE
									| AHB2_MUX_GTE
									| SRAMD_GTE
									| SRAM0_GTE
									| SRAM1_GTE
									| SRAM2_GTE
									| SRAM3_GTE
									| SSI4_GTE
									| SSI5_GTE
									| ROM_GTE
//									| M2S_BUS_M_GTE
									;
//
	CPM.MULTICGTCR = EFM_BUS_CGT
//										| MCC_CGT
//										| MCCADR_CGT
										| ADC_CGT
										| MESH_CGT
										| TC_CGT
										| CLKOUT_CGT
										| KEY_CTRL_CGT
										| EFM_CGT
										| CPM_CGT
										| EPORT_CGT
										| EPORT1_CGT
										| EPORT2_CGT
										| EPORT3_CGT
										| EPORT4_CGT
//										| TRACE_CGT
										;

	CPM.ARITHCGTCR=0;
	CPM.IPSCGTCR= (uint32_t)(IO_CTRL_GTE
								| WDT_GTE
								| RTC_GTE
								| PIT1_GTE
								| PIT2_GTE
								| USI1_GTE
								| EDMAC1_GTE
								| SPI1_GTE
								| SPI2_GTE
								| SPI3_GTE
								| SCI1_GTE
								| SCI2_GTE
								| USI2_GTE
								| I2C1_GTE
								| PWM0_GTE
								| I2C2_GTE
								| I2C3_GTE
								| SCI3_GTE
								| QADC_GTE
								| DAC_GTE
//								| MCC_GTE
								| TSI_GTE
								| LD_GTE
								| TRNG_GTE
								| PGD_GTE
								| SEC_DET_APB
								| PCI_GTE
								| PMURTC_GTE
								| AHB2IPS_GTE
								| (uint32_t)RIMS_APB);
}


void powerEnterSleep(void)
{
	//��δʵ��
}

#if 0
static void delay(volatile U32 val)
{
	while(val--){
		asm("nop");
	}
}
#endif


void clockSet40M(void)
{

}


void jmp_to_rom(void)
{
	__asm("CPSID I");//disable exception & interrupt
//	cpm_sysclk_select(SYSCLK_OSC400M);//select 400MHz OSC
	 clockSet40M();//sysclk == 40M
#if ( CACHE_ENABLE	==	(1) )
	disableCache();
#endif
	__asm("b 0x100");//jmp to rom
}

/*******************************************************************************
* Function Name  : IPS_Clk_Op
* Description    : IPSģ��ʱ�Ӳ���
*
* Input          : -div_op��
*                      DIVIDER_DISABLE����ֹ��Ƶ
*                      UPDATA_DIVIDER�����·�Ƶϵ��
*                      GET_NOW_DIVIDER����ȡ��ǰ��Ƶϵ��
*                  -op_data:
*                      ��������
* Output         : ��ǰ��Ƶϵ��
* Return         : None
******************************************************************************/
UINT32 IPS_Clk_Op(UINT32 div_op, UINT32 op_data)
{
	UINT32 return_val;
	
	return_val = 0;
	
	if(op_data == 0)
	{
		op_data = 1;
	}
	
	switch(div_op)
	{
		case DIVIDER_DISABLE:
			CPM.CDIVENR &= ~(IPS_DIVEN);
			break;
		case UPDATA_DIVIDER:
			CPM.CDIVENR |= IPS_DIVEN;
			CPM.PCDIVR1 &= ~(IPS_DIV_MASK);
			CPM.PCDIVR1 |= (op_data << IPS_DIV_SHIFT);
			CPM.CDIVUPDR = PERDIV_UPD;
			break;
		case GET_NOW_DIVIDER:
			return_val = ((CPM.PCDIVR1 & IPS_DIV_MASK) >> IPS_DIV_SHIFT);
			break;
		case GET_NOW_CLKGATE:
			return_val = (CPM.IPSCGTCR);
			break;
		case CLKGATE_RESTORE:
			CPM.IPSCGTCR = op_data;
			break;
		default:
			break;
	}
	
	return return_val;
}

/******************************************************************************
* Function Name  : cpm_set_sysclk_div
* Description    : ����OSC120M��Ƶ��Ϊϵͳʱ��
* Input          :  div�� the divide value of OSC120M_CLK
*
* Output         : None
* Return         : None
******************************************************************************/
static void cpm_set_sysclk_div(U32 div)
{
	CPM.SCDIVR &= ~(SYS_DIV_MASK);
	CPM.SCDIVR |= (div << SYS_DIV_SHIFT);
	
	CPM.CDIVUPDR |= SYSDIV_UPD;
}

/*******************************************************************************
* Function Name  : CPM_Vref_Trim
* Description    : trim�ο���ѹ
* Input          : trim_value��b'00 is 1.05V; b'01 is 1.1V; b'10 is 1.15V; b'11 is 1.21V��
*															
* Output         : None
* Return         : None
******************************************************************************/
void CPM_Vref_Trim(unsigned int trim_value)
{
	CPM.VCCCTMR = 0x40000000;
	CPM.VCCCTMR = 0x80000000;
	CPM.VCCCTMR = 0xc0000000;
	CPM.VCCCTMR |= 1<<23;
	if(CPM_VREF_TRIM_090 == trim_value)
	{
		CPM.VCCGTRIMR = (CPM.VCCGTRIMR)|(1<<15);
	}
	else
	{
		CPM.VCCGTRIMR = (CPM.VCCGTRIMR)& ~(1<<15);
		CPM.VCCGTRIMR = (CPM.VCCGTRIMR&~0x0f)|(trim_value &0x0f);
	}
}

/*******************************************************************************
* Function Name  : CPM_SysClkSelect
* Description    : ����sys_sel��Ƶ��Ϊϵͳʱ��
* Input          :  - sys_sel�� ϵͳ��ʱ��ԴSYSCLK_SEL_OSC8M, SYSCLK_SEL_OSC160, SYSCLK_SEL_USBPHY or SYSCLK_SEL_OSCEXT
*                   - div��ʱ��Ԥ��Ƶ(�û�����ϣ���ķ�Ƶ)
*
* Output         :  - None
* Return         :  - None
******************************************************************************/
void CPM_SysClkSelect(U32 sys_sel, U32 div)
{
	switch(sys_sel)
	{
		case SYSCLK_OSC8M:
			CPM.OCSR |= OSC8M_EN;
			while(OSC8M_STABLE != (CPM.OCSR & OSC8M_STABLE));
		
			CPM.CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM.CSWCFGR |= SYSCLK_SEL_OSC8M;
			while(CLKSEL_ST_OSC8M != (CPM.CSWCFGR & CLKSEL_ST_OSC8M));
			break;
		
		case SYSCLK_OSC160M:
			
#if SYS_CLK_TRIM_150M
			if(1 == div)
			{
				CPM_Vref_Trim(CPM_VREF_TRIM_121);
			}
#else
			if((CPM.VCCGTRIMR & 0x03) != CPM_VREF_TRIM_110)
			{
				CPM_Vref_Trim(CPM_VREF_TRIM_110);
			}
#endif
			CPM.OCSR |= OSC160M_EN;
			while(OSC160M_STABLE != (CPM.OCSR & OSC160M_STABLE));
		
			CPM.CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM.CSWCFGR |= SYSCLK_SEL_OSC160M;
			while(CLKSEL_ST_OSC160M != (CPM.CSWCFGR & CLKSEL_ST_OSC160M));
			break;
		
		case SYSCLK_USBPHY240M:
			CPM.OCSR |= USB_PHY240M_EN;
			while(USB_PHY240M_STABLE != (CPM.OCSR & USB_PHY240M_STABLE));
		
			CPM.CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM.CSWCFGR |= SYSCLK_SEL_USBPHY240M;
			while(CLKSEL_ST_USBPHY240M != (CPM.CSWCFGR & CLKSEL_ST_USBPHY240M));
			break;
				
		case SYSCLK_OSCEXT:
			CPM.OCSR |= OSCEXT_EN;
			while(OSCEXT_STABLE != (CPM.OCSR & OSCEXT_STABLE));
		
			CPM.CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM.CSWCFGR |= SYSCLK_SEL_OSCEXT;
			while(CLKSEL_ST_OSCEXT != (CPM.CSWCFGR & CLKSEL_ST_OSCEXT));
			break;
		
		default:
			break;
	}
	
	cpm_set_sysclk_div(div-1);
}

/*******************************************************************************
* Function Name  : Get_Sys_Clock
* Description    : ���ص�ǰϵͳƵ�ʣ���λHz
*
* Input          : ��
* Output         : ϵͳƵ��
* Return         : None
******************************************************************************/
UINT32 Get_Sys_Clock(void)
{
	UINT8 clk_src;
	UINT32 clk_freq;
	
	clk_src = CPM.CSWCFGR & SYSCLK_SEL_MASK;
	
	switch((clk_src & 0x3))
	{
		case SYSCLK_OSC8M:
			clk_freq = 8*1000*1000;
			break;
		case SYSCLK_OSC160M:
//#if SYS_CLK_TRIM_108M
//			clk_freq = OSC108M;
//#endif
#if SYS_CLK_TRIM_120M
			clk_freq = OSC120M;
#endif
#if SYS_CLK_TRIM_150M
			clk_freq = OSC150M;
#endif
#if SYS_CLK_TRIM_160M
			clk_freq = OSC160M;
#endif	
#if (!SYS_CLK_TRIM_160M&&!SYS_CLK_TRIM_150M&&!SYS_CLK_TRIM_120M&&!SYS_CLK_TRIM_108M)
		clk_freq = OSC160M;
#endif
		
			break;
		case SYSCLK_USBPHY240M:
			clk_freq = 240*1000*1000;
			break;
		case SYSCLK_OSCEXT:
			clk_freq = 12*1000*1000;
			break;
		default:
			clk_freq = 0;
			break;
	}
	
	return ((UINT32)(clk_freq / (((CPM.SCDIVR & SYS_DIV_MASK) >> SYS_DIV_SHIFT) + 1)));

}


