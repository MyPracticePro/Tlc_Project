/*
 * cache.c
 *
 *  Created on: 2017��2��28��
 *      Author: Administrator
 */

#include "Cache.h"


/*******************************************************************************
* Function Name  : ICACHE_Init
* Description    : CACHE��ʼ��
* Input          :  - rom: The attributes of rom memory regions��
*                          ȡֵcacheThrough, cacheBack or cacheOff
*                   - boot��The attributes of boot memory regions
*                          ȡֵcacheThrough, cacheBack or cacheOff
*                   - spim1�� The attributes of spim1 memory regions
*                          ȡֵcacheThrough, cacheBack or cacheOff
*                   - eflash�� The attributes of eflash memory regions
*                          ȡֵcacheThrough, cacheBack or cacheOff
* Output         : None
*
* Return         : None
* Note			  ���ϵ��ִ��һ�Σ������ظ�ִ�С�
******************************************************************************/
void ICACHE_Init(cache_com spim1, cache_com eflash, cache_com rom, cache_com boot)
{
	/*spim1 cache configuration*/
	if (cacheOff == spim1)
	{
		IPCCRGS_H &= SPIM1_CACHEOFF;
	}
	else if (cacheThrough == spim1)
	{
		IPCCRGS_H &= SPIM1_CACHEOFF;
		IPCCRGS_H |= (WRITE_THROUGH << SPIM1_CACHE_SHIFT);
	}
	else if (cacheBack == spim1)
	{
		IPCCRGS_H &= SPIM1_CACHEOFF;
		IPCCRGS_H |= (WRITE_BACK << SPIM1_CACHE_SHIFT);
	}
	
	/*rom cache configuration*/
	if (cacheOff == rom)
	{
		IPCCRGS &= ROM_CACHEOFF;
	}
	else if (cacheThrough == rom)
	{
		IPCCRGS &= ROM_CACHEOFF;
		IPCCRGS |= (0x02 << ROM_CACHE_SHIFT);
	}
	else if (cacheBack == rom)
	{
		IPCCRGS &= ROM_CACHEOFF;
		IPCCRGS |= (0x03 << ROM_CACHE_SHIFT);
	}
		
	/*boot cache configuration*/
	if (cacheOff == boot)
	{
		IPCCRGS_H &= BOOT_CACHEOFF;
	}
	else if (cacheThrough == boot)
	{
		IPCCRGS_H &= BOOT_CACHEOFF;
		IPCCRGS_H |= (WRITE_THROUGH << BOOT_CACHE_SHIFT);
	}
	else if (cacheBack == boot)
	{
		IPCCRGS_H &= BOOT_CACHEOFF;
		IPCCRGS_H |= (WRITE_BACK << BOOT_CACHE_SHIFT);
	}
	
	/*eflash cache configuration*/
	if (cacheOff == eflash)
	{
		IPCCRGS_H &= EFLASH_CACHEOFF;
	}
	else if (cacheThrough == eflash)
	{
		IR2HIGHADDR = 0x1fffff;
		IPCCRGS_H &= EFLASH_CACHEOFF;
		IPCCRGS_H |= (EFLASH_WRITE_THROUGH);
	}
	else if (cacheBack == eflash)
	{
		IR2HIGHADDR = 0x1fffff;
		IPCCRGS_H &= EFLASH_CACHEOFF;
		IPCCRGS_H |= (EFLASH_WRITE_BACK);
	}
	
	ICACHE->CACHE_CCR |= (GO|INVW1|INVW0);
	while( ((ICACHE->CACHE_CCR)&(GO)) == GO );
	ICACHE->CACHE_CCR |= ENCACHE;
}

/*******************************************************************************
* Function Name  : DCACHE_Init
* Description    : CACHE��ʼ��
* Input          :  - rom: The attributes of rom memory regions��
*                          ȡֵcacheThrough, cacheBack or cacheOff
*                   - boot��The attributes of boot memory regions
*                          ȡֵcacheThrough, cacheBack or cacheOff
*                   - spim1�� The attributes of spim1 memory regions
*                          ȡֵcacheThrough, cacheBack or cacheOff
*                   - eflash�� The attributes of eflash memory regions
*                          ȡֵcacheThrough, cacheBack or cacheOff
* Output         : None
*
* Return         : None
* Note			  ���ϵ��ִ��һ�Σ������ظ�ִ�С�
******************************************************************************/
void DCACHE_Init(cache_com spim1, cache_com eflash, cache_com rom, cache_com boot)
{
	/*spim1 cache configuration*/
	if (cacheOff == spim1)
	{
		DPCCRGS_H &= SPIM1_CACHEOFF;
	}
	else if (cacheThrough == spim1)
	{
		DPCCRGS_H &= SPIM1_CACHEOFF;
		DPCCRGS_H |= (WRITE_THROUGH << SPIM1_CACHE_SHIFT);
	}
	else if (cacheBack == spim1)
	{
		DPCCRGS_H &= SPIM1_CACHEOFF;
		DPCCRGS_H |= (WRITE_BACK << SPIM1_CACHE_SHIFT);
	}
	
	/*rom cache configuration*/
	if (cacheOff == rom)
	{
		DPCCRGS &= ROM_CACHEOFF;
	}
	else if (cacheThrough == rom)
	{
		DPCCRGS &= ROM_CACHEOFF;
		DPCCRGS |= (0x02 << ROM_CACHE_SHIFT);
	}
	else if (cacheBack == rom)
	{
		DPCCRGS &= ROM_CACHEOFF;
		DPCCRGS |= (0x03 << ROM_CACHE_SHIFT);
	}
		
	/*boot cache configuration*/
	if (cacheOff == boot)
	{
		DPCCRGS_H &= BOOT_CACHEOFF;
	}
	else if (cacheThrough == boot)
	{
		DPCCRGS_H &= BOOT_CACHEOFF;
		DPCCRGS_H |= (WRITE_THROUGH << BOOT_CACHE_SHIFT);
	}
	else if (cacheBack == boot)
	{
		DPCCRGS_H &= BOOT_CACHEOFF;
		DPCCRGS_H |= (WRITE_BACK << BOOT_CACHE_SHIFT);
	}
	
	/*eflash cache configuration*/
	if (cacheOff == eflash)
	{
		DPCCRGS_H &= EFLASH_CACHEOFF;
	}
	else if (cacheThrough == eflash)
	{
		DR2HIGHADDR = 0x1fffff;
		DPCCRGS_H &= EFLASH_CACHEOFF;
		DPCCRGS_H |= (EFLASH_WRITE_THROUGH);
	}
	else if (cacheBack == eflash)
	{
		DR2HIGHADDR = 0x1fffff;
		DPCCRGS_H &= EFLASH_CACHEOFF;
		DPCCRGS_H |= (EFLASH_WRITE_BACK);
	}
	
	DCACHE->CACHE_CCR |= (GO|INVW1|INVW0);
	while( ((DCACHE->CACHE_CCR)&(GO)) == GO );
	DCACHE->CACHE_CCR |= ENCACHE;	
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//                 check_target_cache_attr
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Description:
//    check if target address is cached.
//
// Input:
//    the queried start address.
//
// Output:
//    target address cache attribute.
//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
cache_com check_target_cache_attr(UINT32 addr)
{
	cache_com retVal=cacheOff;
//	int region, section, regionShift, found;
//	UINT32 highRegVal, lowRegVal, baseAddr;

	if( (DPCCCR & ENCACHE)== 0x00)
	{
		retVal=cacheOff;
	}
	else
	{
			if(IPCCRGS_H & 0x000000AA)
			{
				retVal = cacheThrough;
			}
	}

	return retVal;
}

void invalid_page_DCache(UINT32 addr)
{
	DPCRINVPAGEADDR = addr;
	DPCRINVPAGESIZE = 0x200 | 0x1;
	
	while((DPCRINVPAGESIZE & 0x1));		//cleard if invalidate completely.
}

void disableCache(void)
{
	//sync DCache
	DPCCCR = GO | PUSHW1 | PUSHW0;
	while(((DPCCCR) & 0x80000000) == 0x80000000);
	
	//sync ICache
	IPCCCR = GO | PUSHW1 | PUSHW0;
	while(((IPCCCR) & 0x80000000) == 0x80000000);
}

