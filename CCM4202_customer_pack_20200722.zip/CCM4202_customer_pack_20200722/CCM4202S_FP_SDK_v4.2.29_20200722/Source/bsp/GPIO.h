/*
 * GPIO.h
 *
 *  Created on: 2016��9��14��
 *      
 */

#ifndef GPIO_H_
#define GPIO_H_
#include "CCM_MEM.h"

void gpioInit(void);
void gpioSet(U8 level);

#endif /* GPIO_H_ */
