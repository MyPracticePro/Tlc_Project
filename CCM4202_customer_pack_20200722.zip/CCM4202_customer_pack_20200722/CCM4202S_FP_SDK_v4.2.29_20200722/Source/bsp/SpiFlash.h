/******************************************************************
 ** �ļ���:spi_flash.h
 ** Copyright (c):C*Core
 ** ������:jshi
 ** �ա���:2015.11.16
 ** �衡��:
 ** ������:
 ** �桡��:Ver0.1
 **--------------------------------------------------------------------------
 ** �޸���:
 ** �ա���:
 ** �޸���:
 ** �桡��:
 
 ******************************************************************/
 
#ifndef __SPI_FLASH_H_
#define __SPI_FLASH_H_

#include "lib/CCM_Types.h"
#include "lib/EPORT.h"

#define SPI_FLASH_PERIPHERALS  &SPI1

#define SPI_FLASH_CS_PIN 0x04


//#define SPI_FLASH_CS_0		(EPORT_WritePin(&EPORT,SPI_FLASH_CS_PIN ,0))
//#define SPI_FLASH_CS_1		(EPORT_WritePin(&EPORT,SPI_FLASH_CS_PIN ,1))

#define SPI_FLASH_CS_0		(SPI_WritePin(&SPI1, PIN_SS, 0))
#define SPI_FLASH_CS_1		(SPI_WritePin(&SPI1, PIN_SS, 1))


#define W25X16_ID		(0XC213)
#define GD25Q16C_ID 		(0XC814)

//#define FLASH_ID 	W25X16_ID 		//W25X16
#define FLASH_ID		GD25Q16C_ID 	//GD25Q16C


#if ( (FLASH_ID) ==  (W25X16_ID) )

//ָ���
#define W25X_WriteEnable		0x06 
#define W25X_WriteDisable		0x04 
#define W25X_ReadStatusReg		0x05 
#define W25X_WriteStatusReg		0x01 
#define W25X_ReadData			0x03 
#define W25X_FastReadData		0x0B 
//#define W25X_FastReadDual		0x3B 
#define W25X_PageProgram		0x02 
#define W25X_BlockErase			0xD8//0x52 
#define W25X_SectorErase		0x20 
#define W25X_ChipErase			0xC7//0x60 
#define W25X_PowerDown			0xB9 
#define W25X_ReleasePowerDown		0xAB 
#define W25X_DeviceID			0xAB 
#define W25X_ManufactDeviceID		0x90 
#define W25X_JedecDeviceID		0x9F 

#elif ( (FLASH_ID) ==  (GD25Q16C_ID) )

//ָ���
#define GD25Q_WriteEnable		0x06
#define GD25Q_WriteDisable		0x04
#define GD25Q_ReadStatusReg		0x05
#define GD25Q_WriteStatusReg		0x01
#define GD25Q_ReadData			0x03
#define GD25Q_FastReadData		0x0B
//#define GD25Q_FastReadDual		0x3B
#define GD25Q_PageProgram		0x02
#define GD25Q_BlockErase		0xD8//0x52
#define GD25Q_SectorErase		0x20
#define GD25Q_ChipErase			0xC7//0x60
#define GD25Q_PowerDown			0xB9
#define GD25Q_ReleasePowerDown		0xAB
#define GD25Q_DeviceID			0xAB
#define GD25Q_ManufactDeviceID		0x90
#define GD25Q_JedecDeviceID		0x9F


#endif



void SPI_Flash_Init(void);
extern U16  SPI_Flash_ReadID(void);			//��ȡFLASH ID
void SPI_Flash_Read(U8* pBuffer,U32 ReadAddr,U16 NumByteToRead);   //��ȡflash
void SPI_Flash_Write(U8* pBuffer,U32 WriteAddr,U16 NumByteToWrite);//д��flash
void SPI_Flash_Erase_Chip(void);		//��Ƭ����
void SPI_Flash_Erase_Sector(U32 Dst_Addr);	//��������
void SPI_Flash_PowerDown(void);			//�������ģʽ
void SPI_Flash_WAKEUP(void);			//����



#endif
