/*
 * Timer.h
 *
 *  Created on: 2016��9��14��
 *      Author: Jason
 */

#ifndef TIMER_H_
#define TIMER_H_

#include "type.h"

extern void timerInit(void);
extern void timerRestart(void);
extern U32  timerElapsedUs(void);
extern void timerDelayUs(U32 us);
extern void timerDelayMs(U32 ms);
extern U32 systemTickMs(void);
extern void power_off_timer_restart(void);
extern U32  power_off_timer_elapsed_us(void);
extern void timerStop(void);
extern void timerStart(void);


#endif /* TIMEOUT_H_ */
