#include "GPIO.h"
#include "Debug.h"
#include "ccm4202s.h"
#include "sys.h"
#include "i2c_drv.h"

extern void  EPORT_WriteGpioData(EPORT_PINx GpioNo, UINT8 bitVal);
U8 g_gint1_int_flag = 0;

void gpioInit(void)
{
	EPORT_ControlConfig_t config;

	/* 
	   Config the eport 0 for a external irq pin for BLE irq, for wakeup the MCU from low power mode,
	   The irq enable please see the BLE initialization code.
	 */
	config.TriggerMode = EPORT_FALLING_EDGE_TRIGGER;
	config.DirectionOutput = 0;
	config.EnablePullup = 1;
	config.OpenDrain = 0;
	EPORT_PinControlConfig(&EPORT, 0, &config); 


    /* For enabled power output.*/
	EPORT_PINx eport_pin = EPORT_PIN38;
	EPORT_WriteGpioData(eport_pin,Bit_RESET);
	EPORT_ConfigGpio(eport_pin,GPIO_OUTPUT);


#if 0
	/*
		Config the eport 1 for a input pin for the external touch pin.
	 
	config.TriggerMode = EPORT_FALLING_EDGE_TRIGGER;
	config.DirectionOutput = 0;
	config.EnablePullup = 1;
	config.OpenDrain = 0;
	EPORT_PinControlConfig(&EPORT, 1, &config); */

	
    EPORT_ConfigGpio(EPORT_PIN1,GPIO_INPUT);
	//EPORT.EPPUER |= (0x01<<1);
    EPORT_Init(EPORT_PIN1, FALLING_EDGE_INT);//LOW_LEVEL_INT 

	

	/* Pin 24*/
	//I2C_ConfigGpio(I2C_SCL,GPIO_INPUT);

    *(uint32_t *)0x4000001C |= (0x01<<12);
	config.TriggerMode = EPORT_FALLING_EDGE_TRIGGER;
	config.DirectionOutput = 0;
	config.EnablePullup = 1;
	config.OpenDrain = 0;
	EPORT_PinControlConfig(&EPORT3, 3, &config); 

	
	/*config.TriggerMode = EPORT_FALLING_EDGE_TRIGGER;
	config.DirectionOutput = 0;
	config.EnablePullup = 1;
	config.OpenDrain = 0;
	EPORT_PinControlConfig(&EPORT, 4, &config); 


	config.TriggerMode = EPORT_FALLING_EDGE_TRIGGER;
	config.DirectionOutput = 0;
	config.EnablePullup = 1;
	config.OpenDrain = 0;
	EPORT_PinControlConfig(&EPORT, 3, &config); */
#endif
}



void gpioISR(void)
{
	EPORT_ClearInterrupt(&EPORT, 4);
	g_gint1_int_flag = 1;
}

void gpioSet(U8 level)
{
	EPORT_WritePin(&EPORT, 0, level);
}
