// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : spi_demo.c
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#include "type.h"
#include "syscfg.h"
#include "spi.h"
#include "eport.h"
#include "uart_drv.h"
#include "mg_api.h"
#include "eport.h"
#include "spi.h"
#include "dma.h"
#include "uart_ble.h"
#include "tc_reg.h"
#include "timer.h"


extern UINT32 g_sys_clk;
extern void CPM_Sleep(void);


/*
MCU - MG126 connection
  GINT0 - IRQ
  SPI1

UART2
*/

#define SPI_MODE_TEST		1

#define SPI_MASTER_MODE

#define SPI_CPU_MODE
//#define SPI_DMAC_MODE		//ջ��ȫ�ֱ�������0x20000000֮�󣬼�IRAM��Start0x20000000,size0x38000
//#define SPI_EDMAC_MODE	//ջ��ȫ�ֱ�������0x20000000֮�󣬼�IRAM��Start0x20000000,size0x38000


typedef struct
{
	__IO UINT32 SPI_CONTROL_REG;	 					//0x00
	__IO UINT32 USI_CONTROL_REG;   					//0x04
	__IO UINT32 I2C_CONTROL_REG;   					//0x08
	__IO UINT32 SCI_CONTROL_REG;   					//0x0c
	__IO UINT32 GINTL_CONTROL_REG;  				//0x10
	__IO UINT32 GINTH_CONTROL_REG;  				//0x14
	__IO UINT32 RESERVED1;   								//0x18
	__IO UINT32 SWAP_CONTROL_REG;   				//0x1C
	__IO UINT32 SPIM1_CONTROL_REG;  				//0x20
	__IO UINT32 SPIM2_CONTROL_REG;  				//0x24
	__IO UINT32	RESERVED2;									//0x28
	__IO UINT32 GINT_31_30_CONTROL_REG;			//0x2c
	__IO UINT32	RESERVED3;									//0x30
	__IO UINT32	RESERVED4;									//0x34
	__IO UINT32	GINT_39_32_CONTROL_REG;			//0x38
	__IO UINT32	GINT_29_22_CONTROL_REG;			//0x3c
	__IO UINT32	RESERVED5;									//0x40
	__IO UINT32 CLKOUT_RSTOUT_CONTROL_REG;	//0x44
	__IO UINT32	RESERVED6;									//0x48
	__IO UINT32	RESERVED7;									//0x4c
	__IO UINT32	RESERVED8;									//0x50
}IOCTRL_TypeDef;



#define IOCTRL     ((IOCTRL_TypeDef *)IOCTRL_BASE_ADDR)
#define SCICR_TX1_GINT4_SWAP_MASK		(1<<28)
#define SCICR_RX1_GINT0_SWAP_MASK		(1<<24)
#define SCICR_TX2_GINT5_SWAP_MASK		(1<<29)
#define SCICR_RX2_GINT3_SWAP_MASK		(1<<27)
#define SCICR_TX3_GINT1_SWAP_MASK		(1<<25)
#define SCICR_RX3_GINT2_SWAP_MASK		(1<<26)


/*******************************************************************************
* Function Name  :IO_Ctrl_SCI_Swap
* Description    :SCI GINT ���ù����л�
* Input          :-sg_sel   ����ѡ��
*									-sw 			:���ù��ܿ���
*									 TRUE  :���ܴ�
*                  FALSE :���ܹر�
*
* Output         : None
* Return         : None
******************************************************************************/
void IO_Ctrl_SCI_Swap(IOCTRL_SG_SEL sg_sel, bool sw)
{
	if(TRUE == sw)//on
	{
		switch(sg_sel)
		{
			case TX1_GINT4:
				IOCTRL->SCI_CONTROL_REG |= SCICR_TX1_GINT4_SWAP_MASK;	//����GINT4��RX1���ù���
				break;
			case RX1_GINT0:
				IOCTRL->SCI_CONTROL_REG |= SCICR_RX1_GINT0_SWAP_MASK;	//����GINT0��TX1���ù���
				break;
			case TX2_GINT5:
				IOCTRL->SCI_CONTROL_REG |= SCICR_TX2_GINT5_SWAP_MASK;	//����GINT5��RX2���ù���
				break;
			case RX2_GINT3:
				IOCTRL->SCI_CONTROL_REG |= SCICR_RX2_GINT3_SWAP_MASK;	//����GINT3��RX2���ù���
				break;
			case TX3_GINT1:
				IOCTRL->SCI_CONTROL_REG |= SCICR_TX3_GINT1_SWAP_MASK;	//����GINT1��TX3���ù���
				break;
			case RX3_GINT2:
				IOCTRL->SCI_CONTROL_REG |= SCICR_RX3_GINT2_SWAP_MASK;	//����GINT2��TX3���ù���
				break;
			default:
				break;
		}
	}
	else	//off
	{
		switch(sg_sel)
		{
			case TX1_GINT4:
				IOCTRL->SCI_CONTROL_REG &= ~SCICR_TX1_GINT4_SWAP_MASK;	//�ر�GINT4��RX1���ù���
				break;
			case RX1_GINT0:
				IOCTRL->SCI_CONTROL_REG &= ~SCICR_RX1_GINT0_SWAP_MASK;	//�ر�GINT0��TX1���ù���
				break;
			case TX2_GINT5:
				IOCTRL->SCI_CONTROL_REG &= ~SCICR_TX2_GINT5_SWAP_MASK;	//�ر�GINT5��RX2���ù���
				break;
			case RX2_GINT3:
				IOCTRL->SCI_CONTROL_REG &= ~SCICR_RX2_GINT3_SWAP_MASK;	//�ر�GINT3��RX2���ù���
				break;
			case TX3_GINT1:
				IOCTRL->SCI_CONTROL_REG &= ~SCICR_TX3_GINT1_SWAP_MASK;	//�ر�GINT1��TX3���ù���
				break;
			case RX3_GINT2:
				IOCTRL->SCI_CONTROL_REG &= ~SCICR_RX3_GINT2_SWAP_MASK;	//�ر�GINT2��TX3���ù���
				break;
			default:
				break;
		}
	}

}


/*******************************************************************************
* Function Name  : SysTick_Enable
* Description    : 
* Input          : flag  : TRUE :Open systick  FALSE :Close systick
*
* Output         : 
* Return         : None
******************************************************************************/
void SysTick_Enable(bool flag)
{
	if(flag == TRUE)
	{
		SysTick->CTRL  |= SysTick_CTRL_ENABLE_Msk;                         /* Enable SysTick */
	}
	else
	{
		SysTick->CTRL  &= ~SysTick_CTRL_ENABLE_Msk;                         /* Disable SysTick */
	}
}





#define WDT		    ((WDT_TypeDef *)(WDT_BASE_ADDR))
#define WDT_EN    0x01

/*******************************************************************************
* Function Name  : WDT_Init
* Description    : WDT��ʼ��
* Input          : - WMRCounterVal: ���Ź�������ֵ
*
* Output         : None
* Return         : None
******************************************************************************/
void WDT_Init(UINT16 WMRCounterVal)
{
	WDT->WDT_WMR = WMRCounterVal;
	WDT->WDT_WCR = WDT_EN;
}

/*******************************************************************************
* Function Name  : WDT_FeedDog
* Description    : WDTι��
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void WDT_FeedDog(void)
{
	WDT->WDT_WSR = 0x5555;
	WDT->WDT_WSR = 0xAAAA;
}


unsigned char SPI_WriteRead(unsigned char SendData)
{
    while(((SPI2_REG_STR->SPISRHW)&(SPISR_TXFFULL_MASK)));
	SPI2_REG_STR->SPIDR = SendData;
	while(!(0x80 & SPI2_REG_STR->SPISR));
	while(((SPI2_REG_STR->SPISRHW) & (SPISR_RXFEMP_MASK)));
	return SPI2_REG_STR->SPIDR;
}

unsigned char SPI_WriteBuf(unsigned char reg, unsigned char const *pBuf, unsigned char len)
{
    unsigned char i;
    
    SPI_CS_L(SPI2_REG_STR);
    
    SPI_WriteRead(reg);
    for (i=0;i<len;i++)
    {
        SPI_WriteRead(*(pBuf+i));
    }
    
    SPI_CS_H(SPI2_REG_STR);
    return 0;
}

unsigned char SPI_ReadBuf(unsigned char reg, unsigned char *pBuf, unsigned char len)
{
    unsigned char i;
    
    SPI_CS_L(SPI2_REG_STR);
    
    SPI_WriteRead(reg);
    for (i=0;i<len;i++)
    {
        *(pBuf+i) = SPI_WriteRead(0xff);
    }
    SPI_CS_H(SPI2_REG_STR);
    /*
    if ((0x0e == reg)&&(1 == len)&&(0 == *pBuf))
    {
        *pBuf = 0x40;
    }
    */
    
    return 0;
}

char IsIrqEnabled(void) //porting api
{
    return !EPORT_ReadGpioData(EPORT_PIN0);
}


//////DO NOT REMOVE, used in ble lib///////
void McuGotoSleepAndWakeup(void)
{
}
void SysClk8to48(void)
{
}
void SysClk48to8(void)
{
}


unsigned char aa;

volatile unsigned int SysTick_Count = 0;

unsigned int GetSysTickCount(void) //porting api
{
    return SysTick_Count;
}
void SysTick_Handler(void)
{
    SysTick_Count++;
    ble_nMsRoutine();
	
}
void EPORT0_0_IRQHandler(void)
{
	if((EPORT_REG_STR->EPFR)&(0x01<< EPORT_PIN0))
    {
        EPORT_REG_STR->EPFR |= (0x01<< EPORT_PIN0);
        
        ble_run(0);
    }
}
void BSP_Init(void)
{
    SPI_InitTypeDef SPI_InitStruct;

	#if TRANSMISSION_TX_TO_RX
    UART_InitTypeDef UART_InitStruct;
	#endif
    
    EPORT_ConfigGpio(EPORT_PIN0,GPIO_INPUT);
    EPORT_Init(EPORT_PIN0, FALLING_EDGE_INT);

	timerDelayMs(20);
    
	SPI_StructInit(SPI_Mode_Master,&SPI_InitStruct);
    SPI_InitStruct.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_10;
	SPI_Init(SPI2_REG_STR,&SPI_InitStruct);
	//DMA_Init(DMA1_BASE_ADDR);

	timerDelayMs(20);


#if TRANSMISSION_TX_TO_RX
    IO_Ctrl_SCI_Swap(TX2_GINT5,TRUE);
	IO_Ctrl_SCI_Swap(RX2_GINT3,TRUE);

	
	UART_InitStruct.UART_BaudRate = 115200;
	UART_InitStruct.UART_FrameLength = UART_DATA_FRAME_LEN_10BIT;
	UART_InitStruct.UART_Mode = UART_INT_MODE;
	UART_InitStruct.UART_Parity = UART_PARITY_NONE;
	UART_Init(SCI2_REG_STR, &UART_InitStruct);
#endif
    
    SysTick_Config(g_sys_clk/1500);  //1ms
	SysTick_Enable(TRUE);

	timerDelayMs(20);

	
    WDT_Init(0x68ff);
}
void BLE_Demo(void)
{
    unsigned char *ble_mac_addr;

    BSP_Init();
    
    SetBleIntRunningMode();
    radio_initBle(TXPWR_0DBM, &ble_mac_addr);
		//printf("MAC Address of BLE:%x %x %x %x %x %x\r\n",ble_mac_addr[0],ble_mac_addr[1],ble_mac_addr[2],ble_mac_addr[3],ble_mac_addr[4],ble_mac_addr[5]);
    ble_run_interrupt_start(160*2);


	//set_ble_mac_address(ble_mac_addr);
	
}


void IrqMcuGotoSleepAndWakeup(void)
{
	if(ble_run_interrupt_McuCanSleep())
	{
		
		//printf("off\r\n");
		//disable_battery_power_output();
    	CPM_Sleep();
	}
}



