/*
 * spi_demo.h
 *
 *  Created on: 2018��3��9��
 *      Author: YangWenfeng
 */

#ifndef BLE_DEMO_H_
#define BLE_DEMO_H_


#define TRANSMISSION_TX_TO_RX   (0)

extern void BLE_Demo(void);
void IrqMcuGotoSleepAndWakeup(void);
void WDT_Init(UINT16 WMRCounterVal);
void WDT_FeedDog(void);




#endif /* SPI_DEMO_H_ */
