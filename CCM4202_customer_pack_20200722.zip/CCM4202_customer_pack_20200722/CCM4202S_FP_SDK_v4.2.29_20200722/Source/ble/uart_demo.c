// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : uart_demo.c
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#include "uart_drv.h"
#include "type.h"
#include "debug.h"
#include "string.h"
#include "uart_demo.h"
#include "syscfg.h"
//#include "ioctrl_drv.h"
//#include "cpm_drv.h"
//#include "eport_drv.h"
//#include "tc_drv.h"
//#include "wdt_drv.h"
#include "delay.h"

//static UINT8 ucUart1Send[1024] = {0x31, 0x32, 0x33, 0x34};
//static UINT8 ucUart1Recv[100]= {0x35, 0x36, 0x37, 0x38};

void UART_Init_Int_Demo(UART_TypeDef *UARTx)
{
	UART_InitTypeDef UART_InitStruct;
	//init uart
	UART_InitStruct.UART_BaudRate = 115200;
	UART_InitStruct.UART_FrameLength = UART_DATA_FRAME_LEN_10BIT;
	UART_InitStruct.UART_Mode = UART_INT_MODE;//�����жϷ�ʽ
	UART_InitStruct.UART_Parity = UART_PARITY_NONE;
	
	UART_Init(UARTx, &UART_InitStruct);
	
}

void SCI_GPIO_Test(UART_TypeDef *SCIx)
{
#if 0
	
	UART_ConfigGpio(SCIx,UART_RX, GPIO_OUTPUT);
	UART_ConfigGpio(SCIx,UART_TX, GPIO_INPUT);
	
	while(1)
	{
		UART_WriteGpioData(SCIx,UART_RX, UART_ReadGpioData(SCIx,UART_TX));
		DelayMS(100);
	}
	
#else
	
	UART_ConfigGpio(SCIx,UART_TX, GPIO_OUTPUT);
	UART_ConfigGpio(SCIx,UART_RX, GPIO_INPUT);
	
	while(1)
	{
		UART_WriteGpioData(SCIx,UART_TX, UART_ReadGpioData(SCIx,UART_RX));
		DelayMS(100);
	}
#endif
}

void UART_Demo(void)
{
	UINT8 data;
	
	UART_TypeDef *sci_base_addr;
	
	sci_base_addr = SCI1_REG_STR;
	
#if SCI_MODE_TEST
	
//GINT[5:0]���ž���SCI���ù��ܣ�����SCI���ù��ܺ�GINT��ת����Ϊ��Ӧ��SCI���ܣ�ͬʱ��SCI���Ž�ת���ɶ�Ӧ��GINT����(����������Դ)��
#if SCI_GINT_SWAP_EN 
	if(sci_base_addr == SCI1)
	{
		//SCI1 GINT0&GINT4 swap enable 
		IO_Ctrl_SCI_Swap(TX1_GINT4,TRUE);
		IO_Ctrl_SCI_Swap(RX1_GINT0,TRUE);
	}
	else if(sci_base_addr == SCI2)
	{
		//SCI2 GINT3&GINT5 swap enable
		IO_Ctrl_SCI_Swap(TX2_GINT5,TRUE);
		IO_Ctrl_SCI_Swap(RX2_GINT3,TRUE);
	}
	else if(sci_base_addr == SCI3)
	{
		//SCI3 GINT1&GINT2 swap enable
		IO_Ctrl_SCI_Swap(TX3_GINT1,TRUE);
		IO_Ctrl_SCI_Swap(RX3_GINT2,TRUE);
	}
	else
	{
		__ASM volatile("bkpt 0x12");
	}
#endif
	
	printf("uart demo...\r\n");		//����SCI1 
	
	UART_Init_Int_Demo(sci_base_addr);
	
	while(1)
	{
		if (UART_RecvByte(sci_base_addr, &data) == TRUE)//���ڽ��յ�����
		{
			UART_SendByte(sci_base_addr, data);//���ͽ��յ�������
			data = 0x00;
		}
	}

#else	//SCI GPIO test
	SCI_GPIO_Test(sci_base_addr);
#endif
}




