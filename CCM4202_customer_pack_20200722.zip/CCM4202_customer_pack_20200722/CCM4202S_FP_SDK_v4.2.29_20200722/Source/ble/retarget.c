#include "type.h"
#include "mg_api.h"
#include "uart_drv.h"
#include "ble_demo.h"
#include "platform.h"

#if TRANSMISSION_TX_TO_RX
#define MAX_SIZE 200
u8 txBuf[MAX_SIZE], rxBuf[MAX_SIZE];
static u16 RxCont = 0;
static u8 PosW = 0, txLen = 0;
#endif

//extern volatile USARTypDef	uart_tag ;

extern char GetConnectedStatus(void);



void SCI2_IRQHandler(void)
{
#if TRANSMISSION_TX_TO_RX

    if((SCI2_REG_STR->SCISR1 & SCISR1_RDRF_MASK) == SCISR1_RDRF_MASK)
	{
        rxBuf[RxCont] = SCI2_REG_STR->SCIDRL;
        RxCont++;
        if(RxCont >= MAX_SIZE)
        {
            RxCont = 0;
        }
	}
    if ((SCI2_REG_STR->SCISR1 & SCISR1_TC_MASK) == SCISR1_TC_MASK)
    {
        if (PosW < txLen)
        {
            SCI2_REG_STR->SCICR2 |= SCICR2_TE_MASK;
            while((SCI2_REG_STR->SCISR1 & SCISR1_TDRE_MASK)==0);
            SCI2_REG_STR->SCIDRL = txBuf[PosW++];
        }
        
        if (PosW >= txLen){
            SCI2_REG_STR->SCICR2 &= ~SCICR2_TCIE_MASK;
            txLen = 0;
            PosW = 0;
        }
    }
#endif
	  return;
}

void moduleOutData(u8*data, u8 len) //api
{
    
//	unsigned char i;
#if TRANSMISSION_TX_TO_RX


    unsigned char i;

    if ((txLen+len)<MAX_SIZE)//buff not overflow
    {
        for (i=0;i<len;i++)
        {
            txBuf[txLen+i] = *(data+i);
        }
        txLen += len;
    }
#else

	platform_bluetooth_event_notify(EVT_BT_REV_BUF, data, len);

	/*uint8_t i = 0;

	for (i = 0; i < len; i++){
		if(!(uart_tag.rx_stat&RX_BUF_F))
		{
			uart_tag.rx_buf[uart_tag.rx_size] = data[i];
			uart_tag.rx_size++;
			uart_tag.rx_size = uart_tag.rx_size&RX_MASK;
	
			if(uart_tag.rx_size == uart_tag.rx_seek)
			{
				uart_tag.rx_stat |= RX_BUF_F;
			}
			uart_tag.rx_stat &= ~RX_BUF_E;
		}
	}*/


#endif
}

#if TRANSMISSION_TX_TO_RX

#define comrxbuf_wr_pos RxCont
u16 comrxbuf_rd_pos = 0; //init, com rx buffer
#endif
void CheckComPortInData(void) //at cmd NOT supported
{
#if TRANSMISSION_TX_TO_RX

    u16 send;
    
    if(comrxbuf_wr_pos != comrxbuf_rd_pos)//not empty
    {
        if(!GetConnectedStatus())
        {
            comrxbuf_rd_pos = comrxbuf_wr_pos; //empty the buffer if any
        }
        else //connected
        {
            if(comrxbuf_wr_pos > comrxbuf_rd_pos)
            {
                send = sconn_notifydata(rxBuf+comrxbuf_rd_pos,comrxbuf_wr_pos - comrxbuf_rd_pos);
                comrxbuf_rd_pos += send;
            }
            else 
            {
                send = sconn_notifydata(rxBuf+comrxbuf_rd_pos,MAX_SIZE - comrxbuf_rd_pos);
                comrxbuf_rd_pos += send;
                comrxbuf_rd_pos %= MAX_SIZE;
            }
        }
    }
#endif
}


extern void WDT_FeedDog(void);

void UsrProcCallback(void) //porting api
{
    WDT_FeedDog();

	
#if TRANSMISSION_TX_TO_RX

    CheckComPortInData();
    if ((txLen) && (0 == PosW))
    {
        SCI2_REG_STR->SCICR2 |= SCICR2_TE_MASK;
        while((SCI2_REG_STR->SCISR1 & SCISR1_TDRE_MASK)==0);
        SCI2_REG_STR->SCIDRL = txBuf[PosW++];
        SCI2_REG_STR->SCICR2 |= SCICR2_TCIE_MASK;
    }
#endif
}
