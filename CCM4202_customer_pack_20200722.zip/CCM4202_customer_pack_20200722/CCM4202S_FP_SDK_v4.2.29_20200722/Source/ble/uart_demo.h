// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : uart_demo.h
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __UART_DEMO_H__
#define __UART_DEMO_H__

#define SCI_MODE_TEST		1
#define SCI_GINT_SWAP_EN		0

extern void UART_Demo(void);

#endif /* UART_DEMO_H_ */
