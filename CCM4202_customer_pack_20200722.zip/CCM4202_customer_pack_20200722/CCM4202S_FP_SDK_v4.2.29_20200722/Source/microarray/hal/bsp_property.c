#include "bsp_property.h"
#include "platform.h"
#include "auto_define.h"
#include "malog.h"
#include "globalvar.h"
#include "projectConfig.h"

boardContext bsp_ctx; 

int8_t storeUserCfgProp(void)
{
	platform_filesystem_write(USER_CFG_DATA_ADDR, &bsp_ctx, sizeof(boardContext));
	platform_filesystem_read(USER_CFG_DATA_ADDR, &bsp_ctx, sizeof(boardContext));
	
	return 0;
}

void get_default_property(ConfigBox_t* box)
{
	periphConfig config;
	uint8_t tmp1, tmp2;

	config.motor_conf.mode = MT_MODE;
	config.motor_conf.forwardRun = MT_FWD;
	config.motor_conf.backwardRun = MT_BWD;
	config.motor_conf.interval = MT_INT;
	config.motor_conf.shaft_detect_cnt = MT_SFT_DET_CNT;
	config.motor_conf.smooth_toler = MT_SMF_TOLE;
	config.motor_conf.shaft_adc_val = MT_SFT_VAL;
	config.motor_conf.shaft_curet_time = MT_SFT_CUR_T;
	config.motor_conf.shaft_curet_cnt = MT_SFT_CUR_CNT;
	config.motor_conf.fwd_det_delay = MT_FWD_DLY;
	config.motor_conf.bwd_det_delay = MT_BWD_DLY;
	config.motor_conf.shaft_rollback = MT_SFT_ROLL;
	config.motor_conf.unlock_timeout = MT_ULK_TOUT;

	config.led_conf.mode = LED_MODE;
	config.led_conf.flash_slow_dura = LED_FLH_SDURA;
	config.led_conf.flash_fast_dura = LED_FLH_FDURA;
	config.led_conf.light_dura = LED_LIH_DURA;
	config.led_conf.breath_half_dura = LED_BTH_DURA;
	config.led_conf.breath_freq = LED_BTH_FREQ;

	config.misc_conf.version = VER_NO;
	config.misc_conf.bt_adv_type = BT_ADV_TYPE;
	config.misc_conf.bt_adv_power = BT_ADV_PWD;
	config.misc_conf.bt_adv_interval = BT_ADV_INT;
	config.misc_conf.bt_adv_duty = BT_ADV_DUTY;

	config.bat_conf.type = BAT_TYPE;
	config.bat_conf.adc_vref = BAT_VREF;
	config.bat_conf.low_warn = BAT_LWAR;

	box->policy = 0x00;
	
	box->ver = config.misc_conf.version;  //bit0~3 vice, bit4~7 main
	
	box->mode = (config.bat_conf.type & 0x03) << 6 | 
		        (config.bat_conf.adc_vref & 0x03) << 4 |
		        config.motor_conf.mode & 0x0f;
	
	if(config.misc_conf.bt_adv_power < 0) {
		tmp1 |= (1 << 5);
	} else {
		tmp1 &= ~(1 << 5);
	}
	tmp1 = config.misc_conf.bt_adv_power & 0x0f;
	box->adv = (config.misc_conf.bt_adv_type & 0x07) << 5 |
		       (tmp1 & 0x1f);

	tmp1 = (config.motor_conf.unlock_timeout / 200) - 1;
	//MALOGD("timeout %d, tmp %d", config.motor_conf.unlock_timeout, tmp1);
	tmp2 = (config.misc_conf.bt_adv_interval / 100) - 1;
	box->interval = (tmp1 & 0x0f) << 4 |
		            (tmp2 & 0x0f);
	
	box->duty = config.misc_conf.bt_adv_duty - 1;

	tmp1 = config.motor_conf.shaft_detect_cnt - 1;
	box->hint = (tmp1 &  0x0f) << 4 |
		        (config.led_conf.mode & 0x0f);
	
	tmp1 = config.motor_conf.smooth_toler - 2;
	tmp2 = (config.motor_conf.shaft_adc_val / 10) - 1;
	box->adc = (tmp1 & 0x07) << 5 |
		       (tmp2 & 0x1f);
	
	tmp1 = ((float)config.motor_conf.shaft_curet_time / 0.2f) - 1;
	tmp2 = (config.motor_conf.shaft_curet_cnt / 2) - 1;
	box->block = (tmp1 & 0x1f) << 3 |
		         (tmp2 & 0x07);
	
	tmp1 = (config.motor_conf.fwd_det_delay / 25) - 1;
	tmp2 = (config.motor_conf.bwd_det_delay / 25) - 1;
	box->delay = (tmp1 & 0x0f) << 4 |
		         (tmp2 & 0x0f);
	
	box->wait = (config.motor_conf.interval / 100) - 1;
	
	box->roll = config.motor_conf.shaft_rollback / 5;

	box->frun = (config.motor_conf.forwardRun / 10) - 1;

	box->brun = (config.motor_conf.backwardRun / 10) - 1;

	box->sflash = (config.led_conf.flash_slow_dura / 10) - 1;

	box->qflash = (config.led_conf.flash_fast_dura / 10) - 1;

	box->light = (config.led_conf.light_dura / 10) - 1;

	box->breath = (config.led_conf.breath_half_dura / 10) - 1;

	box->bfreq = config.led_conf.breath_freq - 1;
	
}

void load_property_to_config()
{
	periphConfig config;
	uint16_t tmp, key;

	key = project_ctx.bsp_ctx->configBox.ver;
	config.misc_conf.version = key;

	key = project_ctx.bsp_ctx->configBox.mode;
	tmp = (key >> 6) & 0x03;
	config.bat_conf.type = tmp;
	tmp = (key >> 4) & 0x03;
	config.bat_conf.adc_vref = tmp;
	tmp = key & 0x0f;
	config.motor_conf.mode = tmp;

	key = project_ctx.bsp_ctx->configBox.adv;
	tmp = (key >> 5) & 0x07;
	config.misc_conf.bt_adv_type = tmp;
	tmp = key & 0x1f;
	if(tmp & 0x10) { //>0
		config.misc_conf.bt_adv_power = tmp & 0x0f;
	} else { //<0
		config.misc_conf.bt_adv_power = 0 - tmp & 0x0f;
	}

	key = project_ctx.bsp_ctx->configBox.interval;
	tmp = (key >> 4) & 0x0f;
	config.motor_conf.unlock_timeout = (tmp + 1) * 200;
	tmp = key & 0x0f;
	config.misc_conf.bt_adv_interval = (tmp + 1) * 100;

	key = project_ctx.bsp_ctx->configBox.duty;
	tmp = key ;
	config.misc_conf.bt_adv_duty = tmp + 1;
	
	key = project_ctx.bsp_ctx->configBox.hint;
	tmp = (key >> 4) &0x0f;
	config.motor_conf.shaft_detect_cnt = tmp + 1;
	tmp = key & 0x0f;
	config.led_conf.mode = tmp;
	
	key = project_ctx.bsp_ctx->configBox.adc;
	tmp = (key >> 5) & 0x07;
	config.motor_conf.smooth_toler = tmp + 2;
	tmp = key & 0x1f;
	config.motor_conf.shaft_adc_val = (tmp + 1) * 10;
	
	key = project_ctx.bsp_ctx->configBox.block;
	tmp = (key >> 3) & 0x1f;
	config.motor_conf.shaft_curet_time = (tmp + 1) * 0.2f;
	tmp = key & 0x07;
	config.motor_conf.shaft_curet_cnt = (tmp + 1) * 2;
	
	key = project_ctx.bsp_ctx->configBox.delay;
	tmp = (key >> 4) & 0x0f;
	config.motor_conf.fwd_det_delay = (tmp + 1) * 25;
	tmp = key & 0x0f;
	config.motor_conf.bwd_det_delay = (tmp + 1) * 25;
	
	key = project_ctx.bsp_ctx->configBox.wait;
	tmp = key;
	config.motor_conf.interval = (tmp + 1) * 100;
	
	key = project_ctx.bsp_ctx->configBox.roll;
	tmp = key;
	config.motor_conf.shaft_rollback = tmp * 5;

	key = project_ctx.bsp_ctx->configBox.frun;
	tmp = key;
	config.motor_conf.forwardRun = (tmp + 1) * 10;

	key = project_ctx.bsp_ctx->configBox.brun;
	tmp = key;
	config.motor_conf.backwardRun = (tmp + 1) * 10;

	key = project_ctx.bsp_ctx->configBox.sflash;
	tmp = key;
	config.led_conf.flash_slow_dura = (tmp + 1) * 10;

	key = project_ctx.bsp_ctx->configBox.qflash;
	tmp = key;
	config.led_conf.flash_fast_dura = (tmp + 1) * 10;

	key = project_ctx.bsp_ctx->configBox.light;
	tmp = key;
	config.led_conf.light_dura = (tmp + 1) * 10;;

	key = project_ctx.bsp_ctx->configBox.breath;
	tmp = key;
	config.led_conf.breath_half_dura = (tmp + 1) * 10;;

	key = project_ctx.bsp_ctx->configBox.bfreq;
	tmp = key;
	config.led_conf.breath_freq = tmp + 1;

	if(project_ctx.bsp_conf != NULL) {
		memcpy(project_ctx.bsp_conf, &config, sizeof(periphConfig));
		MALOGD("load config successfully");
	} else {
		MALOGE("bsp conf null");
	}
	
}

int8_t load_bsp_property(void)
{
	uint8_t tmp[UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2] = {0};
	
	platform_filesystem_read(USER_CFG_DATA_ADDR, &bsp_ctx, sizeof(boardContext));
	if(bsp_ctx.saved != DATA_VFY_KEY) {
		MALOGD("get default prop len %d", sizeof(boardContext));
		//load default prop
		get_default_property(&bsp_ctx.configBox);
		memset(bsp_ctx.fp_used_attr, 0x00, MAX_ID * sizeof(fpContext));
		memcpy(bsp_ctx.bt_adv_name, BOARD, sizeof(BOARD));
		memset(&(bsp_ctx.s_date), 0x00, sizeof(tm_date));
		platform_filesystem_write(UNLOCK_RECORD_ADDR, tmp, UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2);
		bsp_ctx.saved = DATA_VFY_KEY;
		storeUserCfgProp(); 
	} else {
		MALOGD("load prop from flash");
	}

	project_ctx.bsp_ctx = &bsp_ctx;
	load_property_to_config();
	
	printf("/**************************************************/\n");
	printf("policy ver mode adv interval duty hint adc \nblock delay wait roll frun brun sflash qflash \nlight breath bfreq\n");
	printf("config box: %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x\n", 
																   bsp_ctx.configBox.policy, bsp_ctx.configBox.ver, bsp_ctx.configBox.mode,
																   bsp_ctx.configBox.adv, bsp_ctx.configBox.interval, bsp_ctx.configBox.duty,
																   bsp_ctx.configBox.hint, bsp_ctx.configBox.adc, bsp_ctx.configBox.block,
																   bsp_ctx.configBox.delay, bsp_ctx.configBox.wait, bsp_ctx.configBox.roll,
																   bsp_ctx.configBox.frun, bsp_ctx.configBox.brun, bsp_ctx.configBox.sflash,
																   bsp_ctx.configBox.qflash, bsp_ctx.configBox.light, bsp_ctx.configBox.breath,
																   bsp_ctx.configBox.bfreq);
	printf("motor config: mode %d, fwdR %d, bwdR %d, intR %d, sft_d_cnt %d, smh_t %d, sft_val %d\n",
		    project_ctx.bsp_conf->motor_conf.mode,  project_ctx.bsp_conf->motor_conf.forwardRun, project_ctx.bsp_conf->motor_conf.backwardRun,
			project_ctx.bsp_conf->motor_conf.interval, project_ctx.bsp_conf->motor_conf.shaft_detect_cnt, project_ctx.bsp_conf->motor_conf.smooth_toler,
			project_ctx.bsp_conf->motor_conf.shaft_adc_val);
	printf("              sft_c_t %d, sft_c_cnt %d, fwd_dly %d, bwd_dly %d, sft_roll %d, timeout %d\n", 	
			project_ctx.bsp_conf->motor_conf.shaft_curet_time, project_ctx.bsp_conf->motor_conf.shaft_curet_cnt,project_ctx.bsp_conf->motor_conf.fwd_det_delay,
			project_ctx.bsp_conf->motor_conf.bwd_det_delay, project_ctx.bsp_conf->motor_conf.shaft_rollback, project_ctx.bsp_conf->motor_conf.unlock_timeout);
	printf("LED   config: mode %d, fls_s %d fls_f %d, lgh %d, bth_d %d, bth_freq %d\n",
			project_ctx.bsp_conf->led_conf.mode, project_ctx.bsp_conf->led_conf.flash_slow_dura, project_ctx.bsp_conf->led_conf.flash_fast_dura,
			project_ctx.bsp_conf->led_conf.light_dura, project_ctx.bsp_conf->led_conf.breath_half_dura, project_ctx.bsp_conf->led_conf.breath_freq);
	printf("BT    config: adv type %d, power %d, interval %d, duty %d\n",
		    project_ctx.bsp_conf->misc_conf.bt_adv_type, project_ctx.bsp_conf->misc_conf.bt_adv_power,
		    project_ctx.bsp_conf->misc_conf.bt_adv_interval, project_ctx.bsp_conf->misc_conf.bt_adv_duty);
	printf("PMU   config: type %d, vref %d, warn %d\n",
		    project_ctx.bsp_conf->bat_conf.type, project_ctx.bsp_conf->bat_conf.adc_vref, project_ctx.bsp_conf->bat_conf.low_warn);
	printf("/**************************************************/\n");
	return 0;
}

int8_t update_bsp_property(ConfigBox_t* box)
{
	memcpy(&bsp_ctx.configBox, box, sizeof(ConfigBox_t));
	storeUserCfgProp();

	load_property_to_config();
	
	return 0;
}

void storeUnlockRecord(uint8_t fid)
{
    uint8_t unlock_record[UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2];
	uint16_t ptr_unlock_item = 0;
    time_t timeStamp;

	platform_filesystem_read(UNLOCK_RECORD_ADDR, unlock_record, UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2);
	ptr_unlock_item = unlock_record[0] << 8 | unlock_record[1];
    timeStamp = platform_rtc_get_sys_time();

    //ptr_unlock_item++; //index is start from 0
	unlock_record[2 + (ptr_unlock_item % MAX_UNLOCK_ITEM) * UNLOCK_PER_ITEM_LEN] = fid;
	unlock_record[3 + (ptr_unlock_item % MAX_UNLOCK_ITEM) * UNLOCK_PER_ITEM_LEN] = 0;//(timeStamp >> 32) & 0xff;
	unlock_record[4 + (ptr_unlock_item % MAX_UNLOCK_ITEM) * UNLOCK_PER_ITEM_LEN] = (timeStamp >> 24) & 0xff;
	unlock_record[5 + (ptr_unlock_item % MAX_UNLOCK_ITEM) * UNLOCK_PER_ITEM_LEN] = (timeStamp >> 16) & 0xff;
	unlock_record[6 + (ptr_unlock_item % MAX_UNLOCK_ITEM) * UNLOCK_PER_ITEM_LEN] = (timeStamp >> 8) & 0xff;
	unlock_record[7 + (ptr_unlock_item % MAX_UNLOCK_ITEM) * UNLOCK_PER_ITEM_LEN] = timeStamp & 0xff;
	ptr_unlock_item++;

	//more than 256 records, something terrible will be happened
	unlock_record[0] = (ptr_unlock_item >> 8) & 0xff;
	unlock_record[1] = ptr_unlock_item  & 0xff;
	MALOGD("ptr_unlock_item=%d, record timestamp = %lu",ptr_unlock_item, timeStamp);    //this log cause auth image partial????????
	platform_filesystem_write(UNLOCK_RECORD_ADDR, (U32 *)unlock_record, UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2);
}


uint8_t getUnlockRecord(uint8_t* result, uint16_t* record_data_len, uint8_t get_num)
{
	uint16_t recorded_num;
	uint8_t unlock_record[UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2];
	uint8_t i, cur_index = 0;
	
	/*unlock_record[0, 1] is the record num*/
	platform_filesystem_read(UNLOCK_RECORD_ADDR, unlock_record, UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2);
	get_num = get_num? get_num : MAX_UNLOCK_ITEM;  //num == 0, get all item
	recorded_num = unlock_record[0] << 8 | unlock_record[1];
	//recorded_num = recorded_num > 0xff ? 0 : recorded_num; 
	cur_index = recorded_num % MAX_UNLOCK_ITEM;
	MALOGD("has %d records, cur_index = %d, get %d items", recorded_num, cur_index, get_num);
	if(recorded_num <= 0)
	{
		*record_data_len = 0;
		get_num = 0;
	} 
	else if(recorded_num >= MAX_UNLOCK_ITEM) 
	{
		get_num = get_num > recorded_num? recorded_num : get_num;
		*record_data_len = get_num * UNLOCK_PER_ITEM_LEN;
		for(i=0; i<get_num; i++)
		{
			memcpy(result + (i * UNLOCK_PER_ITEM_LEN), 
				   unlock_record + 2 + ((cur_index + i) % MAX_UNLOCK_ITEM) * UNLOCK_PER_ITEM_LEN,
				   UNLOCK_PER_ITEM_LEN);
		} 
	} 
	else
	{
		get_num = get_num > recorded_num? recorded_num : get_num;
		*record_data_len = get_num * UNLOCK_PER_ITEM_LEN;
		memcpy(result, unlock_record + 2, *record_data_len);
	}

	return get_num;

}


uint16_t getUnlockRecordNum(void)
{
	uint8_t unlock_record[2];
	uint16_t recorded_num;
	
	
	platform_filesystem_read(UNLOCK_RECORD_ADDR, unlock_record, 2);
	recorded_num = unlock_record[0] << 8 | unlock_record[1];
	return recorded_num > MAX_UNLOCK_ITEM ? MAX_UNLOCK_ITEM : recorded_num;		
}


uint8_t clearUnlockRecord(void)
{
	uint8_t tmp[UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2] = {0};
	platform_filesystem_write(UNLOCK_RECORD_ADDR, tmp, UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM + 2);
	return 0;
}

