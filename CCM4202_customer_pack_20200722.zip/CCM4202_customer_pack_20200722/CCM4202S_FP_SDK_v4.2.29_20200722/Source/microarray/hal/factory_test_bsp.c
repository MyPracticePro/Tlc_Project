#include "factory_test_bsp.h"
#include "globalvar.h"
#include "Power.h"
#include "kg_utils.h"

u8 g_BT_test_result = 0; //0: not in test, 1: test success light blue, 2: test failed light red
u8 test_rev_buff[TEST_FRAME_LEGTH];

void (*factoryTestNotify)(MmiTestCmdRes res, uint8_t result);


u8 TestcheckSum(u8 *check_buff);
void FactoryTestSendResult(MmiTestCmdRes cmd, u8 result);
void FactoryEnrollCallback(u8 step);
const char* item2Str(uint8_t item);

void factoryTestBTCallback(MmiTestCmdRes res, uint8_t result)
{
	switch(res) {
		case CMD_TEST_ALL_RES:
			break;
		case CMD_TEST_LED_RES:
			if(result == CMD_SUCCESS) {
				FactoryTestSendResult(CMD_TEST_LED_RES, 0);
			} else {
				FactoryTestSendResult(CMD_TEST_LED_RES, 1);
			}
			break;
		case CMD_TEST_MOTOR_RES:
			if(result == CMD_SUCCESS) {
				FactoryTestSendResult(CMD_TEST_MOTOR_RES, 0);
			} else {
				FactoryTestSendResult(CMD_TEST_MOTOR_RES, 1);
			}
			break;
		case CMD_TEST_FP_ID_RES:
			if(result == CMD_SUCCESS) {
				FactoryTestSendResult(CMD_TEST_FP_ID_RES, 0);
			} else {
				FactoryTestSendResult(CMD_TEST_FP_ID_RES, result);
			}
			break;
		case CMD_TEST_FP_ENROLL_RES:
			if(result == CMD_SUCCESS) {
				FactoryTestSendResult(CMD_TEST_FP_ENROLL_RES, 0);
			} else {
				FactoryTestSendResult(CMD_TEST_FP_ENROLL_RES, result);
			}
			break;
		case CMD_TEST_FP_MATCH_RES:
			if(result == CMD_SUCCESS) {
				FactoryTestSendResult(CMD_TEST_FP_MATCH_RES, 0);
			} else {
				FactoryTestSendResult(CMD_TEST_FP_MATCH_RES, 1);
			}
			break;
		case CMD_TEST_BT_RES:
			g_BT_test_result = 0x01;
			if(result == CMD_SUCCESS) {
				FactoryTestSendResult(CMD_TEST_BT_RES, 0);
			} else {
				FactoryTestSendResult(CMD_TEST_BT_RES, 1);
			}
			break;
		case CMD_TEST_BT_RESULT_RES:
			g_BT_test_result = 0x02;
			if(result == CMD_SUCCESS) {
				FactoryTestSendResult(CMD_TEST_BT_RESULT_RES, 0);
			} else {
				FactoryTestSendResult(CMD_TEST_BT_RESULT_RES, 1);
			}
			break;
		default :
			break;
	}
}

void FactoryTestTask(uint8_t const* frame)
{
	static factory_test_t item_t;

	memset(test_rev_buff, 0x00, TEST_FRAME_LEGTH);
	memcpy(test_rev_buff, frame, TEST_FRAME_LEGTH);
	if (TestcheckSum(test_rev_buff)) {
		item_t.item = (factory_test_item)test_rev_buff[TEST_CMD_POS];
		item_t.factoryTestCallback = factoryTestBTCallback;
		lock_async_call_wrapper(Factory_test_process , &item_t);
	} else {
		MALOGE("check sum error!");
	}
	
}

uint8_t factoryInitSensorTest(void)
{
	uint8_t ret;

	ret = mafp_reinit_sensor_parameters();
	if(!ret) {
		factoryTestNotify(CMD_INIT_SENSOR_RES, CMD_SUCCESS);
	} else {
		factoryTestNotify(CMD_INIT_SENSOR_RES, CMD_FAIL);
	}

	return 0;
}

uint8_t factoryADCTest(void)
{
	uint16_t val;

	val = platform_battery_get_value();
	if(val >= BATTERY_MIN_ENERGE && val <= BATTERY_MAX_ENERGE) {
		factoryTestNotify(CMD_TEST_ADC_RES, CMD_SUCCESS);
	} else {
		factoryTestNotify(CMD_TEST_ADC_RES, CMD_FAIL);
	}

	return 0;
}


uint8_t factoryLEDTest(void) 
{
	platform_led_start_warn(LLED_RED, LED_LIGHT, 1);
	platform_msleep(500);
	platform_led_start_warn(LLED_GREEN, LED_LIGHT, 1);
	platform_msleep(500);
	platform_led_start_warn(LLED_BLUE, LED_LIGHT, 1);
	platform_msleep(500);

	factoryTestNotify(CMD_TEST_LED_RES, CMD_SUCCESS);
	
	return 0;
}

uint8_t factoryMotorTest(void)
{
	platform_motor_unlock();
	platform_msleep(2000);
	factoryTestNotify(CMD_TEST_MOTOR_RES, CMD_SUCCESS);

	return 0;
}

void onRemind(u8 event, u8 para)
{
	//MALOGD("evnet = %d, para = %d", event, para);
	switch(event){
		case ERR_FP_EROLL_DETECT:		
			break;
		case SUCCESS_ENROLL_STOP:		
			break;
		case SUCCESS_ENROLL:
			app_impl.send_handle_msg(MSG_FP_ENROLL_SUCC, NULL);
			factoryTestNotify(CMD_TEST_FP_ENROLL_RES, CMD_SUCCESS);
			break;
		case FP_LESS_ENROLL_NUM:
			app_impl.send_handle_msg(MSG_FP_STEP_ENROLL_SUCC, NULL);
			factoryTestNotify(CMD_TEST_FP_ENROLL_RES, para);
			break;
		case FP_UNDETEC:
			break;
		default:
			break;
	}
}

uint8_t factoryFPTest(void)
{
	uint8_t chipid;
	uint8_t fp_enroll_id = 15;
	uint16_t i;
	uint8_t  timeout, ret;
	uint32_t start_tick;
	int32_t auth_fid;
	uint8_t retry_time = 3;

	//get chip id
	chipid = mafp_get_chipid();
	MALOGD("id = %d", chipid);
	if(chipid == 0x79){
		factoryTestNotify(CMD_TEST_FP_ID_RES, CMD_SUCCESS);
	} else {
		factoryTestNotify(CMD_TEST_FP_ID_RES, chipid);
		return 1;
	}

	//test enroll
	factoryTestNotify(CMD_TEST_FP_ENROLL_RES, CMD_START);
	mafp_cancel_enroll();
	for(i = 0; i < FINGER_NUM; i++) {
    	if(!mafp_get_enrollid_status(i)) {
        	break;
		}
	}
	if(i >= FINGER_NUM) {
		factoryTestNotify(CMD_TEST_FP_ENROLL_RES, CMD_FAIL);
		return 1;
	}
	fp_enroll_id = i;

	start_tick = platform_timer_us_tick();
	do {
		timeout = (calculateTimeElapse(start_tick) > (ENROLL_TIMEOUT_DEFAULT / 1000)) ? 1 : 0;
		ret = mafp_enroll_v2(fp_enroll_id, DEFAULT_ENROLL_TIMES, 0, onRemind);
		if(ret == SUCCESS_ENROLL) {
			break;
		}
		platform_msleep(200);
		platform_watchdog_get_count();
	}while(!timeout);

	if(timeout) {
		MALOGD("test timeout");
		factoryTestNotify(CMD_TEST_FP_ENROLL_RES, ERR_TIMEOUT);
		return 1;
	} 
	
	//test match
	factoryTestNotify(CMD_TEST_FP_MATCH_RES, CMD_START);
	start_tick = platform_timer_us_tick();
	do{
		auth_fid = mafp_authenticate_v2();
		if(auth_fid < 0) {
			//MALOGE("detect fail %x", auth_fid);
		} else if(auth_fid == ERR_FP_MATCH_FAILED) {
			retry_time--;
			factoryTestNotify(CMD_TEST_FP_MATCH_RES, CMD_FAIL);
			MALOGE("match fail");
		} else {
			factoryTestNotify(CMD_TEST_FP_MATCH_RES, CMD_SUCCESS);
			MALOGD("match ok id = %x",auth_fid);
			break;
		}

		timeout = (calculateTimeElapse(start_tick) > (MATCH_TIMEOUT_DEFAULT / 1000)) ? 1 : 0;
		platform_msleep(200);
		platform_watchdog_get_count();
	}while(!timeout && retry_time);
	
	if(timeout) {
		MALOGD("test timeout");
		factoryTestNotify(CMD_TEST_FP_MATCH_RES, ERR_TIMEOUT);
		return 1;
	} 

	//remove test id
	mafp_remove_enrollid(fp_enroll_id);	
	return 0;
}

uint8_t factoryBTTest(void)
{
	factoryTestNotify(CMD_TEST_BT_RES, 0);
	factoryTestNotify(CMD_TEST_BT_RESULT_RES, 2);

	return 0;
}

void Factory_test_process(void * param)
{
	factory_test_t *item_t;	 
	uint8_t i;

	platform_board_restore();
	wake_lock_timeout(30);
	platform_touch_enable_interrupt(0);
	get_wake_lock();
	g_fsm_state = STATE_FACTORY_TEST;
	
	item_t = param;
	factoryTestNotify = item_t->factoryTestCallback;

	for(i = 1; i < FACTORY_TEST_ITEM_NUM; i++) {
		MALOGD("item %s", item2Str(i));
		if(!strcmp(item2Str(i), "INIT_SENSOR_TEST")) {
			factoryTestNotify(CMD_INIT_SENSOR_RES, CMD_START);
			factoryInitSensorTest();
		} else if(!strcmp(item2Str(i), "ADC_TEST")) {
			factoryTestNotify(CMD_TEST_ADC_RES, CMD_START);
			factoryADCTest();
		} else if(!strcmp(item2Str(i), "LED_TEST")) {
			factoryTestNotify(CMD_TEST_LED_RES, CMD_START);
			factoryLEDTest();
		} else if(!strcmp(item2Str(i), "MOTOR_TEST")) {
			factoryTestNotify(CMD_TEST_MOTOR_RES, CMD_START);
			factoryMotorTest();
		} else if(!strcmp(item2Str(i), "FP_TEST")) {
			factoryTestNotify(CMD_TEST_FP_ID_RES, CMD_START);
			factoryFPTest();
		} else if(!strcmp(item2Str(i), "BT_TEST")) {
			factoryTestNotify(CMD_TEST_BT_RES, CMD_START);
			//factoryBTTest();
		} else {
			MALOGE("no such item");
		}

		platform_msleep(200);
	}

	factoryTestNotify(CMD_TEST_ALL_RES, CMD_SUCCESS);
	g_fsm_state = STATE_IDLE;
	release_wake_lock();
	platform_touch_enable_interrupt(1);
}

void FactoryTestSendResult(MmiTestCmdRes cmd, u8 result)
{
	u8 j;
	u8 send_buff[TEST_FRAME_LEGTH];

	memset(send_buff, 0x00, TEST_FRAME_LEGTH);
	send_buff[0] = (MMITEST_FRAME_START >> 8) & 0xff;
	send_buff[1] = (MMITEST_FRAME_START & 0xff);
	send_buff[2] = cmd;
	send_buff[3] = result;

	for(j = 2; j < TEST_FRAME_LEGTH - 1; j++)
		        send_buff[TEST_FRAME_LEGTH - 1] += send_buff[j];

	platform_bluetooth_send_notification(send_buff, TEST_FRAME_LEGTH);

}

u8 TestcheckSum(u8 *check_buff)
{
    u8 chk_sum = 0;
	u8 i;

	for(i = 2; i < TEST_FRAME_LEGTH - 1; i++) chk_sum += check_buff[i];
	//MALOGD("chk_sum = 0x%x, checksum pos = 0x%x", chk_sum, check_buff[WH_FRAME_LENGTH - 1]);
    return check_buff[TEST_FRAME_LEGTH - 1] == (chk_sum & 0xff);
}

const char* item2Str(uint8_t item)
{
	switch(item) {
		ENUM_TO_STR(INIT_SENSOR_TEST);
		ENUM_TO_STR(ADC_TEST);
		ENUM_TO_STR(LED_TEST);
		ENUM_TO_STR(MOTOR_TEST);
		ENUM_TO_STR(FP_TEST);
		ENUM_TO_STR(BT_TEST);
	default:
		return "unknow item";
	}	
}

