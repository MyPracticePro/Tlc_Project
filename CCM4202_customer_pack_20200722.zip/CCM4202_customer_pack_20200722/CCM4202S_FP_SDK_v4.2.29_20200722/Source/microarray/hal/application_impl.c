#include "platform.h"
#include "application_impl.h"
#include "malog.h"
#include "globalvar.h"
#include "extLed.h"

int8_t defaultApplicationImpl(app_event_t msg, void* data)
{
	int8_t ret = 0;

	switch(msg) {
		case MSG_SYS_BOOT:
			break;
		case MSG_BT_BRODCAST:
			break;
		case MSG_BT_CONNECTED:
			break;
		case MSG_BT_DISCONNECTED:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_BLINK, 2);
			break;
		case MSG_UNLOCK_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_BLINK, 2);
			SetBeep_Alarm(2);
			platform_motor_unlock();
			break;
		case MSG_UNLOCK_FAIL:
			break;
		case MSG_LOCK_SUCC:
			break;
		case MSG_LOCK_FAIL:
			break;
		case MSG_BAT_CHARGE:
			LED_On(LLED_RED);
			break;
		case MSG_BAT_FULL:
			break;
		case MSG_BAT_LOW_WARN:
			platform_led_start_warn(LLED_RED, LED_LIGHT, 1);
			break;
		case MSG_FP_START_ENROLL:
			break;
		case MSG_FP_STEP_ENROLL_SUCC:
			platform_led_start_warn(LLED_GREEN, LED_LIGHT, 1);
			break;
		case MSG_FP_STEP_ENROLL_FAIL:
			break;
		case MSG_FP_ENROLL_SUCC:
			platform_led_start_warn(LLED_GREEN, LED_FLASH_BLINK, 2);
			break;
		case MSG_FP_ENROLL_FAIL:
			platform_led_start_warn(LLED_RED, LED_LIGHT, 1);
			break;
		case MSG_VERY_ADMIN_SUCC:
			break;
		case MSG_VERY_ADMIN_FAIL:
			break;
		case MSG_FP_DELE_MODE:
			break;
		case MSG_FP_DELE_SUCC:
			break;
		case MSG_FP_DELE_FAIL:
			break;
		case MSG_FP_DELE_SIGLE_SUCC:
			break;
		case MSG_FP_DELE_SIGLE_FAIL:
			break;
		case MSG_FP_MATCH_SUCC:
			platform_led_start_warn(LLED_GREEN, LED_FLASH_BLINK, 2);
			platform_motor_unlock();
			break;
		case MSG_FP_MATCH_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_BLINK, 2);
			break;
		case MSG_FP_MATCH_FROZEN:
			break;
		default:
			MALOGD("no such msg");
			break;
	}

	return ret;
	

}

int8_t dragonApplicationImplMode1(app_event_t msg, void* data)
{
	int8_t ret = 0;


	switch(msg) {
		case MSG_SYS_BOOT:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_BLINK, 10);
			break;
		case MSG_BT_BRODCAST:
			break;
		case MSG_BT_CONNECTED:
			if(platform_usb_get_detectPin()) {
				LED_Off(LLED_GREEN);
			}
			LED_On(LLED_BLUE);
			break;
		case MSG_BT_DISCONNECTED:
			if(platform_usb_get_detectPin()) {
				platform_led_start_warn(LLED_GREEN, LED_FLASH_SLOW, 0xffff);
			}
			LED_Off(LLED_BLUE);
			break;
		case MSG_UNLOCK_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_BLINK, 2);
			platform_motor_unlock();
			break;
		case MSG_UNLOCK_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_BLINK, 2);
			break;
		case MSG_LOCK_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_BLINK, 3);
			break;
		case MSG_LOCK_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_BLINK, 3);
			break;
		case MSG_BAT_CHARGE:
			platform_led_start_warn(LLED_GREEN, LED_FLASH_SLOW, 0xffff);  //flash all time function
			break;
		case MSG_BAT_FULL:
			LED_Off(LLED_GREEN);
			break;
		case MSG_BAT_LOW_WARN:
			platform_led_start_warn(LLED_MIXED, LED_ALTERNATE_RB, 10);  
			break;
		case MSG_FP_START_ENROLL:
			platform_led_start_warn(LLED_GREEN, LED_FLASH_BLINK, 3);
			break;
		case MSG_FP_STEP_ENROLL_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_BLINK, 1);
			break;
		case MSG_FP_STEP_ENROLL_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_BLINK, 1);
			break;
		case MSG_FP_ENROLL_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_SLOW, 4);
			break;
		case MSG_FP_ENROLL_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_SLOW, 4);
			break;
		case MSG_VERY_ADMIN_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_SLOW, 1);
			break;
		case MSG_VERY_ADMIN_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_SLOW, 1);
			break;
		case MSG_FP_DELE_MODE:
			platform_led_start_warn(LLED_GREEN, LED_FLASH_BLINK, 5);
			break;
		case MSG_FP_DELE_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_SLOW, 3);
			break;
		case MSG_FP_DELE_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_SLOW, 3);
			break;
		case MSG_FP_DELE_SIGLE_SUCC:
			platform_led_start_warn(LLED_BLUE, LED_FLASH_SLOW, 2);
			break;
		case MSG_FP_DELE_SIGLE_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_SLOW, 2);
			break;
		case MSG_FP_MATCH_SUCC:
			platform_motor_unlock();
			break;
		case MSG_FP_MATCH_FAIL:
			platform_led_start_warn(LLED_RED, LED_FLASH_BLINK, 4);
			break;
		case MSG_FP_MATCH_FROZEN:
			platform_led_start_warn(LLED_GREEN, LED_FLASH_BLINK, 4);
			break;
		case MSG_FP_UNLCOKREC_UPLOAD:
			
			break;
		case MSG_FP_CALIBRATION:
			
			break;
		case MSG_SELF_CHECKING:
			
			break;
		case MSG_SELF_SUCC:
			
			break;
		case MSG_SELF_FAIL:
			
			break;
		default:
			MALOGD("no such msg");
			break;
	}

	return ret;

}

