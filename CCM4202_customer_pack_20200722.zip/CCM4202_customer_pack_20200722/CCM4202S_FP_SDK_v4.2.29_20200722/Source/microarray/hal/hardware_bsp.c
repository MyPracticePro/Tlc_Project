#include "hardware_bsp.h"
#include "mafp_sensor.h"
#include "extTouch.h"
#include "extLed.h"
#include "Motor.h"
#include "system.h"
#include "wheatek.h"
#include "factory_test_bsp.h"
#include "maFsm.h"
#include "dragonpal.h"
#include "globalvar.h"
#include "application_impl.h"

volatile uint32_t wakeup_times = 0;
uint8_t UART_SVC_ADV_NAME[MAX_BLE_NAME_LEN];
_EnrollTag Enroll_Tag={0};
_MatchTag  Match_Tag={0};
volatile _FsmState g_fsm_state;
ptclPackType g_packet_type;
volatile bt_status_t g_bt_status = BT_CLOSE;
u8 g_receive_buff[FRAME_LENGTH];
application_impl_func app_impl;
projectContext project_ctx;

extern volatile u8 PowerOfftimes;

void onEnrollemnet(u8 event, u8 para)
{
	MALOGD("evnet = %d, para = %d, cb = %p", event, para, Enroll_Tag.enroll_cb);
	switch(event){
		case ERR_FP_EROLL_DETECT:
			Enroll_Tag.enroll_cb(ERR_FP_EROLL_DETECT);
			app_impl.send_handle_msg(MSG_FP_STEP_ENROLL_FAIL, NULL);
			break;
		case SUCCESS_ENROLL_STOP:
			app_impl.send_handle_msg(MSG_FP_ENROLL_FAIL, NULL);
			break;
		case SUCCESS_ENROLL:
			app_impl.send_handle_msg(MSG_FP_ENROLL_SUCC, NULL);
			Enroll_Tag.enroll_cb(para);
			break;
		case FP_LESS_ENROLL_NUM:
			Enroll_Tag.start_tick = platform_timer_us_tick();
			app_impl.send_handle_msg(MSG_FP_STEP_ENROLL_SUCC, NULL);
			Enroll_Tag.enroll_cb(para);
			break;
		case FP_UNDETEC:
			break;
		default:
			break;
	}
}

void enroll_work(void)
{
	u8 ret;

	ret = mafp_enroll_v2(Enroll_Tag.enroll_id, Enroll_Tag.enroll_press_times, Enroll_Tag.stop_flag, onEnrollemnet);
	switch(ret){
		case ERR_FP_EROLL_DETECT:
		case SUCCESS_ENROLL_STOP:
			g_fsm_state = STATE_IDLE;
			Enroll_Tag.stop_flag = 0;
			//Enroll_Tag.enroll_cb(0);
			break;
		case SUCCESS_ENROLL:
			g_fsm_state = STATE_IDLE;
			break;
		case FP_LESS_ENROLL_NUM:
			break;
		case FP_UNDETEC:
			MALOGD("enroll detect none");
			break;
		default:
			break;
	}
}

u8 detectFinger(void)
{

	return isExtTouchPress() && mafp_finger_touch();
}

u8 detectFingerLeave(void)
{

	return !isExtTouchPress() || mafp_finger_leave();

}

void defaultAuthCallback(MatchResult state, int16_t fid, int16_t levl)
{
	switch(state) {
		case MATCH_SUCCESS:
			app_impl.send_handle_msg(MSG_FP_MATCH_SUCC, NULL);
			break;
		case MATCH_FAIL:	
			app_impl.send_handle_msg(MSG_FP_MATCH_FAIL, NULL);
			break;
	}
}

void authentication_work(void)
{
	int32_t auth_fid;

	project_ctx.hasfp = mafp_get_used_enrollids();
	if(!project_ctx.hasfp) {
		if(detectFinger()) {
			project_ctx.key_process = 1;
#if BT_PROTOCOL_DRAGONPAL == 0
			app_impl.send_handle_msg(MSG_UNLOCK_SUCC, NULL);
#endif
		}
    } else {
        auth_fid = mafp_authenticate_v2();
		if(auth_fid < 0) {
			MALOGE("detect fail %x", auth_fid);
		} else if(auth_fid == ERR_FP_MATCH_FAILED) {
			project_ctx.key_process = 1;
			if(app_impl.AuthenticateCallback) {
				app_impl.AuthenticateCallback(MATCH_FAIL, 0xffff, 0x00);
			}
			MALOGE("match fail");
		} else {
			project_ctx.key_process = 1;
			if(app_impl.AuthenticateCallback) {
				app_impl.AuthenticateCallback(MATCH_SUCCESS, auth_fid, 0x00);
			}
			MALOGD("match ok id = %x",auth_fid);
		}

	}
}

#ifndef FP_OPERATION_ENABLE
void BSP_touch_process( void * param )
{
	platform_board_restore();

	if(isLowBatWarn()) {
		project_ctx.is_low_battery = 1;
		app_impl.send_handle_msg(MSG_BAT_LOW_WARN, NULL);
#if BT_PROTOCOL_DRAGONPAL == 0
		platform_bluetooth_standby();
		mafp_powerdown_mode();
		wake_lock_timeout(10);
		return;
#endif
	} else {
		project_ctx.is_low_battery = 0;
	}

	wake_lock_timeout(15);

	switch(g_fsm_state){
		case STATE_IDLE:
			authentication_work();
			break;
		case STATE_ENROLL:
			enroll_work();
			break;
	}

	while(!detectFingerLeave() && !project_ctx.uart_process) {   //fix touch block uart capture process
		platform_watchdog_get_count();
		platform_msleep(20);
	}
	mafp_powerdown_mode();
}

#else
void defaultEnrollCallback(u8 step)
{	
	MALOGD("step %d", step);
}

int8_t setup_enroll(void) 
{
	uint16_t i;
	
	mafp_cancel_enroll();
	for(i = 0; i < FINGER_NUM; i++) {
        	if(!mafp_get_enrollid_status(i)) {
            	break;
			}
	}
	if(i >= FINGER_NUM) {
		return -1;
	}
	Enroll_Tag.enroll_id = i;
	Enroll_Tag.enroll_press_times = DEFAULT_ENROLL_TIMES;
	Enroll_Tag.enroll_timeout = ENROLL_TIMEOUT_DEFAULT;
	Enroll_Tag.enroll_cb = defaultEnrollCallback;

	MALOGD("enroll fid %d", Enroll_Tag.enroll_id);

	g_fsm_state = STATE_ENROLL;
	Enroll_Tag.start_tick = platform_timer_us_tick();
	return 0;
	
}

int8_t idle_work(void)
{
	uint8_t press_second = 0;
	uint32_t cnt_tick = 0;
	int32_t auth_fid;
	int8_t ret;
	uint8_t need_auth = 0, authticated = 0;
	uint8_t retry_time = 3;

	cnt_tick = platform_timer_ms_tick();
	while(!detectFingerLeave()) {
		platform_watchdog_get_count();
		press_second = (platform_timer_ms_tick() - cnt_tick) / 1000;
		if(press_second < TIME_TO_ENROLL) {
			g_fsm_state = STATE_IDLE;
		} else if(press_second >= TIME_TO_ENROLL && press_second < TIME_TO_DELETE) {
			platform_led_start_warn(LLED_GREEN, LED_LIGHT, 2);
			g_fsm_state = STATE_ENROLL;
			if(project_ctx.hasfp) need_auth = 1;
		} else if(press_second >= TIME_TO_DELETE) {
			platform_led_start_warn(LLED_RED, LED_LIGHT, 2);
			g_fsm_state = STATE_DELETE;	
			if(project_ctx.hasfp) need_auth = 1;
		}
		platform_msleep(20);
	}

	if(need_auth && (g_fsm_state == STATE_ENROLL || g_fsm_state == STATE_DELETE)) {
		MALOGD("do verify....");
		cnt_tick = platform_timer_ms_tick();
		do {

			while(!detectFinger()) {
				platform_watchdog_get_count();
				platform_msleep(20);
			}
			cnt_tick = platform_timer_ms_tick() - cnt_tick;
			if(cnt_tick > MATCH_TIMEOUT_DEFAULT) {
				break;
			}
			
			auth_fid = mafp_authenticate_v2();
			if(auth_fid != ERR_FP_MATCH_FAILED) {  //ensure administrator
				authticated = 1;
				platform_led_start_warn(LLED_GREEN, LED_FLASH_BLINK, 2);
				MALOGD("verify pass %x", auth_fid);
				break;
			} else {
				platform_led_start_warn(LLED_RED, LED_FLASH_BLINK, 2);
				MALOGD("verify failed,retry %d", retry_time);
			}

			while(!detectFingerLeave()) {
				platform_watchdog_get_count();
				platform_msleep(20);
			}
		}while(--retry_time);
	}
	
	if(g_fsm_state == STATE_DELETE && (authticated || !need_auth)) {
		MALOGD("delete all fid");
		mafp_clear_all_enrollids();
		g_fsm_state = STATE_IDLE;
	} else if(g_fsm_state == STATE_ENROLL && (authticated || !need_auth)) {
		MALOGD("start to enroll");
		ret = setup_enroll();
		if(ret != 0) g_fsm_state = STATE_IDLE;
	} else if(need_auth && !authticated) {
		g_fsm_state = STATE_IDLE;
	}

	return g_fsm_state;
}

void BSP_touch_process( void * param )
{
	platform_board_restore();

	if(isLowBatWarn()) {
		mafp_powerdown_mode();
		app_impl.send_handle_msg(MSG_BAT_LOW_WARN, NULL);
		wake_lock_timeout(10);
		return;
	}

	get_wake_lock();

	MALOGD("dog_feed_count= %d wakeup_times =%d",platform_watchdog_get_count(), wakeup_times++);

	switch(g_fsm_state){
		case STATE_IDLE:
			authentication_work();
			if(project_ctx.key_process) {
				idle_work();
				project_ctx.key_process = 0;
			}
			break;
		case STATE_ENROLL:
			enroll_work();
			break;
	}

	while(!detectFingerLeave() && !project_ctx.uart_process) {  //fix touch block uart capture process
		platform_watchdog_get_count();
		platform_msleep(20);
	}
	
	release_wake_lock();
	wake_lock_timeout(15);
	mafp_powerdown_mode();
}	
#endif

void BSP_bluetooth_process( void * param )
{
	uint8_t bt_buff[FRAME_LENGTH];
	u8 data_len;
	uint8_t* ptrbuff = (uint8_t *)param;

	data_len = ptrbuff[0];
	
	memcpy(bt_buff, ptrbuff + 1, data_len);
	g_packet_type = TYPE_BT_PACKAGE;
	MALOGD("receiver frame head is : 0x%x%x, checksum : 0x%x", bt_buff[0], bt_buff[1], bt_buff[data_len -1]);
	if(bt_buff[0] == (FRAME_START >> 8) && bt_buff[1] == (FRAME_START & 0x00ff))
	{
		maFsmTask_v2(bt_buff, data_len);
	}
	else if(bt_buff[0] == (MMITEST_FRAME_START >> 8) && bt_buff[1] == (MMITEST_FRAME_START & 0x00ff))
	{
		FactoryTestTask(bt_buff);
	}
#if BT_PROTOCOL_WHEATEK
	else if(bt_buff[0] == (WH_FRAME_START >> 8) && bt_buff[1] == (WH_FRAME_START & 0x00ff))
	{
		wheatekFsmTask(bt_buff);
	}
#endif
#if BT_PROTOCOL_DRAGONPAL
	else if(data_len == DG_FRAME_LENGTH) {
		dragonFsmTask(bt_buff, data_len);
	}
#endif

	
}

void BSP_uart_process( void * param )
{
	u8 uart_buff[FRAME_MOST_LEN];
	u8 data_len;
	uint8_t* ptrbuff = (uint8_t *)param;

	wake_lock_timeout(30);
	platform_touch_enable_interrupt(0);

	data_len = ptrbuff[0];
	if(data_len > FRAME_MOST_LEN)
	{
		MALOGE("uart frame size error! size is %d", data_len);
	}
	g_packet_type = TYPE_UART_PACKAGE;
	memcpy(uart_buff, ptrbuff + 1, data_len);
	//MALOGD("receiver frame head is : 0x%x%x, checksum : 0x%x", uart_buff[0], uart_buff[1], uart_buff[data_len -1]);
	if(uart_buff[0] == (FRAME_START >> 8) && uart_buff[1] == (FRAME_START & 0x00ff))
	{
		maFsmTask_v2(uart_buff, data_len);
	}
	
	platform_touch_enable_interrupt(1);
	project_ctx.uart_process = 0;
}

void BSP_uploadImage_process( void * param )
{
	switch(g_fsm_state) {
		case STATE_IDLE:
			break;
		case STATE_UPLOAD:
			wake_lock_timeout(20);
			fsmUpLoadTask();
			break;
		default:
			break;
	}
}

void BSP_usb_process(void * param)
{
	static u8 pre_usb = 0;

	platform_board_restore();
	wake_lock_timeout(15);
	
	if(detectUsbPlug_robust() && !pre_usb)
	{
		pre_usb = 1;
		MALOGD("USB plugin");
		get_wake_lock();
		app_impl.send_handle_msg(MSG_BAT_CHARGE, NULL);
	}
	else if(!detectUsbPlug_robust() && pre_usb)
	{
		pre_usb = 0;
		MALOGD("USB unplugin");
		release_wake_lock();
		Led_All_Off();
	}
    platform_usb_set_interrupt(1);  //ensure usb detect pin level is stable
}


void algorithm_init(void)
{
	u8 init_retry_times = 10;
	S32 res,bad_blocks;

	get_wake_lock();

	do	//ensure algorithm init success
	{
		res = mafp_init(&bad_blocks);
		if(res != 0)
		{
			platform_led_start_warn(LLED_RED, LED_LIGHT, 1);
			MALOGE("mafp, Res = %x", res);
#ifdef SENSOR_E120N
			//mafp_reset_templates_storage();
#endif
			res = mafp_reinit_sensor_parameters();
			if(res != 0)
			{
				MALOGE("alg init fail %x!", res);
			}
		}
		else
		{
			break;
		}

	}while(init_retry_times--);

	release_wake_lock();
}


void BSP_goto_Sleep(void * param)
{
   //进入休眠前释放定时器初始化
   MALOGD("lock task will sleep now");
   platform_msleep(20);
   platform_board_shutdown();

}

void status_printf(void * param) 
{
	/* status report per second*/
	MALOGD("PowerOfftimes=%d, bt_status=%d, isCharge=%d, chargefull=%d, hasfp=%d, press=%d, P16=%d",
	        PowerOfftimes, project_ctx.bt_status, isUsbPlugin(), isChargefull(), project_ctx.hasfp, isExtTouchPress(), isPin16High());
}

#ifdef CONFIG_BSP_DEBUG
void BSP_test_Func(void * param)
{
  // platform_bsp_test_func(NULL);
  platform_motor_unlock();
}
#endif

void Status_timer_isr(void)
{
	static uint8_t BurnCodeCounter = 0;
	
#if PERIPH_BT_ENABLE
	static uint8_t BT_connect_light = 0;
	/*do something when BT connect*/ 
	if(project_ctx.bt_status == BT_CONNECTED)   //BT breathing light controller
	{
		if(++BT_connect_light *  STATUS_PERIOD >= BT_BREATING_LNG)
		{
			BT_connect_light = 0;
			if(!g_BT_test_result) app_impl.send_handle_msg(MSG_BT_CONNECTED, NULL);
		}

		project_ctx.bt_connect_period--;
		if(!project_ctx.bt_connect_period) {
			platform_bluetooth_disconnect();
		}
		
	} 
	else if(project_ctx.bt_status == BT_ADV)   //BT breathing light controller
	{
		if(++BT_connect_light *  STATUS_PERIOD >= BT_BREATING_LNG)
		{
			BT_connect_light = 0;
			if(!g_BT_test_result) app_impl.send_handle_msg(MSG_BT_BRODCAST, NULL);
		}
	} 
#endif

	/*handler charge event*/
	if(isUsbPlugin() && isChargefull())
	{
		app_impl.send_handle_msg(MSG_BAT_FULL, NULL);
	}

	/*ensure LED off when usb unplugin*/
	if(!isUsbPlugin()) {
		if(LED_Status(LLED_GREEN)) LED_Off(LLED_GREEN);
	}

	/*determine when goto platform reset*/
	if(isUsbPlugin() && isPin16High())
	{
		BurnCodeCounter++;
		if(BurnCodeCounter >= BURN_CODE_DETECT_COUNT)
		{
			BurnCodeCounter = 0;
			MALOGD("reset");
			platform_sys_reset(1);
		}
	}
	else
	{
		BurnCodeCounter = 0;
	}

	/*check enroll whether timeout*/
	if(g_fsm_state == STATE_ENROLL)
	{
		if((Enroll_Tag.enroll_timeout>0) && (calculateTimeElapse(Enroll_Tag.start_tick) > Enroll_Tag.enroll_timeout))
		{
			Enroll_Tag.stop_flag = 1;
			lock_async_call_wrapper(BSP_touch_process, NULL);
		}
	}

	/*display BT test result, flash blue when success and flash red when failed until has touch or after 1min*/
	if(g_BT_test_result)
	{
		if(g_BT_test_result ==  1)
		{
			platform_led_start_warn( LLED_BLUE, LED_FLASH_BLINK, 2);
		}
		else if(g_BT_test_result == 2)
		{
			platform_led_start_warn( LLED_RED, LED_FLASH_BLINK, 2);
		}

		if(isExtTouchPress())
		{
			g_BT_test_result = 0;
			release_wake_lock();
		}
	}

	lock_async_call_wrapper(status_printf, NULL);
	
#ifdef CONFIG_BSP_DEBUG
	static uint32_t test_tick = 0;
	test_tick++;
	if(test_tick % 5 == 0) {
		lock_async_call_wrapper(BSP_test_Func, NULL);
	}
#else
	if(!wait_wake_lock()) lock_async_call_wrapper(BSP_goto_Sleep, NULL);
#endif

}


/***********************************************************************
  函数名称：timer_1ms_tick_func0
  函数功能: 时钟中断进入，间隔1ms扫描(led,motor,按键判断，倒计时判断，休眠倒计时，充电状态判断)
  入口参数：
  出口参数：
***********************************************************************/
void timer_1ms_tick_func0(void)
{
	static uint32_t timerCounter1 = 0;
	
    timerCounter1++;

/***
   1.Motor      ----  must implement function call Motor_timer_isr
   2.PMU        ----  must implement function call PMU_timer_isr
   3.Touch      ----  must implement function call Touch_timer_isr
   4.Ledflash   ----  must implement function call Ledflash_timer_isr
   5.Status     ----  must implement function call Status_timer_isr
   //must ensure no timedelay reference each call
	***/
	//PERI_TIMER_ISR(T_m.Tcnt, MOTOR_PERIOD, Motor);
	PERI_TIMER_ISR(timerCounter1, PMU_PERIOD, PMU);
	PERI_TIMER_ISR(timerCounter1, TOUCH_PERIOD, Touch);
	PERI_TIMER_ISR(timerCounter1, LED_PERIOD, Ledflash);
	PERI_TIMER_ISR(timerCounter1, BEEP_PERIOD, Beep);
	if(g_fsm_state != STATE_FACTORY_TEST) PERI_TIMER_ISR(timerCounter1, STATUS_PERIOD, Status);
}

void timer_1ms_tick_func1(void)
{
	static uint32_t timerCounter2 = 0;

    timerCounter2++;

	PERI_TIMER_ISR(timerCounter2, MOTOR_PERIOD, Motor);
#ifdef PLATFORM_BX2400
	PERI_TIMER_ISR(timerCounter2, UART_PERIOD, Uart); 
#endif
}

uint8_t touch_callback(void)
{
	lock_async_call_wrapper(BSP_touch_process , NULL);
	return 0;
}


uint8_t uart_receive_callback(uint8_t *buf, uint16_t size)
{
	uint8_t rx_lock_buf[256];

	project_ctx.uart_process = 1;

	rx_lock_buf[0] = size;
	memcpy(rx_lock_buf + 1, buf, size);
	memcpy(buf, rx_lock_buf, size + 1);
	lock_async_call_wrapper(BSP_uart_process , (void *)buf);
	return 0;
}

uint8_t motor_notify_callback(motorRunState state)
{
	//MALOGD("state %d", state);

	switch(state) {
		case STA_MOTOR_START:
			break;
		case STA_MOTOR_STOP:
			break;
		case STA_MOTOR_SHAFT:
			break;
		case STA_MOTOR_UNLOCK:
			break;
		case STA_MOTOR_LOCK:
			break;
		case STA_MOTOR_INTERVAL:
			break;
		case STA_MOTOR_FWD_DLY:
			break;
		case STA_MOTOR_BWD_DLY:
			break;
		default:
			break;
	}

	return 0;
}

uint8_t usb_detect_callback(void)
{	
	project_ctx.uart_process = 1;
	lock_async_call_wrapper(BSP_usb_process , NULL);
	return 0;
}

uint8_t bluetooth_receive_callback(bluetoothEvent event, uint8_t *buf, uint16_t size)
{
	uint8_t *status;

	if(size > FRAME_LENGTH) {
		MALOGE("out of range");
		return 1;
	}

	switch(event) {
		case EVT_BT_CNNT_STATE_CHG:
			status = (uint8_t*)buf;
			switch(*status) {
				case 0x00:
					if(g_fsm_state == STATE_ENROLL && project_ctx.bt_status == BT_CONNECTED) {
						Enroll_Tag.stop_flag = 1;
					}
					project_ctx.bt_status = BT_ADV;
					release_wake_lock();
					if(app_impl.send_handle_msg) app_impl.send_handle_msg(MSG_BT_DISCONNECTED, NULL);
					break;
				case 0x01:
					project_ctx.bt_status = BT_CONNECTED;
					get_wake_lock();
					if(app_impl.send_handle_msg) app_impl.send_handle_msg(MSG_BT_CONNECTED, NULL);
					project_ctx.bt_connect_period = 45; //45s
					break;
			}
			break;
		case EVT_BT_REV_BUF:
			g_receive_buff[0] = size;	
			memcpy(g_receive_buff + 1, buf, size);
			project_ctx.bt_connect_period = 45;
			lock_async_call_wrapper(BSP_bluetooth_process , (void *)g_receive_buff);
			break;
	}

	return 0;
}

void init_project_cortext(void)
{
	project_ctx.key_process = 0;
	project_ctx.uart_process = 0;
}

void BSP_initialize(void)
{
	bspFuncCallback g_func_callback;
	time_t timeStamp;

	g_func_callback.app_timer_1ms_tick_func0 = timer_1ms_tick_func0;
	g_func_callback.app_timer_1ms_tick_func1 = timer_1ms_tick_func1;
	g_func_callback.app_touch_callback = touch_callback;
	g_func_callback.app_uart_receive_callback = uart_receive_callback;
	g_func_callback.app_bluetooth_receive_callback = bluetooth_receive_callback;
	g_func_callback.app_usb_detect_callback =  usb_detect_callback;
	g_func_callback.bsp_motor_notify_callback = motor_notify_callback;
	platform_board_create( &g_func_callback);
	
	project_ctx.bsp_conf = &g_periph_config;
	load_bsp_property();
	platform_load_board_config(project_ctx.bsp_conf);
    init_project_cortext();
	algorithm_init();	
	initDeviceInfo();

	fsmInit();
	
#if PERIPH_BT_ENABLE

#if BT_PROTOCOL_WHEATEK
	wheatekfsmInit();
	app_impl.send_handle_msg = defaultApplicationImpl;
	app_impl.AuthenticateCallback = defaultAuthCallback;

#elif BT_PROTOCOL_DRAGONPAL
	dragonFsmInit(); 
	app_impl.send_handle_msg = dragonApplicationImplMode1;
	app_impl.AuthenticateCallback = dragonAuthCallback;

#else
	app_impl.send_handle_msg = defaultApplicationImpl;
	app_impl.AuthenticateCallback = defaultAuthCallback;
#endif

#else 
	app_impl.send_handle_msg = defaultApplicationImpl;
	app_impl.AuthenticateCallback = defaultAuthCallback;
#endif

	MALOGD("BSP_initialize");
	MALOGI("%s_%s", PROJECT_NAME, GIT_TAG);
	MALOGI("branch:%s", GIT_BRANCH);
	MALOGI("compile date: %s", COMPILE_DATE);
	MALOGI("compile user: %s@%s", GIT_USER, COMPILE_USER);

	lock_async_call_wrapper(BSP_usb_process , NULL);   //detect usb when usb reset mcu
	lock_async_call_wrapper(BSP_touch_process , NULL);

	timeStamp = platform_rtc_get_sys_time();
	if((timeStamp & 0x0f) == 0) { 
		app_impl.send_handle_msg(MSG_SYS_BOOT, NULL);
	}
}

