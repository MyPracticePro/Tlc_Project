/*
 * Bin library functions interface for user caller
 *
 * Copyright (C) 2017 Microarray Electronic Co., LTD.
 *
 * Written by:
 *     Hans.Huang  hux@microarray.com.cn
 *     
 * Hans.Huang    10/10/17     For external user call the functions
 */
#include "flash.h"
#include "sensor.h"
#include <stdint.h>
#include "algorithm_bin_interface.h"
#include "platform.h"
#include "wheatek.h"

/******************************* Call by algorithm bin *************************************/
#define lib_uartSendBuff         platform_uart_send_buff
#define lib_systemTick           platform_timer_ms_tick
#define lib_sensorRWReg          sensorRWReg
#define lib_sensorSetMode        sensorSetMode
#define lib_sensorReadLine       sensorReadLine
#define lib_sensorReadFrame      sensorReadFrame
#define lib_eflash_program       eflash_program_withkey
#define lib_eflash_bulk_program  eflash_bulk_program_withkey
#define lib_eflash_page_erase    eflash_page_erase_withkey
#define lib_spiflash_read        SPI_Flash_Read 
#define lib_spiflash_write       SPI_Flash_Write_Sectors

//__attribute__((section(".ARM.__at_0x00801080")))
int tmp_buf[43 * 1024 / 4] = {0x00};


/* Define a function array for init the peripheral device */
void *const bin_funcs_table[]  = {

    lib_uartSendBuff,
    lib_systemTick,
    lib_sensorRWReg,
    lib_sensorSetMode,
    lib_sensorReadLine,
    lib_sensorReadFrame,
	lib_eflash_program,
	lib_eflash_bulk_program,
    lib_eflash_page_erase,
    lib_spiflash_read,
    lib_spiflash_write
};


uint8_t algorithm_func_table_init(void)
{
	S32 res =1;

	binlib_init_data_bss_sections();
	binlib_dbg_en(0);

	tmp_buf[0] = 0x55AAEE44;
	tmp_buf[1] = 0xA5668899;
	binlib_init_buffer(tmp_buf,sizeof(tmp_buf));

	res = binlib_init(bin_funcs_table);		
	// enable BinLib debug, if needed
	//binlib_dbg_en(1);
	return res;	
}

uint8_t algorithm_sensor_init(void)
{
	u8 buff[2] = {0};
	uint8_t res;
	
	res = binlib_api(LIB_INIT_SENSOR, buff, 2);
	if (res) 
	{
		MALOGE("init sensor parameter failed!");	
	}
	else
	{				  
		res = binlib_init(bin_funcs_table);
		if(res != 0)
		{
			MALOGE(" bin_funcs_table res =%d",bin_funcs_table);
		}
	}

	return res;

}

int32_t mafp_get_chipid(void)
{
	return -1;
}

int32_t mafp_post_enroll(void)
{
	return -1;
}

int32_t mafp_post_authenticate(void)
{
	return -1;
}


int32_t mafp_get_enrollid_status(uint8_t enroll_id)
{
    uint8_t  group_buf[32] = {0x00};
    int32_t res           = 0;
    uint8_t  group_id      = 0;
    uint8_t  bit_index     = 0; 
    uint8_t  group_value   = 0x00;
    uint8_t  enroll_mask   = 0x00;

	res = binlib_api(LIB_READ_ID_LIST,group_buf,32);

    if (res == 0){

        /* Get the enroll mask group and mask  bit index */
        group_id    = enroll_id>>3;
        bit_index   = enroll_id%8;
        group_value = group_buf[group_id];
        enroll_mask = (group_value>>bit_index)&0x01;

        if (enroll_mask)
            return 1;
        else
            return 0;
        
    }else{
        return 0;
    }
    


    

}






int32_t mafp_get_used_enrollids(void)
{
    uint8_t  group_buf[32] = {0x00};
    uint8_t  i             = 0;
    uint8_t  j             = 0;
    uint8_t  totals        = 0;
    int32_t  res           = 0;

	res = binlib_api(LIB_READ_ID_LIST,group_buf,32);

    if (res == 0){
        for (i = 0; i < 32; i++){
            
            if (group_buf[i] == 0){
                continue;
            }

            
            for (j = 0; j < 8; j++){
                if ((group_buf[i]>>j)&0x01){
                    totals++;
                }
            }
        }
        return totals;
    }else{
        return 0;
    }
}


int32_t mafp_remove_enrollid(uint8_t enroll_id)
{
	uint8_t buff[4] = {0x00};

    
    buff[0]=(enroll_id>>8)&0xff;
    buff[1]=(enroll_id&0xff);
    buff[2]=0;
    buff[3]=0x01;

    
    if (binlib_api(LIB_DELETE_ID,buff,4) == 0)
    {
        return 0;
    }else{
        return -1;
    }

}


int32_t mafp_clear_all_enrollids(void)
{
	uint8_t buff[2] = {0x00};
	
	buff[0] = 1;
	if (binlib_api(LIB_INIT_SENSOR, buff, 2))
	{
		return -1;
	}
	else 
	{
		 return 0;
  }
}


int mafp_enroll_v2(u8 fid, const u8 max_enroll_times, const u8 stop_flag, void (*callback)(u8 event, u8 para))
{
	u8 temp_id;
	u8 buff[2] = {0x00};
	u8 ret;
	static u8 enroll_step = 0;

	if(stop_flag) {
		ret = SUCCESS_ENROLL_STOP;
		callback(SUCCESS_ENROLL_STOP, 0);
		goto enroll_uncomplete;
	} 

	MALOGD("fid = %d, step = %d, max_times = %d, stop = %d", fid, enroll_step, max_enroll_times, stop_flag);

	ret = binlib_api(LIB_PRE_ENROLL,NULL,0);
	if (ret == 0)
	{
		if(enroll_step  == 0) binlib_api(LIB_CLEAR_ENROLL_ALL_STEPS, NULL, 0);

		temp_id=(fid<<1)&0xfffe;
		buff[0]=(temp_id>>8)&0xff;
		buff[1]=(temp_id&0xff);
		ret=binlib_api(LIB_ENROLL,buff,2);
		if(ret == 0){
			enroll_step++;
			if(enroll_step < max_enroll_times)
			{
				callback(FP_LESS_ENROLL_NUM, enroll_step);
				ret = FP_LESS_ENROLL_NUM;
			}
			else
			{
				temp_id=(fid<<1)&0xfffe;
				temp_id|=0x01;
				buff[0]=(temp_id>>8)&0xff;
				buff[1]=(temp_id&0xff);
				ret=binlib_api(LIB_ENROLL,buff,2);
				if(ret == 0){
					enroll_step = 0;
					callback(SUCCESS_ENROLL, enroll_step);
					ret = SUCCESS_ENROLL;
				}
				else 
				{
					callback(ERR_FP_EROLL_DETECT, enroll_step);
					ret = ERR_FP_EROLL_DETECT;
					goto enroll_uncomplete;	
				}
			}
		}
		else 
		{
			callback(ERR_FP_EROLL_DETECT, enroll_step);
			ret = ERR_FP_EROLL_DETECT;
			goto enroll_uncomplete;	
		}
		
	}
	else
	{
		ret = FP_UNDETEC;
		//goto enroll_uncomplete;
	}

	while(binlib_api(LIB_IS_FINGERLEAVE,NULL,0));
	return ret;

enroll_uncomplete:
	binlib_api(LIB_CLEAR_ENROLL_ALL_STEPS, NULL, 0);
	enroll_step = 0;
	return ret;

}

int mafp_authenticate_v2(void)
{
    U8 buff[2] = {0};
	int ret;
	u8 retry_times = 1;
	unsigned int tick = 0;

	while(retry_times--)
	{
		ret=binlib_api(LIB_PRE_MATCH,NULL,0);
		if (ret == 1) {
			//MALOGD("image partial");
			ret =  ERR_FP_MATCH_FAILED;
		}  
		else if (ret == 0)
		{
		    tick = platform_timer_ms_tick(); 
			ret=binlib_api(LIB_MATCH,buff,2);
			tick = platform_timer_ms_tick() - tick;
			//MALOGD("auth time: %d", tick);
				/*
			 * ERROR_AUTH_NO_MOVE
			 * ERROR_AUTH_NO_MATCH
			 * ERROR_AUTH_ALGO_FAIL
			 * match_id
			 *
			 * */
			if(ret == 0 )
			{
			    //do matched action
				//MALOGD("match ok  id = %x",buff[1]); 		
				ret = buff[1];
	            //store unlock record below
	            //storeUnlockRecord(buff[1]);
	            break;
			}
			else
			{
				//match failed action
				//MALOGD("match failed");
				ret = ERR_FP_MATCH_FAILED;
				
			}
		}
	}
	return ret;
}

int32_t sensor_get_download_buf(uint8_t *name, uint8_t **dst_addr, uint32_t size)
{
	return -1;
}

int32_t sensor_save_download_buf(void)
{
	return -1;
}


int32_t sensor_enroll_image_testing(uint8_t fid)
{
	return -1;
}


int32_t sensor_authenticate_image_testing(void)
{
	return -1;
}


int32_t sensor_get_upload_image_buf(uint32_t idx, uint8_t **dst_addr)
{
	return -1;
}


int32_t sensor_get_upload_template_buf(uint32_t idx, uint8_t **dst_addr)
{
	return -1;
}


int32_t mafp_detect_mode(void)
{
	return -1;
}


int32_t mafp_get_max_subtpl_num(void)
{
	return -1;
}


int32_t mafp_reset_sensor_config(void)
{
	return -1;
}




int32_t sensor_upload_subtpls(void)
{
	return -1;
}

int32_t mafp_factory_init(void)
{
	return -1;
}


int32_t mafp_cancel_enroll(void)
{
	binlib_api(LIB_CLEAR_ENROLL_ALL_STEPS, NULL, 0);
	return 0;
}

int32_t mafp_finger_leave(void)
{
	return !binlib_api(LIB_IS_FINGERLEAVE,NULL,0);;
}

int32_t mafp_init(int32_t *bad_blocks)
{
	return algorithm_func_table_init();
}

int32_t mafp_reinit_sensor_parameters(void)
{
	return algorithm_sensor_init();
}

int32_t mafp_reset_templates_storage(void)
{
	return -1;
}

int32_t sensor_set_fid_used(uint8_t fid)
{
	return -1;
}

int32_t mafp_powerdown_mode(void)
{
	return 0;
}

int32_t mafp_finger_touch(void)
{
	return binlib_api(LIB_IS_FINGERLEAVE,NULL,0);;
}

