#ifndef FACTORY_TEST_BSP_H
#define FACTORY_TEST_BSP_H

#include "type_def.h"
#include "malog.h"
#include "Power.h"
#include "wheatek.h"

#define MMITEST_FRAME_START  0xA5A5
#define TEST_FRAME_LEGTH     20
#define TEST_CMD_POS         2
#define TEST_DATA_POS        3



	
#define MMI_TEST_OK       0x00
#define ERR_MMI_RESTORE   0x01
#define ERR_ADC           0x02
#define ERR_FP_ENROLL     0x03
#define ERR_FP_MATCH      0x04
#define ERR_TIMEOUT       0x0a
#define ERR_TOKEN         0x0b

#define CMD_START    0xF0
#define CMD_SUCCESS  0xF1
#define CMD_FAIL     0xF2


typedef enum  
{
	ALL_TEST = 0,
	INIT_SENSOR_TEST,
	ADC_TEST,
    LED_TEST,
    MOTOR_TEST,
    FP_TEST,
    BT_TEST,
    FACTORY_TEST_ITEM_NUM,
}factory_test_item;

typedef enum
{
	CMD_TEST_ALL_RES = 0xe1,
	CMD_INIT_SENSOR_RES,
	CMD_TEST_ADC_RES,
	CMD_TEST_LED_RES,
	CMD_TEST_MOTOR_RES,
	CMD_TEST_FP_ID_RES,
	CMD_TEST_FP_ENROLL_RES,
	CMD_TEST_FP_MATCH_RES,
	CMD_TEST_BT_RES,
	CMD_TEST_BT_RESULT_RES,
}MmiTestCmdRes;


typedef struct
{
    u8 item;
	void (*factoryTestCallback)(MmiTestCmdRes res, uint8_t result);
	u8 result;
}factory_test_t;


extern void Factory_test_process(void * param);
extern void FactoryTestTask(uint8_t const* frame);

#endif
