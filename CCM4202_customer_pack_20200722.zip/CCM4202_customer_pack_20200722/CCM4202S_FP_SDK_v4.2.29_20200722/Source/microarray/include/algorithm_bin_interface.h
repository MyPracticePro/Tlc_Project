#ifndef _ALGORITHM_BIN_INTERFACE_H_
#define _ALGORITHM_BIN_INTERFACE_H_

/************************************ Call by bin caller**********************************/
typedef enum
{
	LIB_READ_ID_LIST=0x01,
	LIB_PRE_ENROLL=0x02,
	LIB_PRE_MATCH=0x03,
	LIB_ENROLL =0x04,
	LIB_MATCH=0x05,
	LIB_DELETE_ID=0x06,
	LIB_IS_FINGERLEAVE=0x07,
	LIB_CLEAR_ENROLL_ALL_STEPS=0x08,
	LIB_INIT_SENSOR=0x0b,
	LIB_FRAME_MAX
} _Lib_Cmd;


#define FUNC_TABLE_START		(0x08014000UL)

#define FUNC(i)				(*(unsigned int *)(FUNC_TABLE_START + (i) * 4))


typedef int           (*lib_init_t)(void *const funcs_tab[]);
typedef unsigned char (*lib_api_t)(unsigned char cmd, unsigned char *buff, unsigned short buff_len);
typedef void          (*lib_timer_isr_t)(void);
typedef void          (*lib_dbg_en_t)(unsigned char en);
typedef void          (*lib_init_bss_and_data_section_t)(void);
typedef  int (*lib_set_buf_t)(int *ptr, int len);



#define binlib_init                     ((lib_init_t)FUNC(1))
#define binlib_api                      ((lib_api_t)FUNC(2))
#define binlib_timer_isr                ((lib_timer_isr_t)FUNC(3))
#define binlib_dbg_en                   ((lib_dbg_en_t)FUNC(4))
#define binlib_init_buffer              ((lib_set_buf_t)FUNC(5))
#define binlib_init_data_bss_sections   ((lib_init_bss_and_data_section_t)FUNC(6))

extern void *const bin_funcs_table[];
int32_t mafp_get_used_enrollids(void);

#endif /* end of _ALGORITHM_BIN_INTERFACE_H_ */
