#ifndef _TYPE_DEF_H_
#define _TYPE_DEF_H_
		
typedef unsigned char BYTE;
typedef signed char SBYTE;
typedef unsigned short USHORT;
typedef unsigned short WORD;
typedef short SHORT;
typedef unsigned int UINT;
typedef unsigned long DWORD;
typedef int INT;
typedef char CHAR;
typedef unsigned char BOOL;
typedef float FLOAT;
typedef double DOUBLE;

typedef unsigned char	u8;
typedef unsigned short	u16;
typedef unsigned int	u32;

typedef unsigned char	U8;
typedef unsigned short	U16;
typedef unsigned int	U32;


typedef signed char		s8;
typedef signed short	s16;
typedef signed int		s32;


typedef            signed char   S8;
typedef volatile unsigned char   VU8;

typedef            signed short  S16;
typedef volatile unsigned short  VU16;

typedef            signed int    S32;
typedef volatile unsigned int    VU32;

typedef unsigned char           uint8_t;
typedef unsigned short          uint16_t;
typedef unsigned int            uint32_t;       
typedef signed char             int8_t;
typedef short                   int16_t;
typedef int                     int32_t;
typedef unsigned long long      uint64_t;

typedef unsigned           int uintptr_t;



#endif

