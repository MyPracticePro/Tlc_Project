/**
 *
 * @file lock_task.h
 *
 * @brief The header file of lock_task.c
 *
 * Copyright (C) Apollo 2015-2016
 *
 */

#ifndef LOCK_TASK_H_
#define LOCK_TASK_H_
#include "type_def.h"
#include "malog.h"

#define LOCK_QUEUE_SIZE         15
#define LOCK_TASK_STACK_SIZE    1024

#ifndef PLATFORM_BX2400
#define OS_PRIORITY_LOCK_TASK   1
#define ASYNC_CALL_MSG_TYPE     0x10
#endif


typedef struct
{
    uint8_t type;
    void (*func)(void *);
    void *param;
}lock_async_call_queue_t;

typedef union
{
    uint8_t type;
    lock_async_call_queue_t async_call;
}lock_queue_t;


void lock_queue_create(void);
void oslock_task_create(void *param);
void oslock_async_call_handler(lock_async_call_queue_t *ptr);
void lock_async_call_wrapper(void (*func)(void *),void *param);
void oslock_task(void *params);
#endif
