/*
 * yale.h
 *
 *  Created on: 2018骞�鏈�1鏃�
 *      Author: li
 */


#ifndef __YALE_H__
#define __YALE_H__



#include"system.h"


extern void yaleFsmTask(S32 ch);


#endif
