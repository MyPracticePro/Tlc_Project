/*********************************************************************************************************
 ** file:	    fsm.h
 ** description:	ͷ�ļ�
 ** author:      li
 ** date :       2017/05/16
 ***********************************************************************************************************/

#ifndef __FSM_H__
#define __FSM_H__

#include "type_def.h"


#define FRAME_START     0xEF01
#define FRAME_PID       0x06
#define FRAME_STA_LEN   9


#define FRAME_LEN_HIGH  0x07
#define FRAME_LEN_LOW   0x08
#define FRAME_CRC 1



#define PID_COMMAND    0x01
#define PID_DATA       0x02
#define PID_LAST_DATA  0x08
#define PID_ACK        0x07
#define PID_DATA_ACK   0x09
#define PID_DEBUG_PRINT 0x0a
#define FRAME_MOST_LEN 256

#define MA_BT_ADV_LEN        11

typedef enum
{
	idle,
	busy,
	done,
	running,
	null
}_Status;


enum
{
	ENROLL =0x01 ,
	GEN_CHAR=0x02,
	BUFFERID_MATCH=0x03,
	SERACH=0x04,
	LOADCHAR=0x07,
	UPCHAR=0x08,
	DOWNCHAR=0x09,
	UPLOAD_IMAGE =0x0a,
	DOWN_IMAGE=0x0b,
	Delete_ID=0x0c,
	EMPTY_ID=0x0d,
	SET_SYS_PARA=0x0e,
	GET_SYS_PARA=0x0f,
	SET_PWD=0x12,
	VFY_PWD=0x13,
	GET_RANDOM=0x14,
	SET_ADDR=0x15,
	Delete_MULTI_ID=0x1c,
	GET_ID_NUM=0x1d,
	GET_ID_LIST=0x1f,
	INIT_SYSTEM=0x21,
	DEVICE_READY=0x22,
	HAND_SHAKE=0x23,
	CONFIG_ENROLL=0x24,               
	CONFIG_MATCH=0x25,
	INIT_SENSOR=0x26,
	SWITCH_PROTOCOL=0x27,
	RESET_SENSOR_CONFIG=0X28,
	FACTORY_TEST_VFY = 0x35,
	FACTORY_TEST = 0x36,
	READ_BOARD_CFG = 0x37,
	WRITE_BOARD_CFG = 0x38,
	DEBUG_PRINT_EN=0x40,
	DEBUG_PRINT_MODE=0x41,
	DEBUG_GET_PARA=0x42,
	DEBUG_UPLOAD=0x43,
	DEBUG_UPDATE=0x44,
	DEBUG_ENROLL_AFTER_DOWNLOAD=0x45,
	DEBUG_MATCH_AFTER_DOWNLOAD=0x46,
	DEBUG_RESET_TEMPLATE_STORAGE=0x47,
	DEBUG_READ_ALL_FLASH=0x48,
	DEBUG_READ_BURN_CODE_TIME=0x49,
	DEBUG_IS_FINGER_LEAVE=0x50,
	DEBUG_CHECK_DETECT_MODE=0x51,
	DEBUG_DOWNLOAD_DATA=0x52,
	DEBUG_RECEIVE_DATA=0x53,
	DEBUG_STORE_DATA=0x54,
	DEBUG_TEST_BUTTON1=0x55,
	DEBUG_TEST_BUTTON2=0x56,
	DEBUG_TEST_BUTTON3=0x57,
	DEBUG_TEST_BUTTON4=0x58,
	DEBUG_UPDATE_PRE_MOVE1=0x59,
	DEBUG_UPDATE_PRE_MOVE2=0x5a,
	FRAME_MAX
};


#define PS_OK                   0x00
#define PS_COMM_ERR             0x01
#define PS_GET_IMG_ERR          0x03
#define PS_GEN_CHAR_ERR         0x06
#define PS_NOT_SEARCHED         0x09
#define PS_ADDRESS_OVER         0x0b
#define PS_UP_CHAR_ERR          0x0d
#define PS_RECV_ERR             0x0e
#define PS_UP_IMG_ERR           0x0f
#define PS_DEL_TEMP_ERR         0x10
#define PS_CLEAR_TEMP_ERR       0x11
#define PS_INVALID_PASSWORD     0x13
#define PS_INVALID_REG          0x1a
#define PS_ENROLL_ERR           0x1e
#define PS_DEVICE_ADDR_ERR      0x20
#define PS_MUST_VERIFY_PWD      0x21
#define PS_PARAM_ERROR          0x22
#define PS_END_UPLOAD           0x23
#define PS_ID_ALREADY_EXIST     0x24
#define PS_NO_ERROR             0x25
#define PS_TIMEOUT              0x26
#define PS_DOWN_IMG_ERR         0x27
#define PS_COMMAND_ERR          0x28
#define PS_PID_ERR              0x29
#define PS_ENROLL_TIMES_WRONG   0x30
#define PS_UPDATE_FAIL          0x31
#define PS_SWITCH_PROTOCOL_FAIL 0x32
#define PS_RESPONSE             0x33
#define PS_GET_IMG_OK           0x34
#define PS_INITSEBSOR_ERR       0x35
#define PS_INITSYSTEM_ERR       0x36
#define PS_CLEAR_BADBLOCKS_ERR  0x37
#define PS_FINGER_EXIST         0x38
#define PS_DETECT_MODE_FAIL     0x39
#define PS_RECEIVEDATA_FAIL     0x3a
#define PS_STOREDATA_FAIL       0x3b
#define PS_ID_INEXIST           0x3c
#define PS_FRAME_LENGTH_ERR     0x3d
#define PS_FRAME_HEAD_ERR       0x3e

#define SYS_PARA_BAUDRATE	0x04
#define SYS_PARA_SECLVL		0x05
#define SYS_PARA_PACKLEN	0x06


#define FSM_EFLASH_CODE_SIZE  (SENSOR_DATA_OFFSET*1024)    //128K code


#define FSM_EFLASH1_BASE (EFM0_MAIN_BASEADDR)
#define FSM_EFLASH1_READ_START_ADDR  (FSM_EFLASH1_BASE + FSM_EFLASH_CODE_SIZE )
#define FSM_EFLASH1_READ_SIZE  (1 * 1024 * 1024 - FSM_EFLASH_CODE_SIZE)


#define FSM_SEND_DATA_IMAGE 0x01
#define FSM_SEND_DATA_EFLASH1_DATA 0x02


#define DEBUG_UPDATE_FLAG_FRE1 (0x01)
#define DEBUG_UPDATE_FLAG_FRE2 (0x02)

extern void fsmInit(void);
extern void fsmTask(S32 ch);
extern void deviceReady(void);
extern void fsmDebugPrint(const char *fmt, ...);
extern U8 SendData(char *name,U8 *buf,U32 len);
extern void maFsmTask_v2(uint8_t const* frame, uint8_t len);
extern void fsmUpLoadTask(void);

#define IS_MICROARRAY_COMPATIBLE_SYNOCHIP_VAILD_FUNC(THIS) (((THIS) == SWITCH_PROTOCOL)|| ((THIS) == HAND_SHAKE))



#endif
