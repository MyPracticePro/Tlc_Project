#ifndef BSP_PROPERITY_H
#define BSP_PROPERITY_H

#include "kg_utils.h"
#include "type_def.h"

#define BLE_NAME_LENGTH      24

#define UNLOCK_RECORD_ADDR  (USER_CFG_DATA_ADDR + 0x800)  //size 2K
#define UNLOCK_PER_ITEM_LEN     6
#define MAX_UNLOCK_ITEM  127


typedef struct {
	uint8_t policy;
	uint8_t ver;
	uint8_t mode;
	uint8_t adv;
	uint8_t interval;
	uint8_t duty;
	uint8_t hint;
	uint8_t adc;
	uint8_t block;
	uint8_t delay;
	uint16_t wait;
	uint8_t roll;
	uint8_t frun;
	uint8_t brun;
	uint8_t sflash;
	uint8_t qflash;
	uint8_t light;
	uint8_t breath;
	uint8_t bfreq;
	uint8_t reserved;
}ConfigBox_t;

typedef struct {
	uint8_t used;
	uint16_t fid;
	uint8_t attribute;
}fpContext;

typedef struct {
	ConfigBox_t configBox;
	fpContext fp_used_attr[20];
	uint8_t bt_adv_name[BLE_NAME_LENGTH + 1];
	tm_date  s_date;
	uint16_t saved;
}boardContext;


extern int8_t load_bsp_property(void);
extern int8_t update_bsp_property(ConfigBox_t* box);
extern int8_t storeUserCfgProp(void);
extern void storeUnlockRecord(uint8_t fid);
extern uint8_t getUnlockRecord(uint8_t* result, uint16_t* record_data_len, uint8_t get_num);
extern uint16_t getUnlockRecordNum(void);
extern uint8_t clearUnlockRecord(void);

#endif


