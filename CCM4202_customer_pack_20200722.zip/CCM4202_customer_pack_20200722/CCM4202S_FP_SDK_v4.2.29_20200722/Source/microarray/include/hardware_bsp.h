#ifndef HARDWARE_BSP_H
#define HARDWARE_BSP_H

#include "type_def.h"
#include "application_impl.h"
#include "bsp_property.h"


#define PERI_TIMER_ISR(x, t, f) if(x % t == 0) f##_timer_isr()

#define MAX_BLE_NAME_LEN    12
extern uint8_t UART_SVC_ADV_NAME[MAX_BLE_NAME_LEN];

#define BT_REV_BUFF_LENGTH        120
#define FRAME_LENGTH              20

#define STATUS_PERIOD             1000
#define BT_BREATING_LNG           5000

#define MATCH_TIMEOUT_DEFAULT           (30 * 1000 * 1000)
#define ENROLL_TIMEOUT_DEFAULT          (30 * 1000 * 1000)

#define TIME_TO_ENROLL   5
#define TIME_TO_DELETE   8

typedef struct
{
	uint8_t enroll_id;
	uint8_t enroll_press_times;
	uint8_t stop_flag;
	uint8_t enroll_cmd; 
	uint32_t enroll_timeout;
	uint32_t start_tick;
	void (*enroll_cb)(u8 step);
	uint8_t result;
}_EnrollTag;

typedef struct
{
	U8 match_id;
	U32 match_timeout;
	uint32_t start_tick;
	U16 match_time;
	U8 isShow_timeoutInfo;
	U8 match_cmd;
	U32 matchTimeStart;
	U32 mathcTimeEnd;
}_MatchTag;

typedef enum
{
	MATCH_SUCCESS = 0,
	MATCH_FAIL,
}MatchResult;

typedef struct {
	int8_t (*send_handle_msg)(app_event_t msg, void* data);
	void (*AuthenticateCallback)(MatchResult state, int16_t fid, int16_t levl);
}application_impl_func;

extern void BSP_initialize(void);
extern void BSP_uart_process( void * param );
extern void BSP_touch_process( void * param );
extern void BSP_uploadImage_process( void * param );

#endif
