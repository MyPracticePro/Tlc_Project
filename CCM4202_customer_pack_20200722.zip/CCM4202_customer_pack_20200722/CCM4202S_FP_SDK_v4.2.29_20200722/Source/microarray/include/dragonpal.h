#ifndef DRAGON_PAL_H
#define DRAGON_PAL_H

#include "platform.h"
#include "system.h"

#define DG_FRAME_PID_HIGH   0
#define DG_FRAME_PID_LOW    1
#define DG_FRAME_LENGTH     16
#define DG_MAX_FRAMES       5

#define DG_OK                   0x00
#define DG_PWD_ERR              0x01
#define DG_FAIL                 0x02
#define DG_FRAME_LENGTH_ERR     0x3d
#define DG_CHK_TOKEN_ERR        0x3e

#define DG_AES_KEY_ADDR      0x8ff
#define DG_UNLOCK_PWD_ADDR   0x8ef

#define DG_BT_ADV_LEN        17
#define AES_KEY_LEN          16

#define DG_USER_DATA_FLASH_ADDR    0x8023000

#define CMD_RES(cmd) ((0xff00 - (cmd & 0xff00)) + (cmd & 0xff)) 

#define DG_FRAME_DECRYPT  

#define DG_UNLOCK_ITEM_LEN  8

#define DG_ENROLL_TIMES 6

typedef enum {
    CMD_DG_QUERY_DBG = 0x0000,
    CMD_DG_OPEN_DBG,
    CMD_DG_CLOSE_DBG,
    CMD_DG_INTERACT_DBG,

	CMD_DG_WR_FACTORY_CFG = 0x0100,
	CMD_DG_RD_FACTORY_CFG,

	CMD_DG_WR_USER_DATA = 0x0200,
	CMD_DG_RD_USER_DATA,

	CMD_DG_WR_TOKEN = 0x0300,

	CMD_DG_SET_DATE = 0x1000,
	CMD_DG_GET_DATE,
	CMD_DG_GET_BAT = 0x1100,
	CMD_DG_MOD_BT_NAME = 0x1200,
	CMD_DG_MOD_AES_SKEY_L = 0x1300,
	CMD_DG_MOD_AES_SKEY_H,
	CMD_DG_MOD_UNLOCK_PWD_O = 0x1400,
	CMD_DG_MOD_UNLOCK_PWD_N,
	
	CMD_DG_UNLOCK = 0x2000,
	CMD_DG_LOCK,
	CMD_DG_LOCK_MUAL,
	CMD_DG_GET_LOCK_STE,

	CMD_DG_SYSTEM_RESET = 0x2100,

	CMD_DG_GET_FINGER_NUM = 0x3000,
	CMD_DG_GET_FP_ATTR,
	CMD_DG_MOD_FP_ATTR,
	CMD_DG_FP_ENROLL,
	CMD_DG_FP_ENROLL_CANCEL,
	CMD_DG_FP_AUTHENTICATE,
	CMD_DG_FP_DELETE,
	CMD_DG_FP_CALIBRATE,

	CMD_DG_GET_RECORD_NUM = 0x6000,
	CMD_DG_GET_RECORD,
	CMD_DG_GET_RECORD_2,
	CMD_DG_CLR_RECORD,
	CMD_DG_GET_FROZEN,
	CMD_DG_GET_FROZEN_2,

	CMD_DG_COMM = 0x7f00,
}DragonCmd;

typedef struct {
	uint8_t aes_skey[AES_KEY_LEN];
	int8_t  g_pwd[6];
	uint16_t saved;
}dragonPrivateZone;

extern void dragonFsmTask(uint8_t const* frame, uint8_t len);
extern void dragonFsmInit(void);
extern void dragonAuthCallback(MatchResult state, int16_t fid, int16_t levl);


#endif
