#ifndef _QUEUE_H_
#define _QUEUE_H_

#include "lock_task.h"

#define MinQueueSize    5   //最小队列元素

typedef lock_queue_t elementType;

typedef struct queueRecord
{
    int capacity;   //队列的最大容量
    int front;  //队首元素下标
    int rear;   //队尾元素下标
    int size;   //队列有多少元素
    elementType *array; //指向动态分配的内存
}QUEUE;

int isEmpty(QUEUE *q);      //判空
int isFull(QUEUE *q);       //判满
QUEUE *createQueue(int maxElements, void *array, QUEUE *q);    //创建一个队列
void disposeQueue(QUEUE *q);    //销毁一个队列
void makeEmpty(QUEUE *q);   //构造一个空队列
void enQueue(QUEUE *q, elementType element);    //入队
elementType *front(QUEUE *q);        //返回队首元素但不删除
void deQueue(QUEUE *q); //删除队首元素不返回
elementType *frontAndDequeue(QUEUE *q);  //出队，返回并删除

#endif
