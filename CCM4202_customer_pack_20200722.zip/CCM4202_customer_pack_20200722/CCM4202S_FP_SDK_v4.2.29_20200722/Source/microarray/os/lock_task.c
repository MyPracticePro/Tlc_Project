/**
 *
 * @file lock_task.c
 *
 * @brief This file mainly packed ble system into a lock_task task.
 *
 *
 */
#include "lock_task.h"
#include "malog.h"
#include "hardware_bsp.h"

#ifdef PLATFORM_BX2400
#include "osapp_task.h"
#include "osapp_config.h"
#include "task_init.h"
TaskHandle_t handler_oslock_task;
#endif

#ifdef PLATFORM_AC693X
#include "system/task.h"
#endif


StackType_t stack_oslock_task[LOCK_TASK_STACK_SIZE];
StaticTask_t env_oslock_task;
QueueHandle_t lock_q;

#ifdef PLATFORM_AC693X
bool msg_send(QueueHandle_t q,void *data,uint32_t xTicksToWait)
{
    return xQueueSend(q,data,xTicksToWait);
}

bool msg_send_isr(QueueHandle_t q,void *data)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    bool retval = xQueueSendFromISR(q,data,&xHigherPriorityTaskWoken);
    if(retval)
    {
       portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
    }
    return retval;
}
#endif

static void lock_queue_async_call_send(lock_async_call_queue_t *async,uint32_t xTicksToWait)
{
    msg_send(lock_q,async,xTicksToWait);
}

static void lock_queue_async_call_send_isr(lock_async_call_queue_t *async)
{
    msg_send_isr(lock_q,async);
}

void lock_async_call_wrapper(void (*func)(void *),void *param)
{
    lock_async_call_queue_t async = 
    {
        .type = ASYNC_CALL_MSG_TYPE,
        .func =func,
        .param = param,
    };
#ifdef PLATFORM_BX2400
    if(in_interrupt())
    {
        lock_queue_async_call_send_isr(&async);
    }
    else
    {
        lock_queue_async_call_send(&async,portMAX_DELAY);
    }
#else
	lock_queue_async_call_send(&async,portMAX_DELAY);
#endif
}

void oslock_async_call_handler(lock_async_call_queue_t *ptr)
{
    ptr->func(ptr->param);
}

void lock_queue_create(void)
{
    static StaticQueue_t lock_q_env;
    static uint8_t lock_q_buf[LOCK_QUEUE_SIZE*sizeof(lock_queue_t)];
    lock_q = xQueueCreateStatic(LOCK_QUEUE_SIZE,sizeof(lock_queue_t),lock_q_buf,&lock_q_env);
}

void oslock_task_create(void *param)
{
#ifdef PLATFORM_BX2400
    handler_oslock_task = xTaskCreateStatic(oslock_task,"OSLOCK TASK",LOCK_TASK_STACK_SIZE,
            param,OS_PRIORITY_LOCK_TASK,stack_oslock_task,&env_oslock_task);
#endif

#ifdef PLATFORM_AC693X
	task_create(oslock_task, NULL, "lock_task");
	lock_queue_create();
#endif
}

void oslock_task( void * params )
{

#ifdef PLATFORM_AC693X
    log_i("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    log_i("         oslock_task start");
    log_i("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
#endif

	BSP_initialize();
    while( 1 )
    {

        lock_queue_t data;
        if(xQueueReceive(lock_q,&data,portMAX_DELAY)!=pdPASS)
        {
#ifdef PLATFORM_BX2400
            BX_ASSERT(0);
#endif
        }


        switch (data.type)
        {
            case ASYNC_CALL_MSG_TYPE:
            {
                lock_async_call_queue_t *async = &data.async_call;
                oslock_async_call_handler(async);
            }
            break;

            default:
                break;
        }

    }
}

