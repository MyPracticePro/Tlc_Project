#include "cyclone_queue.h"
#include "lock_task.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

QUEUE *lock_q;


static void lock_queue_async_call_send(lock_async_call_queue_t *async,uint32_t xTicksToWait)
{
	lock_queue_t sync;
	sync.type = ASYNC_CALL_MSG_TYPE;
	memcpy(&sync.async_call, async, sizeof(lock_async_call_queue_t));

    enQueue(lock_q, sync);
}

void lock_async_call_wrapper(void (*func)(void *),void *param)
{
    lock_async_call_queue_t async = 
    {
        .type = ASYNC_CALL_MSG_TYPE,
        .func =func,
        .param = param,
    };

	lock_queue_async_call_send(&async,0xffffffff);
}


void oslock_async_call_handler(lock_async_call_queue_t *ptr)
{
	MALOGD("%x", ptr->func);
    ptr->func(ptr->param);
}


void lock_queue_create(void)
{
    static QUEUE lock_q_env;
    static uint8_t lock_q_buf[LOCK_QUEUE_SIZE*sizeof(lock_queue_t)];
    lock_q = createQueue(LOCK_QUEUE_SIZE,lock_q_buf,&lock_q_env);
}

void oslock_task_create(void *param)
{
	lock_queue_create();
}


void oslock_task( void * params )
{

    while( 1 )
    {
        if(isEmpty(lock_q))
        {
			return ;
        }
	
		lock_queue_t *data;
		data = frontAndDequeue(lock_q);
		if(data == NULL) {
			return;
		}

        switch (data->type)
        {
            case ASYNC_CALL_MSG_TYPE:
            {
                lock_async_call_queue_t *async = &data->async_call;
                oslock_async_call_handler(async);
            }
            break;

            default:
                break;
        }

    }
}

