/*
 *  Beep.c
 *
 *  Created on: 2020/07/13
 *      Author: Young
 */

#include "Beep.h"
#include "platform.h"

BEEP s_beep;

void BeepInit(void)
{
	s_beep.time = 0;
	s_beep.mode = BEEP_MODE;
	s_beep.status = BEEP_IDLE;
}


 void SetBeep_Alarm(uint8_t time)
{
	s_beep.time = time; 
	s_beep.status = BEEP_START;
	if(s_beep.mode) s_beep.duration = BEEP_DURA_PER_TIME;
}

void SetSpeaker_Voice(Voice_t voice)
{
	platform_beep_start();
	s_beep.mode = 0;
	s_beep.time = 1;
	s_beep.duration = voice * BEEP_DUTY * 2;
	s_beep.status = BEEP_START;
}

void Beep_timer_isr(void)
 {
	static uint16_t tick;
	uint16_t interval;

	
	switch(s_beep.status) {
		case BEEP_START:
			tick = 0;
			s_beep.status = BEEP_ALARM;
			break;
		case BEEP_ALARM:
			if(s_beep.mode && !tick) {
				platform_beep_start_pwm();
			} else {
				
				if((tick % BEEP_DUTY) == 0)  platform_beep_toggle();
			}
			tick++;
			if(tick > s_beep.duration) {
				s_beep.status = BEEP_INT;
				tick = 0;
				if(s_beep.mode) platform_beep_stop_pwm();
			}
			break;
		case BEEP_INT:
			tick++;
			if(s_beep.mode) interval = BEEP_INT_DURA + BEEP_DURA_PER_TIME;
			else interval = BEEP_INT_DURA;
		
			if((tick % interval) == 0) {
				if(--s_beep.time) {
					tick = 0;
					s_beep.status = BEEP_ALARM;
				} else {
					s_beep.status = BEEP_STOP;
				}
			}
			break;
		case BEEP_STOP:
			s_beep.status = BEEP_IDLE;
			break;
		case BEEP_IDLE:
			break;
	}
 }


