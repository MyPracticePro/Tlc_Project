/*
 *  Led.c
 *
 *  Created on: 2018/12
 *      Author: john
 */

#include "extLed.h"
#include "platform.h"

volatile LED leds[LED_NUM];
led_breath_t breath_var;

ledConfig *led_conf;

void LedInit(ledConfig *conf)
{
    u8 i;
	
	//MALOGD("flash_speed = %d, light_duration = %d", conf->flash_speed, conf->light_duration);
	led_conf = conf;

	for(i=0; i<LED_NUM; i++)
	{
		leds[i].status = LED_OFF;
		leds[i].pre_status = LED_OFF;
		leds[i].duration = 0;
	}

	//default  pull up	
	Led_All_Off();
}

void LED_On(uint8_t type)
{
	platform_led_set_value(type, LIGHT);
	leds[type].status = LED_ON;
}

void LED_Breath(uint8_t type)
{
	leds[type].duration = led_conf->breath_half_dura;
	leds[type].status = LED_BREATH;
}

void LED_Off(uint8_t type)
{	
	if(type == LLED_MIXED) {
		switch(leds[LLED_MIXED].status) {
			case LED_ALTERNATE_RG:
				platform_led_set_value(LLED_RED, OFF);
				platform_led_set_value(LLED_GREEN, OFF);
				leds[LLED_MIXED].status = LED_OFF;
				break;
			case LED_ALTERNATE_RB:
				platform_led_set_value(LLED_RED, OFF);
				platform_led_set_value(LLED_BLUE, OFF);
				leds[LLED_MIXED].status = LED_OFF;
				break;
			case LED_ALTERNATE_GB:
				platform_led_set_value(LLED_GREEN, OFF);
				platform_led_set_value(LLED_BLUE, OFF);
				leds[LLED_MIXED].status = LED_OFF;
				break;
			case LED_WATER_FLOW:
				Led_All_Off();
				break;
		}
	} else {
		platform_led_set_value(type, OFF);
		leds[type].status = LED_OFF;
	}
	memset(&breath_var, 0x00, sizeof(led_breath_t));
}

void LED_On_dur(uint8_t type)
{
	platform_led_set_value(type, LIGHT);
}

u8 LED_Status(uint8_t type)
{
	return platform_led_get_state(type) && leds[type].status != LED_LIGHT && leds[type].status != LED_FLASH && leds[type].status != LED_BREATH
		   && leds[type].status != LED_ALTERNATE_RG && leds[type].status != LED_ALTERNATE_RB && leds[type].status != LED_ALTERNATE_GB
		   && leds[type].status != LED_WATER_FLOW;  
}

void LED_toggle(uint8_t type)
{
	static uint8_t cur_type = 0, tick = 1;
	uint8_t pre_type;

	if(type != LLED_MIXED) platform_led_toggle(type);
	else {
		if((++tick % 2) == 0) {
			tick = 0;
			pre_type = cur_type;
			switch(leds[LLED_MIXED].status) {
				case LED_ALTERNATE_RG:
					cur_type = (cur_type == LLED_RED) ? LLED_GREEN : LLED_RED;
					break;
				case LED_ALTERNATE_RB:
					cur_type = (cur_type == LLED_RED) ? LLED_BLUE : LLED_RED;
					break;
				case LED_ALTERNATE_GB:
					cur_type = (cur_type == LLED_GREEN) ? LLED_BLUE : LLED_GREEN;
					break;
				case LED_WATER_FLOW:
					//cur_type = (cur_type < LLED_BLUE) ? cur_type++ : LLED_RED;
					break;
			}
		}
		platform_led_set_value(pre_type, OFF);
		platform_led_toggle(cur_type);
	}
}

void Led_All_Off(void)
{
	u8 i;

	for(i=0; i<LED_NUM - 1; i++)
	{
		LED_Off(i);
	}
}

void SetLedBeep_Status(uint8_t type, LED_status status, int time)
{
	u8 j;
	uint8_t  flash_type ;

	//MALOGD("flash_speed = %d, light_duration = %d", conf->flash_speed, conf->light_duration);

	//step 1: if have led is light on, it will be off temporary
	for(j=0; j<LED_NUM; j++)
	{
		if(leds[j].status == LED_FLASH || leds[j].status == LED_LIGHT || leds[j].status == LED_ALTERNATE_RG 
		|| leds[j].status == LED_ALTERNATE_RB || leds[j].status == LED_ALTERNATE_GB || leds[j].status == LED_WATER_FLOW)
		{
			if(j < type) return;    //ensure just one led on light all the time,priority is RED>GREEN>BLUE
			else {
				if(leds[j].status == LED_FLASH && leds[j].always_on) {
					leds[j].pre_status = leds[j].status;	
				}
				LED_Off(j);
			}
		}
	
		if(leds[j].status == LED_ON || leds[j].status == LED_BREATH) 
		{
			leds[j].pre_status = leds[j].status;
			LED_Off(j);
		}
	}

	
	if(status == LED_FLASH_SLOW) {
		flash_type = 0;
		status = LED_FLASH;
	} else if(status == LED_FLASH_BLINK) {
		flash_type = 1;
		status = LED_FLASH;
	}
	leds[type].status = status;
	switch(leds[type].status) {
		case LED_FLASH:
			leds[type].flash_type = flash_type;
			if(flash_type == 0) {
				if(time == 0xffff) {
					leds[type].always_on = 1;
					leds[type].duration = 0xffff;
				} else {
					leds[type].always_on = 0;
					leds[type].duration = (time * led_conf->flash_slow_dura * 2) / LED_PERIOD;
				}
			} else {
				if(time == 0xffff) {
					leds[type].always_on = 1;
					leds[type].duration = 0xffff;
				} else {
					leds[type].always_on = 0;
					leds[type].duration = (time * led_conf->flash_fast_dura * 2) / LED_PERIOD;
				}
			}
			break;
		case LED_LIGHT:
			leds[type].duration = (time * led_conf->light_dura) / LED_PERIOD;
			break;
		case LED_BREATH:
			leds[type].duration = time;
			break;
		case LED_ALTERNATE_RG:
		case LED_ALTERNATE_RB:
		case LED_ALTERNATE_GB:
		case LED_WATER_FLOW:
			if(time == 0xffff) {
				leds[LLED_MIXED].always_on = 1;
				leds[LLED_MIXED].duration = 0xffff;
			} else {
				leds[LLED_MIXED].always_on = 0;
				leds[LLED_MIXED].duration = (time * led_conf->flash_slow_dura * 2) / LED_PERIOD;
			}
			break;
	}

	//MALOGD("status = %d, duration = %d", leds[type].status, leds[type].duration);
}

void Ledflash_timer_isr(void)		//ÿ100ms����һ��
{
	u8 i,j;
	uint16_t flash_speed;
	uint8_t bth_period;  //pwm period ms
	uint8_t bth_speed;   //duration per duty
	
	for(i=0; i<LED_NUM; i++)
	{
		if(leds[i].status == LED_LIGHT || leds[i].status == LED_FLASH || leds[i].status == LED_BREATH
		|| leds[i].status == LED_ALTERNATE_RG || leds[i].status == LED_ALTERNATE_RB || leds[i].status == LED_ALTERNATE_GB
		|| leds[i].status == LED_WATER_FLOW)
		{
			//step 2: implement light or flash action
			switch(leds[i].status)
			{
				case LED_LIGHT: 
					leds[i].duration--;
					if(leds[i].duration == 0)   
					{
						LED_Off(i);
					} else {
						LED_On_dur(i);
					}
					break;
				case LED_FLASH : 
					flash_speed = leds[i].flash_type ? (led_conf->flash_fast_dura / LED_PERIOD) : (led_conf->flash_slow_dura / LED_PERIOD);
					leds[i].duration--;
					if((leds[i].duration % flash_speed) == 0)  LED_toggle(i);
					if(leds[i].duration == 0)   
					{
						if(leds[i].always_on) {
							leds[i].duration = 0xffff;
						} else {
							LED_Off(i);
						}
					}
					break;
				case LED_BREATH:
					bth_speed = led_conf->breath_half_dura / led_conf->breath_freq;
					bth_period = led_conf->breath_freq;
					leds[i].duration--;
					if(leds[i].duration == 0) {
						leds[i].duration = led_conf->breath_half_dura;
					}
					if((leds[i].duration %  bth_period) == 0)  {
						if(leds[i].duration % bth_speed == 0) { 
							breath_var.direction ? breath_var.duty-- : breath_var.duty++;
							if(breath_var.duty >= bth_period) breath_var.direction = 1;
							else if(breath_var.duty <= 1) breath_var.direction = 0;
						}
						
						breath_var.duty_cnt = breath_var.duty ;
						if(breath_var.duty_cnt > 1 && breath_var.duty_cnt <= bth_period) {
							breath_var.flag = 1;
							LED_toggle(i);
						}
					}
					breath_var.duty_cnt--;
					if(breath_var.duty_cnt == 0 && breath_var.flag) {
						breath_var.flag = 0;
						LED_toggle(i);
					}
					break;
				case LED_ALTERNATE_RG:
				case LED_ALTERNATE_RB:
				case LED_ALTERNATE_GB:
				case LED_WATER_FLOW:
					flash_speed = led_conf->flash_slow_dura / LED_PERIOD;
					leds[LLED_MIXED].duration--;
					if((leds[LLED_MIXED].duration % flash_speed) == 0)  LED_toggle(LLED_MIXED);
					if(leds[LLED_MIXED].duration == 0)   
					{
						if(leds[LLED_MIXED].always_on) {
							leds[LLED_MIXED].duration = 0xffff;
						} else {
							LED_Off(LLED_MIXED);
						}
					}
				default:
					break;
			}

			//step 3:when led flash or light has finish,  restore led pre status
			if(leds[i].status == LED_OFF )//&& (leds[i].pre_status == LED_FLASH || leds[i].pre_status == LED_LIGHT)
			{
				for(j=0; j<LED_NUM; j++)
				{
					if(leds[j].pre_status == LED_ON) 
					{
						LED_On(j);
						leds[j].pre_status = LED_OFF;
					}

					if(leds[j].pre_status == LED_BREATH) 
					{
						LED_Breath(j);
						leds[j].pre_status = LED_OFF;
						memset(&breath_var, 0x00, sizeof(led_breath_t));
					}

					if(leds[j].pre_status == LED_FLASH) {
						leds[j].status = LED_FLASH;
						leds[j].always_on = 1;
						leds[j].duration = 0xffff;
						leds[j].pre_status = LED_OFF;
					}
				}
			}
		}
	} 
}


