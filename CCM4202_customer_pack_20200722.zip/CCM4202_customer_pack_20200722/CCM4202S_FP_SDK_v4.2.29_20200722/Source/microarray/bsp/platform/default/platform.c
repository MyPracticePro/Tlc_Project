#include "platform.h"
#include "boardConfig.h"
#include "globalvar.h"

periphConfig g_periph_config;
bspFuncCallback g_func_callback;
flash_space_t flash_space;


int32_t platform_create(periphConfig *config, bspFuncCallback *callback_table)
{	
	/*uart init*/
	
	/*function table init*/
	g_func_callback.app_timer_1ms_tick_func0 = callback_table->app_timer_1ms_tick_func0;
	g_func_callback.app_timer_1ms_tick_func1 = callback_table->app_timer_1ms_tick_func1;
	g_func_callback.app_touch_callback = callback_table->app_touch_callback;
	g_func_callback.app_uart_receive_callback = callback_table->app_uart_receive_callback;
	g_func_callback.app_usb_detect_callback = callback_table->app_usb_detect_callback;
	
	/*motor init */
	g_periph_config.motor_conf.forwardRun = config->motor_conf.forwardRun;
	g_periph_config.motor_conf.backwardRun = config->motor_conf.backwardRun;
	g_periph_config.motor_conf.interval = config->motor_conf.interval;


	/*LED init*/
	g_periph_config.led_conf.flash_speed = config->led_conf.flash_speed;
	g_periph_config.led_conf.light_duration = config->led_conf.light_duration;
	LedInit(&g_periph_config.led_conf);

	/*watchdog init*/
	platform_watchdog_start();

	/*PMU init*/
	

	/*timer init*/
	

	/*spi init*/
	

	/*touch init*/
	
	
	return 0;
}

uint8_t platform_restore(void)
{ 

	return 0;
}

uint8_t platform_shutdown(void)
{

	return 0;
}

uint8_t platform_destroy(void)
{
	return 0;
}

/*
 * Calc flash space plan for whole system, to solve the flash space confiliction among features
 * Flash space plan:
 * 1. properties
 * 2. backgroud image
 * 3. badpoints
 * 4. latest match record (1 pages)
 * 5. finger templates (2 pages)
 * 6. sensor configuration (1 page)
 */ 
int32_t init_flash_space(flash_space_t *space)
{
	int32_t page_size = EFLASH_PAGESIZE;
	int32_t bkg_size = IMAGE_T_SIZE*sizeof(uint8_t);
	int32_t badpoint_tab_size = sizeof(uint32_t)*(ECS64_BADPIXEL_NUM);

	space->prop_start = SENSOR_PROPERTY_ADDR;
	space->bkg_start = ROUND_UP(space->prop_start + sizeof(sensor_dyn_param_t), page_size);
	space->badpoint_start = ROUND_UP(space->bkg_start + bkg_size, page_size);
	space->match_rcrd_start = ROUND_UP(space->badpoint_start + badpoint_tab_size, page_size);
	space->templates_start = space->match_rcrd_start + page_size;
	space->sensor_cfg_start = space->templates_start + page_size * 2;
	space->subtpls_start = space->sensor_cfg_start + page_size;

	MALOGD("prop_start %x, bkg_start %x, badpoint_start %x, rcrd_start %x, templates_start %x, sensor_cfg_start %x, subtpls_start %x",
	     space->prop_start, space->bkg_start, space->badpoint_start, space->match_rcrd_start,
	     space->templates_start, flash_space.sensor_cfg_start, space->subtpls_start);

	if (space->subtpls_start > SUBTPLS_START_ADDR) {
		MALOGE("!!!!!!! Note : Flash overwrite, %x - %x.!!!!!!!!",
				space->subtpls_start, SUBTPLS_START_ADDR);
		return -2;
	}
	
	return 0;
}


int32_t platform_mafp_create(void)
{	
	// Init the flash usage plan
	if (init_flash_space(&flash_space)) {
		LOGE("plan failed");
		return ERROR_FLASH_CONFIG;
	}
	return 0;
}

int32_t platform_mafp_destroy(void)
{
	return 0;
}

int32_t platform_msleep(uint32_t ms)
{	
	
	return 0;
}


int8_t platform_motor_unlock(void)
{

	return 0;
}

void platform_motor_f_run(void)
{
	
}

void platform_motor_b_run(void)
{
	
}

void platform_motor_stop(void)
{
	
}

int8_t platform_watchdog_start(void)
{

	return 0;
}

int32_t platform_watchdog_get_count(void)
{
    return 0;
}

void platform_led_start_warn(uint8_t type, LED_status status, int time)
{
	
}

void platform_led_set_value(uint8_t led, uint8_t val)
{
	//MALOGD("led = %d, val = %d", led, val);
	switch(led){
		case LLED_RED:
			//gpio_set_val(LEDR_pin_num, val);
	 		break;
		case LLED_GREEN:
			//gpio_set_val(LEDG_pin_num, val);
	 		break;
		case LLED_BLUE:
			//gpio_set_val(LEDB_pin_num, val);
	 		break;
		default:
			break;
	}
}

uint8_t platform_led_get_state(uint8_t led)
{
	uint8_t state = 0;

	switch(led){
		case LLED_RED:
			//state = io_pin_read(LEDR_pin_num);
	 		break;
		case LLED_GREEN:
			//state = io_pin_read(LEDG_pin_num);
	 		break;
		case LLED_BLUE:
			//state = io_pin_read(LEDB_pin_num);
	 		break;
		default:
			break;
	}

	//MALOGD("led = %d, state = %d", led, state);

	return state == 0 ? LIGHT : OFF;
}

void platform_led_toggle(uint8_t led)
{
	switch(led){
		case LLED_RED:
			//GPIO_ToggleBits(LEDR_pin_num);
	 		break;
		case LLED_GREEN:
			//GPIO_ToggleBits(LEDG_pin_num);
	 		break;
		case LLED_BLUE:
			//GPIO_ToggleBits(LEDB_pin_num);
	 		break;
		default:
			break;
	}
}

void platform_usb_set_interrupt(uint8_t enable)
{
	
}

uint8_t platform_usb_get_detectPin(void)
{
	return 0;
}

uint8_t platform_usb_get_BurnCodePin(void)
{
	return 0;
}

uint8_t platform_usb_get_chargePin(void)
{
	return 0;
}

uint16_t platform_battery_get_value(void)
{

	return 0;
}

uint32_t platform_timer_ms_tick(void)
{
	return 0;
}

uint32_t platform_timer_us_tick(void)
{
	return 0;
}

uint8_t platform_uart_read_byte(int32_t *ch)
{	
	return 0;
}

uint8_t platform_uart_read_buff(uint8_t *buff, uint32_t len, void (*callback) (void*,uint8_t))
{
	return 0;
}

uint8_t platform_uart_send_buff(uint8_t *buff, uint32_t len)
{
	return 0;
}

uint8_t platform_uart_send_empty(void)
{
	return 1;
}

uint8_t platform_uart_set_baudrate(uint32_t rate)
{
	
	return 0;
}

uint8_t platform_bluetooth_send_notification(uint8_t const *data,uint16_t length)
{
	return 0;
}

uint8_t* platform_bluetooth_get_address(uint8_t *mac_len)
{
	
	return NULL;
}

void platform_touch_enable_interrupt(uint8_t enable)
{
	
}

uint8_t platform_touch_get_status(void)
{
	return 0;
}

int32_t platform_fs_read(uint32_t addr, void *buf, uint32_t size)
{
	if (size >= 30 * 1024) {
		MALOGE("size %d too long.", size);
		return -1;
	}

	if (addr < EFM0_MAIN_BASEADDR) {
		MALOGE("out of range %x %d", addr, size);
		return -2;
	} 

	if (!VALID_EFLASH_SPACE(addr, size)) {
		MALOGE("out of range %x %d", addr, size);
		return -3;
	}
	
	return 0;
}

int32_t platform_fs_write(uint32_t addr, void *buf, uint32_t size, uint32_t key)
{	
	uint32_t page_size = 0;
	uint32_t addr_erase = 0;
	int32_t ret = 0;

	if (addr % 0x800) {
		MALOGE("addr is not page aligned.");
		return -1;
	}

	if (size >= 20 * 1024) {
		MALOGE("size %d too long.", size);
		return -2;
	}

	if (!VALID_EFLASH_SPACE(addr, size)) {
		MALOGE("out of range %x %d", addr, size);
		return -3;
	}
	

	return ret;
}

int32_t platform_fs_page_size(void)
{
	return 0x1000;
}

int32_t platform_fs_erase_page(uint32_t addr, uint32_t key)
{
	return 0;
}

int32_t platform_fs_write_dword_tag(uint32_t addr, uint32_t val, uint32_t key)
{	
	return 0;
}

uint8_t platform_eflash_bulk_program(uint32_t addr, uint32_t num_words, uint32_t *data_buf)
{
	return 0;
}

int32_t platform_get_jiffies(uint32_t *jiffies)
{
	
	return 0;
}


int32_t platform_spi_write_read(const void* cpWriteBuf, int nWriteSize, void* pReadBuf, int nReadSize)
{
	return 0;
}

uint64_t platform_rtc_get_sys_time(void)
{
    return 0;
}

uint8_t platform_rtc_set_sys_time(uint64_t timestamp)
{
	return 0;
}

int32_t platform_rand(void)
{
	return 0;
}


int32_t platform_rand_with_seed(int32_t seed)
{
	
	return 0;
}
void platform_sys_reset(void)
{
}