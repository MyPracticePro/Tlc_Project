#ifndef BOARD_CONFIGH_H_
#define BOARD_CONFIGH_H_

#define Dir_Out        1
#define Dir_In         0

#define Motor_IN1_pin_num   8
#define Motor_IN2_pin_num   23

#define Dog_pin_num    21

#define LEDR_pin_num   11       			//RED
#define LEDB_pin_num   10       			//BLUE
#define LEDG_pin_num   3            		//GREEN

#define CHARGE_STATUS_PIN_NUM    15
#define USB_DETECT_PIN_NUM       22
#define BURN_CODE_DETECT_PIN     16

#define EXT_TOUCH_PIN_NUM  17

#endif

