#include <stdlib.h>
#include "Timer.h"
#include "ble_demo.h"
#include "Uart_pc.h"
#include "Sensor.h"
#include "Flash.h"
#include "eport.h"
#include "ioctrl_drv.h"
#include "uart_drv.h"
#include "adc_drv.h"
#include "EPORT.h"
#include "mg_api.h"
#include "sys.h"
#include "core_cm4.h"
#include "pci_drv.h"
#include "tsi_drv.h"
#include "rtc_drv.h"
#include "pwm_drv.h"
#include "ccm_mem.h"
#include  "ccm_drv.h"
#include "cpm_reg.h"
#include "reboot_demo.h"
#include "platform.h"
#include "boardConfig.h"
#include "globalvar.h"
#include "extTouch.h"
#include "projectConfig.h"


#define SCICR_TX2_GINT5_SWAP_MASK		(1<<29)
#define SCICR_TX3_GINT1_SWAP_MASK		(1<<25)

#define I2C_SCL_PULL_DOWN_UP_MASK       (1<<8)

#define CPM_R                 ((CPM_TypeDef *)(CPM_BASE_ADDR))

periphConfig g_periph_config;
bspFuncCallback g_func_callback;
flash_space_t flash_space;

volatile uint32_t bsp_timer_tick = 0;

static int32_t protocol_token = 0;

unsigned char *ble_mac_addr;

static int8_t is_bt_standby = 0;


void GPIO_ToggleBits(EPORT_PINx pin);
void update_token(void);

extern void Uart_timer_isr(void);
extern void  EPORT_WriteGpioData(EPORT_PINx GpioNo, UINT8 bitVal);
extern void EPORT_ITConfig(EPORT_PINx IntNo, FunctionalState NewState);
extern void WDT_Init(UINT16 WMRCounterVal);
extern void CPM_PowerOff_1p5(void);
extern void CPM_Sleep(void);
extern void updateDeviceInfoData(u8* name, u8 len);

int32_t platform_board_create(bspFuncCallback *callback_table)
{	
	EPORT_ControlConfig_t gpio_config;

	/*function table init*/
	memcpy(&g_func_callback, callback_table, sizeof(bspFuncCallback));

	/*uart init*/
	uartInit(115200);
	
	/*motor init */
	UART_ConfigGpio(Motor_SCI_COM, Motor_IN1_pin_num, GPIO_OUTPUT);
	UART_ConfigGpio(Motor_SCI_COM, Motor_IN2_pin_num, GPIO_OUTPUT);
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN1_pin_num, 0);
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN2_pin_num, 0);

	/*LED init*/
	EPORT_ConfigGpio(LEDR_pin_num, GPIO_OUTPUT);
	EPORT_WriteGpioData(LEDR_pin_num, Bit_SET);
	EPORT_ConfigGpio(LEDB_pin_num, GPIO_OUTPUT);
	EPORT_WriteGpioData(LEDB_pin_num, Bit_SET);
	EPORT_ConfigGpio(LEDG_pin_num, GPIO_OUTPUT);
	EPORT_WriteGpioData(LEDG_pin_num, Bit_SET);

	/*Beep Init*/
	BeepInit();
	SPI_PinIOConfig_t pin_io_config;
	pin_io_config.GPIO_Prior_Normal = 0;
	pin_io_config.Direction_Output = 1;
	SPI_PinIOConfig(&SPI1, PIN_SS, &pin_io_config);
	SPI_PinIOConfig(&SPI1, PIN_MISO, &pin_io_config);

	/*watchdog init*/
	WDT_Init(0x68ff);
	platform_watchdog_start();

	/* For enabled power output.*/
	EPORT_WriteGpioData(POWER_EN_PIN,PERIPH_POWER_EN);
	EPORT_ConfigGpio(POWER_EN_PIN,GPIO_OUTPUT);

	/*PMU init*/
	gpio_config.DirectionOutput = 0;
	gpio_config.EnablePullup = 1;
	gpio_config.OpenDrain = 0;
	gpio_config.TriggerMode = EPORT_BOTH_EDGE_TRIGGER;	
	EPORT_PinControlConfig(&EPORT, USB_DETECT_PIN_NUM - EPORT_PIN0, &gpio_config);
	IOCTRL->GINTL_CONTROL_REG &=  ~SCICR_TX2_GINT5_SWAP_MASK;   //usb detect pin pull down
	EPORT_Init(USB_DETECT_PIN_NUM, RISING_FALLING_EDGE_INT);
	EPORT_ITConfig(USB_DETECT_PIN_NUM, ENABLE);

	I2C_ConfigGpio(CHARGE_STATUS_PIN_NUM, GPIO_INPUT);
	//do{I2C->PCR &= 0xFE;}while(0);
	IOCTRL->I2C_CONTROL_REG &= ~I2C_SCL_PULL_DOWN_UP_MASK;  //charge pin pull down

	/*timer init*/
	timerInit();

	/*spi init*/
	sensorInit();

	/*touch init*/ 
#if ENABLE_INTERNEL_TOUCH
	PCI_Init(1);
	INIT_SENS_PARA;
	if((CPM_R->CPM_SLPCFGR&0xc0000000)==0)
	{
		PCI_Clear_Status();
		Nvram_Write();
		TSI_Init(TSI_EN_CHANNEL);
	}else{
		TSI_Wakeup_Re_init(TSI_EN_CHANNEL);
		//MALOGD("TSI_RE_INIT!/r/n");	
	}
	//NVIC_Init(3, 3, TSI_IRQn, 2);	
#else
	EPORT_ConfigGpio(EXT_TOUCH_PIN_NUM,GPIO_INPUT);
    EPORT_Init(EXT_TOUCH_PIN_NUM, RISING_EDGE_INT);
	EPORT_ITConfig(EXT_TOUCH_PIN_NUM, ENABLE);
	IOCTRL->GINTL_CONTROL_REG &=  ~SCICR_TX3_GINT1_SWAP_MASK;
#endif

	/*flash init*/
	flashInit();	

	/*sys clk init*/
	SysTick_Config(g_sys_clk/1000);  //1ms
	SysTick->CTRL  |= SysTick_CTRL_ENABLE_Msk; 

#if PERIPH_BT_ENABLE
	SPI_InitTypeDef SPI_InitStruct;

	/*ble init*/
	/* 
	   Config the eport 0 for a external irq pin for BLE irq, for wakeup the MCU from low power mode,
	   The irq enable please see the BLE initialization code.
	 */
	gpio_config.TriggerMode = EPORT_FALLING_EDGE_TRIGGER;
	gpio_config.DirectionOutput = 0;
	gpio_config.EnablePullup = 1;
	gpio_config.OpenDrain = 0;
	EPORT_PinControlConfig(&EPORT, 0, &gpio_config);

	SPI_StructInit(SPI_Mode_Master,&SPI_InitStruct);
	SPI_InitStruct.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_10;
	SPI_Init(SPI2_REG_STR,&SPI_InitStruct);
	//DMA_Init(DMA1_BASE_ADDR);

	EPORT_ConfigGpio(EPORT_PIN0,GPIO_INPUT);
    EPORT_Init(EPORT_PIN0, FALLING_EDGE_INT); // LOW_LEVEL_INT
	SetBleIntRunningMode();
	radio_initBle(TXPWR_0DBM, &ble_mac_addr);
	ble_run_interrupt_start(160*2);
#endif

	return 0;
}

int32_t platform_load_board_config(periphConfig *config)
{
	MotorInit(&config->motor_conf, g_func_callback.bsp_motor_notify_callback);
	LedInit(&config->led_conf);

	return 0;
}


uint8_t platform_board_restore(void)
{ 
	timerStart();
	
#if PERIPH_BT_ENABLE
	if(is_bt_standby) {
		is_bt_standby = 0;
		radio_resume();
	}
#endif
	return 0;
}

uint8_t platform_board_shutdown(void)
{
	
#if PERIPH_BT_ENABLE
	SPI_PinIOConfig_t pin_io_config;

	if(!is_bt_standby) {
		is_bt_standby = 1;
		radio_standby();
	}

	pin_io_config.GPIO_Prior_Normal = 0;
	pin_io_config.Direction_Output = 0;
	SPI_PinIOConfig(&SPI2, PIN_SS, &pin_io_config);
	SPI_PinIOConfig(&SPI2, PIN_SCK, &pin_io_config);
	SPI_PinIOConfig(&SPI2, PIN_MOSI, &pin_io_config);
	SPI_PinIOConfig(&SPI2, PIN_MISO, &pin_io_config);
	SPI_WritePin(&SPI2, PIN_SS, 0);
	SPI_WritePin(&SPI2, PIN_SCK, 0);
	SPI_WritePin(&SPI2, PIN_MOSI, 0);
	SPI_WritePin(&SPI2, PIN_MISO, 0);

	EPORT_ITConfig(EPORT_PIN0, DISABLE);
	EPORT_WriteGpioData(EPORT_PIN0,Bit_RESET);
#endif

	timerStop();

	EPORT_WriteGpioData(POWER_EN_PIN,!PERIPH_POWER_EN);
	
#if ENABLE_INTERNEL_TOUCH
	Config_TSI_Lowpower_Wakeup(TSI_WAKEUP_CHANNEL);
#endif

	
#if PERIPH_POWER_EN
	CPM_Sleep();
#else 
	CPM_PowerOff_1p5();
#endif

	//CPM_PowerOff_1();
	return 0;
}

int32_t platform_mafp_create(void)
{	

	return 0;
}

int32_t platform_mafp_destroy(void)
{
	return 0;
}

int8_t platform_motor_unlock(void)
{
	motor_open();
	return 0;
}

void platform_motor_f_run(void)
{
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN1_pin_num, 0);
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN2_pin_num, 1);
}

void platform_motor_b_run(void)
{
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN1_pin_num, 1);
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN2_pin_num, 0);
}

void platform_motor_stop(void)
{
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN1_pin_num, 0);
	UART_WriteGpioData(Motor_SCI_COM, Motor_IN2_pin_num, 0);
}

uint32_t platform_motor_shaftlock(void)
{
	uint32_t adcValue;

	ADC_GetConversionValue(MOTOR_SHAFT_ADC_CHN); 
	adcValue = ADC_GetConversionValue(MOTOR_SHAFT_ADC_CHN);
	//MALOGD("motor adc %d", adcValue);
	return adcValue;
}


int8_t platform_watchdog_start(void)
{
	WDT_Init(0x68ff);
	return 0;
}

int32_t platform_watchdog_get_count(void)
{
	WDT_FeedDog();
    return 0;
}

void platform_led_start_warn(uint8_t type, LED_status status, int time)
{
	SetLedBeep_Status(type, status, time);
}

void platform_led_set_value(uint8_t led, uint8_t val)
{
	//MALOGD("led = %d, val = %d", led, val);
	switch(led){
		case LLED_RED:
			EPORT_WriteGpioData(LEDR_pin_num, !val);
	 		break;
		case LLED_GREEN:
			EPORT_WriteGpioData(LEDG_pin_num, !val);
	 		break;
		case LLED_BLUE:
			EPORT_WriteGpioData(LEDB_pin_num, !val);
	 		break;
		default:
			break;
	}
}

uint8_t platform_led_get_state(uint8_t led)
{
	uint8_t state = 0;

	switch(led){
		case LLED_RED:
			state = EPORT_ReadGpioData(LEDR_pin_num);
	 		break;
		case LLED_GREEN:
			state = EPORT_ReadGpioData(LEDG_pin_num);
	 		break;
		case LLED_BLUE:
			state = EPORT_ReadGpioData(LEDB_pin_num);
	 		break;
		default:
			break;
	}

	//MALOGD("led = %d, state = %d", led, state);

	return state == 0 ? LIGHT : OFF;
}

void platform_led_toggle(uint8_t led)
{
	switch(led){
		case LLED_RED:
			GPIO_ToggleBits(LEDR_pin_num);
	 		break;
		case LLED_GREEN:
			GPIO_ToggleBits(LEDG_pin_num);
	 		break;
		case LLED_BLUE:
			GPIO_ToggleBits(LEDB_pin_num);
	 		break;
		default:
			break;
	}
}

void platform_beep_start_pwm(void)
{
	CCM->PCFG3 |= (0x01 << 2);
	PWM_OutputInit(PWM_PORT2,0,PWM_CLK_DIV_1,18000,10000,0);
}
void platform_beep_stop_pwm(void)
{
	PWM_Stop(PWM_PORT2);
	CCM->PCFG3 &= ~(0x01 << 2);
}

void platform_beep_start(void)
{
	SPI_WritePin(&SPI1, PIN_SS, 1);
	platform_msleep(1);
	SPI_WritePin(&SPI1, PIN_SS, 0);
}

void platform_beep_toggle(void)
{
	if(0 != SPI_ReadPin(&SPI1, PIN_MISO)) {
		SPI_WritePin(&SPI1, PIN_MISO, 0);
	} else {
		SPI_WritePin(&SPI1, PIN_MISO, 1);
	}
}

void platform_usb_set_interrupt(uint8_t enable)
{
	if(enable) {
		EPORT_ITConfig(USB_DETECT_PIN_NUM, ENABLE);
	} else {
		EPORT_ITConfig(USB_DETECT_PIN_NUM, DISABLE);
	}
}

uint8_t platform_usb_get_detectPin(void)
{
	return EPORT_ReadGpioData(USB_DETECT_PIN_NUM);
}

uint8_t platform_usb_get_BurnCodePin(void)
{
	return 0;//I2C_Read_Gpio_Data_Reboot(I2C_SDA);
}

uint8_t platform_usb_get_chargePin(void)
{
	return I2C_ReadGpioData(CHARGE_STATUS_PIN_NUM);
}

uint16_t platform_battery_get_value(void)
{
	uint32_t adcValue;
	uint32_t resVC;

	ADC_GetConversionValue(BATTERY_ADC_CHANNEL); 
	resVC = ADC_GetConversionValue(BATTERY_ADC_CHANNEL);   //vref 3.3V
	adcValue = resVC * BATTERY_MAX_ENERGE / MAX_BAT_ADC_VALUE;
	//MALOGD("battery adc %d %d", adcValue, resVC);

	return adcValue;
}

uint32_t platform_timer_ms_tick(void)
{
	return bsp_timer_tick;
}

uint32_t platform_timer_us_tick(void)
{
	return bsp_timer_tick;
}

uint8_t platform_uart_read_byte(int32_t *ch)
{	
	return 0;
}

uint8_t platform_uart_read_buff(uint8_t *buff, uint32_t len, void (*callback) (void*,uint8_t))
{
	return 0;
}

uint8_t platform_uart_send_buff(uint8_t *buff, uint32_t len)
{
	uartSendBuff(buff, len);
	return 0;
}

uint8_t platform_uart_send_empty(void)
{
	return uartSendBuffEmpty();
}

uint8_t platform_uart_set_baudrate(uint32_t rate)
{
	
	return 0;
}

uint8_t platform_bluetooth_set_context(unsigned char *addr)
{
	if(addr != NULL) radio_setBleAddr(addr);

	return 0;
}

uint8_t platform_bluetooth_send_notification(const uint8_t *data,uint16_t length)
{
	uint32_t timeout = 0x6FFFF;

    while ((!sconn_indicationdata((unsigned char*)data, (unsigned char)length)) && timeout){
		timeout--;
	}
	return 0;
}

uint8_t platform_bluetooth_event_notify(bluetoothEvent event, void *buf, uint32_t buf_size)
{
	//MALOGD("bt evt %x, buf size %d", event, buf_size);

	if(event == EVT_BT_CNNT_STATE_CHG) {
		//MALOGD("bt connect %d", *status);
		if(*(uint8_t *)buf == 0) {  //BT connected
			update_token();
		}
	}
	
	g_func_callback.app_bluetooth_receive_callback(event, (uint8_t *)buf, buf_size);
	return 0;
}

unsigned char* platform_bluetooth_get_address(void)
{
	return ble_mac_addr;
}

uint8_t platform_bluetooth_get_token(int32_t *p_token)
{
	*p_token = protocol_token;

	if(p_token != NULL) {
		//MALOGD("token %x", *p_token);
		return sizeof(int32_t);
	}

	return 0;
}

uint8_t platform_bluetooth_set_ble_name(uint8_t *name, uint8_t len)
{
	updateDeviceInfoData(name, len);
	return 0; 
}

uint8_t platform_bluetooth_set_adv_data(unsigned char * adv_data, unsigned char len)
{
	ble_set_adv_data(adv_data, len);
	return 0;
}

uint8_t platform_bluetooth_disconnect(void)
{
	ble_disconnect();
	return 0;
}


uint8_t platform_bluetooth_standby(void)
{
	if(!is_bt_standby) {
		is_bt_standby = 1;
		radio_standby();
	}

	return 0;
}


void platform_touch_enable_interrupt(uint8_t enable)
{
	if(enable) {
		EPORT_ITConfig(EXT_TOUCH_PIN_NUM, ENABLE);
	} else {
		EPORT_ITConfig(EXT_TOUCH_PIN_NUM, DISABLE);
	}
}

uint8_t platform_touch_get_status(void)
{
#if ENABLE_INTERNEL_TOUCH
	return 1;
#else
	return EPORT_ReadGpioData(EXT_TOUCH_PIN_NUM);
#endif
}

int32_t platform_filesystem_read(uint32_t addr, void *buf, uint32_t size)
{
	memcpy(buf, (void *)addr, size);
	return 0;
}

int32_t platform_filesystem_write(uint32_t addr, void *buf, uint32_t size)
{	
	uint8_t ret;
	
	ret = eflashWrite(addr, size, buf);
	return ret;
}

#ifdef USE_ALGO_BIN_HEX
int32_t platform_msleep(uint32_t ms)
{	
	timerDelayMs(ms);
	return 0;
}


int32_t platform_rand(void)
{
	return rand();
}

int32_t platform_fs_erase_page(uint32_t addr, uint32_t key)
{
	SPI_Flash_Erase_Sector(addr);
	return 0;
}

#endif


/*int32_t platform_fs_page_size(void)
{
	return EFLASH_PAGESIZE;
}

int32_t platform_fs_write_dword_tag(uint32_t addr, uint32_t val, uint32_t key)
{	
	
	return 0;
}

uint8_t platform_eflash_bulk_program(uint32_t addr, uint32_t num_words, uint32_t *data_buf)
{
	return 0;
}

int32_t platform_get_jiffies(uint32_t *jiffies)
{
	*jiffies = bsp_timer_tick;
	return 0;
}*/


int32_t platform_spi_write_read(const void* cpWriteBuf, int nWriteSize, void* pReadBuf, int nReadSize)
{
	return 0;
}

time_t platform_rtc_get_sys_time(void)
{
	tm time;
	int month, day;
	tm_date date;
	time_t timeStamp;
	
	RTC_GetTime(&time);
	date.sec = time.second;
	date.min = time.minute;
	date.hour = time.hour;
	if(project_ctx.bsp_ctx->s_date.year < RTC_REF_YEAR) {
		project_ctx.bsp_ctx->s_date.year = RTC_REF_YEAR;
	}
	month_day(project_ctx.bsp_ctx->s_date.year, time.day, &month, &day);
	date.mday = day;
	date.mon = month;
	date.year = project_ctx.bsp_ctx->s_date.year;
	 
	timeStamp = localTime_to_unixTimestamp(date);

	//MALOGD("%d_%d_%d %d:%d:%d stamp %lu", date.year, date.mon, date.mday, date.hour, date.min, date.sec, timeStamp);
    return timeStamp;
}

uint8_t platform_rtc_set_sys_time(uint64_t timestamp)
{
	tm_date local_date;
	tm time;

	local_date = unixTimestamp_to_localTime(timestamp); 
	memcpy(&project_ctx.bsp_ctx->s_date, &local_date, sizeof(tm_date));
	time.day = day_of_year(local_date.year, local_date.mon, local_date.mday);
	time.hour = local_date.hour;
	time.minute = local_date.min;
	time.second = local_date.sec;
	RTC_SetTime(time);
	return 0;
}


/*int32_t platform_rand_with_seed(int32_t seed)
{
	
	return 0;
}*/

void platform_sys_reset(uint8_t isflash)
{

	if(isflash) Reboot_Demo();
	Sys_Soft_Reset();
}

#ifdef CONFIG_BSP_DEBUG
void platform_bsp_test_func(void *data)
{
	//uint8_t pin,pin_ss;
	SPI_PinIOConfig_t pin_io_config;
	uint8_t i;
	static uint8_t sequence = 0;

	MALOGD("%d voice", sequence);

	pin_io_config.GPIO_Prior_Normal = 0;
	pin_io_config.Direction_Output = 1;

	SPI_PinIOConfig(&SPI1, PIN_SS, &pin_io_config);
	SPI_PinIOConfig(&SPI1, PIN_MISO, &pin_io_config);

	//pull reset pin
	SPI_WritePin(&SPI1, PIN_SS, 1);
	platform_msleep(5);
	SPI_WritePin(&SPI1, PIN_SS, 0);

	platform_msleep(5);

	//play voice
	SPI_WritePin(&SPI1, PIN_MISO, 0);
	for(i = 0; i <= sequence; i++) {
		SPI_WritePin(&SPI1, PIN_MISO, 1);
		platform_msleep(10);
		SPI_WritePin(&SPI1, PIN_MISO, 0);

		
		platform_msleep(5);
	}
	sequence++;

}
#endif

void EPORT0_1_IRQHandler(void) 
{
	EPORT_t *EPORTx;

	EPORTx = &EPORT;
	EPORTx->EPFR |= 0x01<< EXT_TOUCH_PIN_NUM;
	g_func_callback.app_touch_callback();
	ext_touch_disable_interrupt();
}

void EPORT0_5_IRQHandler(void) 
{
	EPORT_t *EPORTx;

	EPORTx = &EPORT;
	EPORTx->EPFR |= 0x01<< USB_DETECT_PIN_NUM;
	g_func_callback.app_usb_detect_callback();
}


void GPIO_ToggleBits(EPORT_PINx pin)
{

	if(0 != EPORT_ReadGpioData(pin)) {
		EPORT_WriteGpioData(pin, 0);
	} else {
		EPORT_WriteGpioData(pin, 1);
	}
}

void update_token(void)
{
	int32_t tmp_seed;

	tmp_seed =  platform_rand();
	
	protocol_token = tmp_seed;
}

void app_timer0_interrupt_callback(void* param)
{
#if ENABLE_INTERNEL_TOUCH
	unsigned char key_data;
	uint16_t scan_rate = 100;

	if(bsp_timer_tick % scan_rate == 0) {
		key_data = TSI_Key_Data();
		if((key_data != 0xff)&&(key_data != 0xaa))
		{
			MALOGD("CH:%d\r\n",key_data);
			if(key_data == 0x0B) {
				g_func_callback.app_touch_callback();
			}
		}
	}
#endif
    bsp_timer_tick++ ;

	/*tm time;
	if(bsp_timer_tick % 1000 == 0){
		RTC_GetTime(&time);
		MALOGD("second %d", time.second);
	}*/

	if(g_func_callback.app_timer_1ms_tick_func0 && g_func_callback.app_timer_1ms_tick_func1) {
		g_func_callback.app_timer_1ms_tick_func0();
		g_func_callback.app_timer_1ms_tick_func1();
	}

	Uart_timer_isr();
}

