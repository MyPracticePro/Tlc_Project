#ifndef BOARD_CONFIGH_H_
#define BOARD_CONFIGH_H_

#include "ioctrl_drv.h"
#include "i2c_drv.h"

#define Motor_SCI_COM           SCI1_REG_STR
#define Motor_IN1_pin_num       UART_TX
#define Motor_IN2_pin_num       UART_RX
#define MOTOR_SHAFT_ADC_CHN     ADCCH_0

#define LEDR_pin_num   EPORT_PIN2      	     		//RED
#define LEDB_pin_num   EPORT_PIN3       			//BLUE
#define LEDG_pin_num   EPORT_PIN4            		//GREEN

#define CHARGE_STATUS_PIN_NUM    I2C_SCL
#define USB_DETECT_PIN_NUM       EPORT_PIN5

#define EXT_TOUCH_PIN_NUM  EPORT_PIN1

#define POWER_EN_PIN EPORT_PIN38

#define BATTERY_ADC_CHANNEL ADCCH_1

#define ENABLE_INTERNEL_TOUCH   0

#define MAX_BAT_ADC_VALUE  4095 // 4.2V battery adc value

#define RTC_REF_YEAR 2020  //RTC time begin 2020 year

#define BEEP_PIN_BUM  EPORT_PIN14

#define PERIPH_POWER_EN   0// 0:pull down  1:pull up  

#endif

