/*
 *  Poewer.c
 *
 *  Created on: 2018/12
 *      Author: john
 */
 
#include "Power.h"
#include "platform.h"

volatile u8 PowerOfftimes;

void usbChargeDetectIntInit(void);
u8 getBatteryPercent(void);

static u8 wake_lock;

uint8_t isUsbPlugin(void)
{
	return platform_usb_get_detectPin();
}

uint8_t detectUsbPlug_robust(void)
{
	u8 preBit, curBit;
	u8 retryTime = 5;
	
	do{
		curBit = platform_usb_get_detectPin();
		if(curBit == preBit) {
			retryTime--;
		}
		else {
			retryTime = 5;
		}
		preBit = curBit;
		platform_msleep(10);
	}while(retryTime > 0);
	
    return curBit;
}

u8 isLowBatWarn(void)
{
    static u8 low = 0;
	uint16_t cur_bat;
	int16_t gap;

    cur_bat = platform_battery_get_value();
	MALOGD("current battery : %d", cur_bat);
	gap = low ? ENABLE_UPPER_LIMIT_GAP : ENABLE_LOWER_LIMIT_GAP;
	low = cur_bat <= (LOW_BATTERY_VALUE + gap) ? 1 : 0;
	
	return low;
}

u8 isPin16High(void)
{
	return platform_usb_get_BurnCodePin();
}

u8 isChargefull(void)
{
	return platform_usb_get_chargePin();
}

u8 getBatteryPercent(void)
{
    u8 percent;
    float  cur_bat;
	cur_bat = platform_battery_get_value();
	percent = ((float)(cur_bat - BATTERY_MIN_ENERGE) / (BATTERY_MAX_ENERGE - BATTERY_MIN_ENERGE)) * 100;
	percent = percent > 100 ? 100 : percent;
	MALOGD("battery remind: %d", percent);
    return percent;
}

void PMU_timer_isr(void)
{
   // MALOGD("start" );

	if (PowerOfftimes > 0) PowerOfftimes--;
}

void get_wake_lock(void)
{
   wake_lock++;
}

void release_wake_lock(void)
{
   if(wake_lock > 0) wake_lock--;
}

u8 wait_wake_lock(void)
{
    return wake_lock||PowerOfftimes;
}

void wake_lock_timeout(u8 Hz)
{
	PowerOfftimes = Hz * (1000 / PMU_PERIOD);
}

