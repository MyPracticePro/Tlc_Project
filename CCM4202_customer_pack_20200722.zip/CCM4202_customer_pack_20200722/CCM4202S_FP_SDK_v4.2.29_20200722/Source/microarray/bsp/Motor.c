/*
 * Motor.c
 *
 *  Created on: 2018/12
 *      Author: john
 */
 
#include "Motor.h"
#include "platform.h"

volatile MOTORS MOTOR;
motorConfig* motor_conf;
mt_handle_t mt_handle;

#define MT_PREPARE_TIME   200
#define MT_SAMPLE_RATE    5
#define VALUE_AVG_LEN  8  //must be sqart(2)
#define MT_UNLOCK_TIME 8
static uint16_t value_array[VALUE_AVG_LEN] = {0};


void motor_unlock_mode15(void);
void motor_mode15_process(void);
void motor_unlock_mode0(void);
void motor_mode0_process(void);


void MotorInit(motorConfig* conf, uint8_t (*notify)(uint8_t state))
{
	motor_conf = conf;
	mt_handle.s_notify = notify;

	if(motor_conf->mode == DG_MODE0) {
		mt_handle.motor_unlock = motor_unlock_mode0;
		mt_handle.motor_unlock_process = motor_mode0_process;
	} else if(motor_conf->mode == DEFAULT_MODE) {
		mt_handle.motor_unlock = motor_unlock_mode15;
		mt_handle.motor_unlock_process = motor_mode15_process;
	}
}

void motor_open(void)
{
	if(mt_handle.motor_unlock  != NULL) {
		mt_handle.motor_unlock();
	} else {
		MALOGD("motor handle is NULL");
	}
}

void Motor_timer_isr(void)
{
	if(mt_handle.motor_unlock_process != NULL) {
		mt_handle.motor_unlock_process();
	}
}

void motor_unlock_mode0(void)
{
	if(!MOTOR.run) {
		MOTOR.state = STA_MOTOR_START;
		memset(value_array, 0x00, VALUE_AVG_LEN *sizeof(uint16_t));
	}
}

void motor_mode0_process(void)
{
	static long tick = 0, adc_tick = 0, proc_tick = 0;
	static uint8_t isProc = 0, isAdcProc = 0, isAdcStart;
	static uint16_t sample_cnt = 0;
	uint8_t index;
	static uint16_t preAdc, curAdc, minAdc = 0xffff, avgAdc = 0, adcSum = 0; 
	static uint8_t unlock_cnt, shaft_cnt;
	static uint8_t pre_state;
	uint8_t ret;

	/*task I: measure adc value*/
	if(isAdcStart) {
		adc_tick++;
		if(!isAdcProc) {
			adc_tick = 0;
			isAdcProc = 1;
		} else {
			if((adc_tick % MT_SAMPLE_RATE) == 0) {
				index = sample_cnt % VALUE_AVG_LEN;
				value_array[index] = platform_motor_shaftlock();
				preAdc = curAdc;
				curAdc = value_array[index];
				adcSum += curAdc;
				sample_cnt++;
				//MALOGD("curAdc %d, minAdc %d, preAdc %d", curAdc, minAdc, preAdc);
				if(sample_cnt % VALUE_AVG_LEN == 0) {
					avgAdc = adcSum / VALUE_AVG_LEN;
					if(avgAdc < minAdc) {
						minAdc = avgAdc;
					}
					adcSum = 0;
				}
				//adc_tick = 0;
			}
		}
	}

	
	/*task II: controlle motor run, divide 9 stage,
	  STA_MOTOR_IDLE: motor do nothing when idle stage, 
	  STA_MOTOR_START: motor start to work when receiver cmd,
	  STA_MOTOR_FWD_DLY: delay moment ensure get precise adc value,
	  STA_MOTOR_UNLOCK:  unlock process,
	  STA_MOTOR_SHAFT: detect whether motor is shafting,
	  STA_MOTOR_INTERVAL: motor will be remind moment when shafting,
	  STA_MOTOR_BWD_DLY: delay moment ensure get precise adc value,
	  STA_MOTOR_LOCK:  lock process
	  STA_MOTOR_STOP:  all process compelete */
	  
	if(MOTOR.run) {
		tick++;
		if(tick >= motor_conf->unlock_timeout) {
			platform_motor_stop();
			MOTOR.state = STA_MOTOR_IDLE;
		}
	}

	if(MOTOR.state == STA_MOTOR_IDLE)
	{
		tick = 0;
		adc_tick = 0;
		isProc = 0;
		isAdcStart = 0;
		isAdcProc = 0;
		MOTOR.run = 0;
	}
	else if(MOTOR.state == STA_MOTOR_START)
	{
		ret = mt_handle.s_notify(STA_MOTOR_START);
		if(!ret) {
			MOTOR.run = 1;
			MOTOR.state = STA_MOTOR_FWD_DLY;
		}
	}
	else if(MOTOR.state == STA_MOTOR_FWD_DLY)
	{
		if(!isProc) {
			proc_tick = 0;
			isProc = 1;
			platform_motor_f_run();
			mt_handle.s_notify(STA_MOTOR_FWD_DLY);
		} else {
			proc_tick++;
			if(proc_tick >= motor_conf->fwd_det_delay) {
				MOTOR.state = STA_MOTOR_UNLOCK;
				isProc = 0;
			}
		}
	}
	else if(MOTOR.state == STA_MOTOR_UNLOCK)
	{
		isAdcStart = 1;
		if((adc_tick % MT_SAMPLE_RATE) == 0) {
			//MALOGD("curAdc %d, minAdc %d", curAdc, minAdc);
			if((minAdc * motor_conf->shaft_curet_time) < curAdc) {
				mt_handle.s_notify(STA_MOTOR_UNLOCK);
				unlock_cnt++;
				if(unlock_cnt >= motor_conf->shaft_curet_cnt) {
					unlock_cnt = 0;
					mt_handle.s_notify(STA_MOTOR_UNLOCK);
					MOTOR.state = STA_MOTOR_SHAFT;
					pre_state = STA_MOTOR_UNLOCK;
				}
			} else {
				unlock_cnt = 0;
			}
		}
	} 
	else if(MOTOR.state == STA_MOTOR_SHAFT)
	{
		if((adc_tick % MT_SAMPLE_RATE) == 0) {
			//MALOGD("curAdc %d, preAdc %d det cnt %d", curAdc, preAdc, motor_conf->shaft_detect_cnt);
			if(curAdc - preAdc <= motor_conf->smooth_toler) {
				shaft_cnt++;
				if(shaft_cnt >= motor_conf->shaft_detect_cnt && curAdc >= motor_conf->shaft_adc_val) {
					shaft_cnt = 0;
					mt_handle.s_notify(STA_MOTOR_SHAFT);
					platform_motor_stop();
					if(pre_state == STA_MOTOR_UNLOCK) {
						MOTOR.state = STA_MOTOR_INTERVAL;
					} else {
						MOTOR.state = STA_MOTOR_ROLLBACK;
					} 
					isAdcStart = 0;
					sample_cnt = 0;
					isProc = 0;
					tick = 0;
					memset(value_array, 0x00, VALUE_AVG_LEN *sizeof(uint16_t));
				}
			} else {
				shaft_cnt = 0;
			}
		}
	}
	else if(MOTOR.state == STA_MOTOR_INTERVAL)
	{
		if(!isProc) {
			proc_tick = 0;
			isProc = 1;
			mt_handle.s_notify(STA_MOTOR_INTERVAL);
		} else {
			proc_tick++;
			if(proc_tick >= motor_conf->interval) {
				MOTOR.state = STA_MOTOR_BWD_DLY;
				isProc = 0;
			}
		}
	}
	else if(MOTOR.state == STA_MOTOR_BWD_DLY)
	{
		if(!isProc) {
			proc_tick = 0;
			isProc = 1;
			mt_handle.s_notify(STA_MOTOR_BWD_DLY);
			platform_motor_b_run();
		} else {
			proc_tick++;
			if(proc_tick >= motor_conf->bwd_det_delay) {
				MOTOR.state = STA_MOTOR_LOCK;
				isProc = 0;
			}
		}
	}
	else if(MOTOR.state == STA_MOTOR_LOCK) 
	{
		isAdcStart = 1;
		if((adc_tick % MT_SAMPLE_RATE) == 0) {
			//MALOGD("curAdc %d, minAdc %d", curAdc, minAdc);
			if((minAdc * motor_conf->shaft_curet_time) < curAdc) {
				unlock_cnt++;
				if(unlock_cnt >= motor_conf->shaft_curet_cnt) {
					unlock_cnt = 0;
					mt_handle.s_notify(STA_MOTOR_LOCK);
					MOTOR.state = STA_MOTOR_SHAFT;
					pre_state = STA_MOTOR_LOCK;
				}
			} else {
				unlock_cnt = 0;
			}
		}
	}
	else if(MOTOR.state == STA_MOTOR_ROLLBACK)
	{
		if(!isProc) {
			proc_tick = 0;
			isProc = 1;
			mt_handle.s_notify(STA_MOTOR_ROLLBACK);
		} else {
			proc_tick++;
			if(proc_tick >= MOTOR_ROLLBACK_INTERVAL) {
				MOTOR.state = STA_MOTOR_STOP;
				isProc = 0;
			}
		}
	}
	else if(MOTOR.state == STA_MOTOR_STOP)
	{
		if(!isProc) {
			proc_tick = 0;
			isProc = 1;
			platform_motor_f_run();
			mt_handle.s_notify(STA_MOTOR_STOP);
		} else {
			proc_tick++;
			if(proc_tick >= motor_conf->shaft_rollback) {
				MOTOR.state = STA_MOTOR_IDLE;
				isProc = 0;
				platform_motor_stop();
			}
		}
	}
}


void motor_unlock_mode15(void)
{
	
	MALOGD("back = %d, forw = %d, int = %d", motor_conf->backwardRun, motor_conf->forwardRun, motor_conf->interval);
	if(MOTOR.FCnt == 0 && MOTOR.BCnt == 0) {
		MOTOR.Flg = 1;
		MOTOR.FCnt = motor_conf->forwardRun / MOTOR_PERIOD;
		MOTOR.BCnt = motor_conf->backwardRun / MOTOR_PERIOD;
		MOTOR.Stage = MOTOR_FLAG;
		MOTOR.Gap = motor_conf->interval / MOTOR_PERIOD;
		MOTOR.Testmode = MOTOR_TEST_MODE;
	}
	memset(value_array, 0x00, VALUE_AVG_LEN *sizeof(uint16_t));
}

void motor_forward_open(u16 dura)
{
	//MALOGD("motor_open start nows");
	if(MOTOR.FCnt == 0 && MOTOR.BCnt == 0) {	
		MOTOR.Flg = 1;
		MOTOR.FCnt = dura / MOTOR_PERIOD;
		MOTOR.BCnt = 0;
		MOTOR.Stage = MOTOR_FLAG;
		MOTOR.Gap = 0;
		MOTOR.Testmode = MOTOR_TEST_MODE;
	}
}

void motor_backward_open(u16 dura)
{
	//MALOGD("motor_open start nows");
	if(MOTOR.FCnt == 0 && MOTOR.BCnt == 0) {
		MOTOR.Flg = 1;
		MOTOR.FCnt = 0;
		MOTOR.BCnt = dura / MOTOR_PERIOD;
		MOTOR.Stage = MOTOR_FLAG;
		MOTOR.Gap = 0;
		MOTOR.Testmode = MOTOR_TEST_MODE;
	}
}

uint8_t motor_shaftlock(void) 
{	
	static uint8_t i = 0;
	uint8_t j;
	uint16_t sum = 0;
	uint16_t avg;

	value_array[i++ % VALUE_AVG_LEN] = platform_motor_shaftlock();
	for(j = 0; j < VALUE_AVG_LEN; j++) {
		sum += value_array[j];
	}
	avg = sum / VALUE_AVG_LEN;

	return avg > MOTOR_SHAFT_ADC_VALUE ? 1 : 0;
}

void motor_mode15_process(void)
{
	uint8_t isShaftlock = 0;
	
	if(MOTOR.Flg==0)                                       
	{     
		//MT_POWER_LO;    
	}
	else
	{
	
		if(MOTOR.FCnt)             
		{
			//MALOGD("MOTOR.FCnt = %d\n",MOTOR.FCnt);
			if((motor_conf->forwardRun - MOTOR.FCnt) > MOTOR_STABLE_TIME) {
				isShaftlock = motor_shaftlock();
			}
			MOTOR.FCnt--;
			platform_motor_f_run();
			if(MOTOR.FCnt<2 || isShaftlock) 
			{
				platform_motor_stop();
				memset(value_array, 0x00, VALUE_AVG_LEN *sizeof(uint16_t));
				MOTOR.FCnt=0;
				if(!MOTOR.Stage)
				MOTOR.Flg=0;
			}

		}
		else if(MOTOR.Stage)
		{
			if(MOTOR.Gap)        
			{
				//MALOGD("MOTOR.Gap = %d\n",MOTOR.Gap);
				MOTOR.Gap--;
			}
			else
			{
				if(MOTOR.BCnt)    
				{
					if((motor_conf->backwardRun - MOTOR.BCnt) > MOTOR_STABLE_TIME) {
						isShaftlock = motor_shaftlock();
					}
					MOTOR.BCnt--;
					if(MOTOR.BCnt==1 || isShaftlock) 
					{   
						platform_motor_stop();
						memset(value_array, 0x00, VALUE_AVG_LEN *sizeof(uint16_t));
						MOTOR.BCnt=0;
						MOTOR.FCnt=0;
						MOTOR.Flg=0;
						MOTOR.Stage=0;
					}
					else
					{
						platform_motor_b_run();
					}
				}
			}
		}		
	}
}





