#include "extTouch.h"
#include "platform.h"

volatile uint8_t finger_dealing_flag = 0;

void ext_touch_disable_interrupt(void)
{
	finger_dealing_flag = 1;
	platform_touch_enable_interrupt(0);
}

void ext_touch_enable_interrupt(void)
{
    finger_dealing_flag = 0;
	platform_touch_enable_interrupt(1);
}

uint8_t isExtTouchPress(void)
{
    return platform_touch_get_status();
}

void Touch_timer_isr(void) 
{
	static u8 touch_scan_rate = TOUCH_SCAN_RATE;

	if(finger_dealing_flag)
	{
		if(--touch_scan_rate == 0)
		{
			//MALOGD("start");
			touch_scan_rate = TOUCH_SCAN_RATE;
			ext_touch_enable_interrupt();
		}
	}

}
