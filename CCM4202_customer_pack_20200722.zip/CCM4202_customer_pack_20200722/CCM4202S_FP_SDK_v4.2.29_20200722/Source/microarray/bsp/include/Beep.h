/*
 *  Beep.h
 *
 *  Created on: 2020/7/13
 *      Author: Young
 */
 

#ifndef BEEP_H_
#define BEEP_H_

#include "type_def.h"
#include "malog.h"

typedef enum{
	BEEP_IDLE = 0,
	BEEP_START,
	BEEP_ALARM,
	BEEP_INT,
	BEEP_STOP,
}BEEP_STATUS;


typedef struct{
	uint8_t pin_num;
	uint8_t mode;
	BEEP_STATUS status;
	uint8_t time;
	uint16_t duration;
}BEEP;

typedef enum {
	VOC_TIP=1,
	VOC_FP_ENROLL_START,
	VOC_FP_ENROLL_AGAIN,
	VOC_FP_ENROLL_FAILED,
	VOC_FP_ENROLL_RESTART,
	VOC_FP_MATCH_FAILED,
	VOC_FP_ENROLL_FINISH,
	VOC_PWD_ENROLL_START,
	VOC_PWD_ENROLL_AGAIN,
	VOC_PWD_INVALID,
	VOC_PWD_FAILED,
	VOC_FACTORY_RESTORED,
	VOC_UNLOCK_SUCCESS,
	VOC_ADD_USER,
	VOC_FP_MATCH_SUCCESS,
	VOC_OPEN_MODE_VFY,
	VOC_FACTORY_VFY,
	VOC_SYS_LOCK,
	VOC_OPEN_MODE,
	VOC_OPEN_MODE_CANCEL,
	VOC_ENGLISH,
	VOC_CHINESE,
	E_VOC_FP_ENROLL_START,
    E_VOC_FP_ENROLL_AGAIN,
    E_VOC_FP_ENROLL_FAILED,
    E_VOC_FP_MATCH_FAILED,
    E_VOC_FP_ENROLL_RESTART,
	E_VOC_FP_ENROLL_FINISH,
	E_VOC_PWD_ENROLL_START,
	E_VOC_PWD_ENROLL_AGAIN,
	E_VOC_PWD_INVALID,
	E_VOC_PWD_ERROR,
	E_VOC_FACTORY_RESTORED,
	E_VOC_UNLOCK_SUCCESS,
	E_VOC_ADD_USER,
	E_VOC_FP_MATCH_SUCCESS,
	E_VOC_OPEN_MODE_VFY,
	E_VOC_FACTORY_VFY,
	E_VOC_SYS_LOCK,
	E_VOC_OPEN_MODE,
	E_VOC_OPEN_MODE_CANCEL,
}Voice_t;


#define BEEP_MODE   1  //0 GPIO, 1 PWM

#define BEEP_PERIOD     1
#define BEEP_DURA_PER_TIME    200   //ms
#define BEEP_DUTY       2           //ms
#define BEEP_INT_DURA    100

void BeepInit(void);
void SetBeep_Alarm(uint8_t time);
void Beep_timer_isr(void);
void SetSpeaker_Voice(Voice_t voice);

#endif
