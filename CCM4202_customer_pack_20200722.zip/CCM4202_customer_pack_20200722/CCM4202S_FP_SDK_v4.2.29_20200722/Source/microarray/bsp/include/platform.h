#ifndef __PLATFORM_H__
#define __PLATFORM_H__
#include "malog.h"
#include "extLed.h"
#include "Motor.h"
#include "Beep.h"
#include "kg_utils.h"
#include "mafp_sensor.h"
#include "hardware_bsp.h"
#include "power.h"

#ifdef PLATFORM_CCM4202
#include "eflash_api.h"
#endif

#ifdef PLATFORM_AC693X
#define AT_MICRO_DATA             AT(.microarray_data)
#define AT_MICRO_CODE             AT(.microarray_code)
#define EFM0_MAIN_BASEADDR      (0x01d80000UL)
#define EFM1_MAIN_BASEADDR		(0x00880000UL)
#endif

#ifdef PLATFORM_BX2400
#define EFM0_MAIN_BASEADDR		(0x00800000UL)   /* 5 Fingers */
#define EFM1_MAIN_BASEADDR		(0x00880000UL)  
#endif

#ifdef PLATFORM_CCM4202
//#define EFM0_MAIN_BASEADDR		(0x00800000UL)   /* 5 Fingers */
//#define EFM1_MAIN_BASEADDR		(0x00880000UL)  
#define EFLASH_PAGESIZE					(512)
#define EFLASH1_PAGESIZE                (512)
#endif


#ifdef SENSOR_E064N
#define EFLASH_OPERATION_KEY		(0x9536142e)
#define getKeyLL()	((EFLASH_OPERATION_KEY)&(0xff))
#define getKeyLH()	((EFLASH_OPERATION_KEY>>8)&(0xff))
#define getKeyHL()	((EFLASH_OPERATION_KEY>>16)&(0xff))
#define getKeyHH()	((EFLASH_OPERATION_KEY>>24)&(0xff))
#endif

/* eflash page size. */
//#define EFLASH_PAGESIZE			(0x1000)     /* 4K */
//#define EFLASH1_PAGESIZE		(0x1000)	 /* 4K */
#define EFLASH_PROG_ERASE_PASS		(0)
#define EFLASH_PROG_ERASE_FAIL		(1)

#define ROUND_UP(x, aligned)                    (((x) + (aligned) - 1) / (aligned) * (aligned))

#define SENSOR_DATA_OFFSET                      (148)//(400)		// code & data in flash = 184K

#define SENSOR_PROPERTY_ADDR                    (EFM0_MAIN_BASEADDR + 1024 * (SENSOR_DATA_OFFSET + 4))   // 4K for system used

#define VALID_EFLASH_SPACE(addr, size)          (((addr) >= EFM0_MAIN_BASEADDR) && ((addr) + (size) <= (EFM0_MAIN_BASEADDR + 1* 1016 * 1024)))

#define USER_CFG_DATA_ADDR                      0x8022000


/////////////////////////// Templates Flash related configuration start ///////////////////////////////

// 4K for SYSTEM, 4K prop, 16 for bkg, 4K for match record, 8K for finger template related
#define TPLS_EFLASH1_START                      (EFM0_MAIN_BASEADDR + 1024 * (SENSOR_DATA_OFFSET + 36))
#define TPLS_EFLASH1_END                        (EFM0_MAIN_BASEADDR + 1024 * (SENSOR_DATA_OFFSET+400))

#define TPLS_EFLASH2_START                      (TPLS_EFLASH1_END)
#define TPLS_EFLASH2_END                        (TPLS_EFLASH1_END + 1024 * 100)


typedef struct flash_space_s {
	uint32_t syspara_start;
	uint32_t prop_start;
	uint32_t bkg_start;
	uint32_t badpoint_start;
	uint32_t match_rcrd_start;
	uint32_t templates_start;
	uint32_t sensor_cfg_start;
	uint32_t subtpls_start;
	uint32_t user_data_end;
} flash_space_t;


extern flash_space_t flash_space;

typedef enum {
	EVT_BT_CNNT_STATE_CHG = 0x00,
	EVT_BT_REV_BUF,
}bluetoothEvent;

typedef struct {
	uint8_t version;
	uint8_t bt_adv_type; //00:wakeup 01:long-term
	int8_t bt_adv_power; //dB  -15dB ~ 15dB
	uint16_t bt_adv_interval; // (n + 1) * 100ms  0~1600ms
	uint8_t bt_adv_duty;     //(n + 1) * 1s  0~32s
}miscConfig;

typedef struct {
	motorConfig motor_conf;
	ledConfig led_conf;
	batteryConfig bat_conf;
	miscConfig misc_conf;
}periphConfig;

typedef struct {
	void (*app_timer_1ms_tick_func0)(void);
	void (*app_timer_1ms_tick_func1)(void);
	uint8_t (*app_touch_callback)(void);
	uint8_t (*app_uart_receive_callback)(uint8_t *buf, uint16_t size);
	uint8_t (*app_bluetooth_receive_callback)(bluetoothEvent event, uint8_t *buf, uint16_t size);
	uint8_t (*app_usb_detect_callback)(void);
	uint8_t (*bsp_motor_notify_callback)(uint8_t state);
}bspFuncCallback;


/*platform perpheral interface*/
extern int32_t platform_board_create(bspFuncCallback *callback_table);
extern int32_t platform_load_board_config(periphConfig *config);
extern uint8_t platform_board_shutdown(void);
extern uint8_t platform_board_restore(void);
extern int32_t platform_mafp_create(void);
extern int32_t platform_mafp_destroy(void);
extern int32_t platform_msleep(uint32_t ms);
extern int32_t platform_filesystem_read(uint32_t addr, void *buf, uint32_t size);
extern int32_t platform_filesystem_write(uint32_t addr, void *buf, uint32_t size);
extern int32_t platform_fs_page_size(void);
extern int32_t platform_fs_erase_page(uint32_t addr, uint32_t key);
extern int32_t platform_fs_write_dword_tag(uint32_t addr, uint32_t val, uint32_t key);
extern uint8_t platform_eflash_bulk_program(uint32_t addr, uint32_t num_words, uint32_t *data_buf);
extern int32_t platform_spi_write_read(const void* cpWriteBuf, int nWriteSize, void* pReadBuf, int nReadSize);
extern int32_t platform_get_jiffies(uint32_t *jiffies);
extern int8_t platform_motor_unlock(void);
extern void platform_motor_f_run(void);
extern void platform_motor_b_run(void);
extern void platform_motor_stop(void);
extern uint32_t platform_motor_shaftlock(void);
extern int8_t platform_watchdog_start(void);
extern int32_t platform_watchdog_get_count(void);
extern void platform_led_start_warn(uint8_t type, LED_status status, int time);
extern void platform_led_set_value(uint8_t led, uint8_t val);
extern uint8_t platform_led_get_state(uint8_t led);
extern void platform_led_toggle(uint8_t led);
extern void platform_usb_set_interrupt(uint8_t enable);
extern uint8_t platform_usb_get_detectPin(void);
extern uint8_t platform_usb_get_BurnCodePin(void);
extern uint8_t platform_usb_get_chargePin(void);
extern uint16_t platform_battery_get_value(void);
extern uint32_t platform_timer_ms_tick(void);
extern uint32_t platform_timer_us_tick(void);
extern void platform_timer_start(void);
extern void platform_timer_stop(void);
extern uint8_t platform_uart_read_byte(int32_t *ch);
extern uint8_t platform_uart_read_buff(uint8_t *buff, uint32_t len, void (*callback) (void*,uint8_t));
extern uint8_t platform_uart_send_buff(uint8_t *buff, uint32_t len);
extern uint8_t platform_uart_send_empty(void);
extern uint8_t platform_uart_set_baudrate(uint32_t rate);
extern uint8_t platform_bluetooth_set_context(unsigned char *addr);
extern uint8_t platform_bluetooth_send_notification(const uint8_t *data,uint16_t length);
extern uint8_t platform_bluetooth_event_notify(bluetoothEvent event, void *buf, uint32_t buf_size);
extern uint8_t platform_bluetooth_get_token(int32_t *p_token);
extern uint8_t platform_bluetooth_set_ble_name(uint8_t *name, uint8_t len);
extern uint8_t platform_bluetooth_set_adv_data(unsigned char * adv_data, unsigned char len);
extern uint8_t platform_bluetooth_standby(void);
extern uint8_t platform_bluetooth_disconnect(void);
extern void platform_touch_enable_interrupt(uint8_t enable);
extern unsigned char* platform_bluetooth_get_address(void);
extern uint8_t platform_touch_get_status(void);
extern time_t platform_rtc_get_sys_time(void);
extern uint8_t platform_rtc_set_sys_time(uint64_t timestamp);
extern int32_t platform_rand(void);
extern int32_t platform_rand_with_seed(int32_t seed);
extern void platform_sys_reset(uint8_t isflash);
extern void platform_bsp_test_func(void *data);
extern void platform_beep_toggle(void);
extern void platform_beep_start_pwm(void);
extern void platform_beep_stop_pwm(void);
extern void platform_beep_start(void);

#endif

