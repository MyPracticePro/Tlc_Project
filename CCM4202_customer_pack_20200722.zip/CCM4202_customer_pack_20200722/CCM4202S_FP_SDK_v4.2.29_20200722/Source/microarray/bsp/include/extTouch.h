#ifndef EXT_TOUCH_H
#define EXT_TOUCH_H

//#include "lock_task.h"
#include "hardware_bsp.h"

#define TOUCH_PERIOD  100
#define TOUCH_SCAN_RATE 10

void Touch_timer_isr(void);
void ext_touch_disable_interrupt(void);
void ext_touch_enable_interrupt(void);
uint8_t isExtTouchPress(void);
void ext_touch_int_init(void);


#endif

