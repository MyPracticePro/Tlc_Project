/*
 *  Poewer.c
 *
 *  Created on: 2018/12
 *      Author: john
 */

#ifndef KEY_H_
#define KEY_H_

#include "type_def.h"
#include "malog.h"

#define BATTERY_MAX_ENERGE       4095
#define LOW_BATTERY_VALUE        3553
#define BATTERY_MIN_ENERGE       3300
#define ENABLE_LOWER_LIMIT_GAP   (-20)
#define ENABLE_UPPER_LIMIT_GAP   (20)

#define BURN_CODE_DETECT_COUNT   3
#define PMU_PERIOD               500

typedef struct {
	uint8_t type;      //00:lithium  01:Li-MnO2
	uint8_t adc_vref;  //00:<=0.3v  01:0.6v 10:1.2v  11: >=1.8v 
	uint8_t low_warn;  //percent
}batteryConfig;


void wake_lock_timeout(u8 times);
void release_wake_lock(void);
void get_wake_lock(void);
u8 wait_wake_lock(void);
uint8_t isUsbPlugin(void);
uint8_t detectUsbPlug_robust(void);
u8 getBatteryPercent(void);
u8 isLowBatWarn(void);
u8 isPin16High(void);
void PMU_timer_isr(void);
u8 isChargefull(void);


#endif 
