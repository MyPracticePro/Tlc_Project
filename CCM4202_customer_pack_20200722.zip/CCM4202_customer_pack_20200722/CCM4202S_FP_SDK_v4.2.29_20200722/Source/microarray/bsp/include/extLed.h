/*
 *  Led.h
 *
 *  Created on: 2018/012
 *      Author: john
 */
 


#ifndef EXTLED_H_
#define EXTLED_H_

#include "type_def.h"
#include "malog.h"

#define LED_PERIOD     1

#define LIGHT 1
#define OFF   0

#define LED_NUM        (3 + 1)

typedef struct {
	uint8_t mode;	// 0~F, F:default
	uint16_t flash_slow_dura;
	uint16_t flash_fast_dura;
	uint16_t light_dura;
	uint16_t breath_half_dura;
	uint8_t breath_freq;
}ledConfig;

typedef enum {
	LLED_RED=0,	
	LLED_BLUE=1,
	LLED_GREEN=2, 
	LLED_MIXED,
}LED_type;

typedef enum {
	LED_OFF=0,
	LED_ON=1,
	LED_LIGHT=2,
	LED_FLASH=3,
	LED_FLASH_SLOW,
	LED_FLASH_BLINK,
	LED_BREATH,
	LED_ALTERNATE_RG,
	LED_ALTERNATE_RB,
	LED_ALTERNATE_GB,
	LED_WATER_FLOW,
}LED_status;

typedef struct{
	u8 pin_num;
	LED_status pre_status;
	LED_status status;
	uint16_t duration;
	uint8_t flash_type;
	uint8_t always_on;
}LED;

typedef struct{
	uint8_t duty ;
	uint8_t flag ;
	uint16_t duty_cnt;
	uint8_t direction;
}led_breath_t;


void LedInit(ledConfig *conf);
void SetLedBeep_Status(uint8_t type, LED_status status, int time);
void Ledflash_timer_isr(void);
void Led_All_Off(void);
void LED_On(uint8_t type);
void LED_Off(uint8_t type);
u8 LED_Status(uint8_t type);
void LED_Breath(uint8_t type);


#endif
