/*
 * UART0 Operations
 *
 * Copyright (C) 2017 Microarray Electronic Co., LTD.
 *
 * Written by:
 *     Hans.Huang  hux@microarray.com.cn
 *     
 * Hans.Huang    09/05/17     Create this file for UART0 Function Declars and MACRO Defines
 */


#ifndef _UART_H
#define _UART_H


#include <stdint.h>

#define RX_MASK						0x00FF
#define	RX_BUF_F					0x01   
#define RX_BUF_E					0x02   
#define USART_REC_LEN  		        (RX_MASK+1)
#define UART_ISR_RECV_LEN           0x20
#define UART_IDLE_TIME              5 //ms
#define UART_PERIOD                 1
#define mod(x, y) ((x > y) ? (x - y) : (x + 0xff - y + 1))


typedef struct
{
	uint8_t	    rx_buf[USART_REC_LEN];        
	uint16_t	rx_seek;                 
	uint16_t	rx_size;                 
	uint8_t	    rx_stat;                     
}USARTypDef;

void uartInit(void);
void uartSendBuff(uint8_t *dat, uint32_t len);
int32_t  uartSendBuffEmpty(void);
void debugPrint(const char *fmt, ...);
void uartdeInit(void);
void Uart_timer_isr(void);
uint8_t   uartReadByte(int32_t *ch);
void reset_Uart_Tag( void );
void uart0_rx_func_callback(void *dummy,uint8_t status);

#endif /* End of _UART_H */
