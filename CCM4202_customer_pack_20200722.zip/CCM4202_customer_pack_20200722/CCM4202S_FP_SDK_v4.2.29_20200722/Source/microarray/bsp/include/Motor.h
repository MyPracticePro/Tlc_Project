/*
 * Motor.h
 *
 *  Created on: 2018/12
 *      Author: john
 */
 

#ifndef MOTOR_H_
#define MOTOR_H_

#include "type_def.h"

#define MOTOR_FORWARD_DURATION     120 
#define MOTOR_BACKWARD_DURATION    70
#define MOTOR_INTERVAL_FURATION    400
#define MOTOR_ROLLBACK_INTERVAL    200
#define MOTOR_FLAG                 1
#define MOTOR_TEST_MODE            0
#define MOTOR_PERIOD               1
#define MOTOR_SHAFT_ADC_VALUE      135
#define MOTOR_STABLE_TIME          50

typedef enum {
	STA_MOTOR_IDLE,
	STA_MOTOR_START,
	STA_MOTOR_FWD_DLY,
	STA_MOTOR_UNLOCK,
	STA_MOTOR_SHAFT,
	STA_MOTOR_INTERVAL,
	STA_MOTOR_BWD_DLY,
	STA_MOTOR_LOCK,
	STA_MOTOR_ROLLBACK,
	STA_MOTOR_STOP,
}motorRunState;

typedef enum {
	DG_MODE0 = 0x00,
	DEFAULT_MODE = 0x0f,
}motorUnlockMode;

typedef struct {
	void (*motor_unlock)(void);
	void (*motor_unlock_process)(void);
	uint8_t (*s_notify)(uint8_t state);
}mt_handle_t;

typedef struct {
	uint8_t mode;
	uint16_t forwardRun;
	uint16_t backwardRun;
	uint32_t interval;         //(n + 1) * 100ms
	uint8_t shaft_detect_cnt;  //(n + 1)   0~16
	uint8_t smooth_toler;  //Smoothing tolerance   (n + 2)   0~10
	uint16_t shaft_adc_val;  //(n + 1) * 10   0~320
	uint8_t shaft_curet_time;  // (n + 1) * 0.2  0~1.6
	uint8_t shaft_curet_cnt;   //(n + 1) * 2     0~16
	uint16_t fwd_det_delay;  //(n + 1) * 25ms   0~400ms
	uint16_t bwd_det_delay;   //(n + 1) * 25ms + 50   0~400ms
	uint16_t shaft_rollback;  //(n + 1) * 5ms   0~1280ms
	uint16_t unlock_timeout; //(n + 1) * 200ms  0~3200ms
}motorConfig;

typedef struct{
	unsigned char Stage;			//����ת��־
	unsigned char Dly;
	unsigned char Flg;				//�����־
	u16 FCnt;				//����ʱ��
	u16 BCnt;				//����ʱ��
	u16 Gap; 				//���ʱ��
	unsigned char Lockcls; 		//������־
	unsigned char Testmode;		//�������ģʽ
	uint8_t run;
	uint8_t state;
}MOTORS;


void MotorInit(motorConfig* conf, uint8_t (*notify)(uint8_t state));
void motor_open(void);
void Motor_timer_isr(void);
void motor_forward_open(u16 dura);
void motor_backward_open(u16 dura);
#endif 
