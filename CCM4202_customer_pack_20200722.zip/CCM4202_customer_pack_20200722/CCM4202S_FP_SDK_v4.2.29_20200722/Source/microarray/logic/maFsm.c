/*********************************************************************************************************
 ** file:	    fsm.c
 ** description:	Э������ʵ��
 ** author:      li
 ** date :       2017/05/16
 ***********************************************************************************************************/
#include "maFsm.h"
#include <string.h>
#include <mafp_sensor.h>
#include <system.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include"synocFsm.h"
#include"yaleFsm.h"
#include "globalvar.h"
#include "factory_test_bsp.h"
#ifdef SENSOR_E064N
#include "sensor_comm.h"
#endif

static void maFsmTask(S32 ch);
static S32 fsmGetFrame(S32 ch,U8 err_flag);
static U16 frameSetPack(U16 _data_len,U8* _data_buf,U8 _type,U8 * _send_buff);
static void fsmSendFrame(U8 _ack,U16 _data_len,U8 *_data_buf);
//static void fsmSendFrameForPostEnroll(U8 _ack,U16 _data_len,U8 *_data_buf,S32 (*mafp_post_enroll)(void));
static void fsmSendFrameTmp(U8 _ack,U16 _data_len,U8 *_data_buf,U32 addr);                  // for setaddr
static U16 frameSetPackTmp(U16 _data_len,U8* _data_buf,U8 _type,U8 * _send_buff,U32 addr);  //for setaddr
static void recvTimeoutProcess(void);
static void initDownLoadTag(void);
static void fsmDownLoadTask(void);
//static void fsmUpLoadTask(void);
static void fsmUploadImage(void);
static void initUploadTag(void);
static void setUpLoadTaskDoneFlag(void);
static void fsmDownImage(void);
static void fsmVfyPwd(void);
static void fsmSetPwd(void);
static void fsmSetAddr(void);
static void fsmSetSysPara(void);
static void fsmGetSysPara(void);
static void fsmGetIdList(void);
static void fsmGetIdNum(void);
static void fsmDeleteID(void);
static void fsmEmptyId(void);
static void fsmEnroll(void);
static void fsmMatch(void);
static void fsmInitSystem(void);
static void fsmInitSensor(void);
static void fsmHandshake(void);
static void fsmEnDebugPrint(void);
static void fsmDebugGetPara(void);
static void fsmDebugUpdate(void);
static void fsmDebugEnrollAfterDownLoad(void);
static void fsmDebugMatchAfterDownLoad(void);
static void fsmDebugResetTemplateStorage(void);
static void fsmDebugReadAllFlash(void);
static void fsmSendDataTask(U8 flag);
static void fsmSwitchProtocol(void);
static void fsmDeleteMultiId(void);
static void fsmConfigEnroll(void);
static void fsmConfigMatch(void);
static void fsmBurnCodeTime(void);
static void fsmCheckDetectMode(void);
static void fsmIsFingerLeave(void);
static void fsmReceiveData(void);
static void fsmDownData(void);
static void fsmStoreData(void);
static void fsmTestButton1(void);
static void fsmTestButton2(void);
static void fsmTestButton3(void);
static void fsmTestButton4(void);
static void fsmResetSensorConfig(void);
static void fsmDebugUpdatePreMove1(void);
static void fsmDebugUpdatePreMove2(void);
static void maOpenCmdForOtherProtocol(S32 ch);
static void  refreshRecTimeout(void);
static void fsmReadBoardCfg(void);
static void fsmWriteBoardCfg(void);
static void fsmFactoryTestVfy(void);
static void fsmFactoryTest(void);
void factoryTestfsmCallback(MmiTestCmdRes res, uint8_t result);

static U8  Last_Data_Flag=0;
static void (*g_frame_func[FRAME_MAX])(void);
static U8 g_recv_buff[512];
static U8 g_send_buff[512];
static U8 Burn_Code_Time_Buff[130];
static U8 Debug_Update_flag=0;
static U32 recv_len = 0;




///////////////////////////////////////////////////////////////////////main func//////////////////////////////////////////////////


void fsmInit(void)
{
	memset(g_frame_func, 0, sizeof(g_frame_func));
	g_frame_func[ENROLL] = fsmEnroll;
	g_frame_func[SERACH] = fsmMatch;
	g_frame_func[Delete_ID] = fsmDeleteID;
	g_frame_func[EMPTY_ID] = fsmEmptyId;
	g_frame_func[SET_SYS_PARA] = fsmSetSysPara;
	g_frame_func[GET_SYS_PARA] = fsmGetSysPara;
	g_frame_func[SET_PWD] = fsmSetPwd;
	g_frame_func[VFY_PWD] = fsmVfyPwd;
	g_frame_func[GET_RANDOM] = NULL;
	g_frame_func[SET_ADDR] = fsmSetAddr;
	g_frame_func[GET_ID_NUM] = fsmGetIdNum;
	g_frame_func[GET_ID_LIST] = fsmGetIdList;
	g_frame_func[DOWN_IMAGE] = fsmDownImage;
	g_frame_func[UPLOAD_IMAGE] = fsmUploadImage;
	g_frame_func[INIT_SYSTEM] =fsmInitSystem;
	g_frame_func[DEVICE_READY]=deviceReady;
	g_frame_func[INIT_SENSOR] =fsmInitSensor;
	g_frame_func[HAND_SHAKE]=fsmHandshake;
	g_frame_func[CONFIG_ENROLL]=fsmConfigEnroll;
	g_frame_func[CONFIG_MATCH]=fsmConfigMatch;
	g_frame_func[SWITCH_PROTOCOL]=fsmSwitchProtocol;
	g_frame_func[RESET_SENSOR_CONFIG]=fsmResetSensorConfig;
	g_frame_func[FACTORY_TEST_VFY]=fsmFactoryTestVfy;
	g_frame_func[FACTORY_TEST]=fsmFactoryTest;
	g_frame_func[READ_BOARD_CFG]=fsmReadBoardCfg;
	g_frame_func[WRITE_BOARD_CFG]=fsmWriteBoardCfg;
	g_frame_func[DEBUG_PRINT_EN]=fsmEnDebugPrint;
	g_frame_func[DEBUG_GET_PARA]=fsmDebugGetPara;
	g_frame_func[DEBUG_UPDATE]=fsmDebugUpdate;
	g_frame_func[DEBUG_ENROLL_AFTER_DOWNLOAD]=fsmDebugEnrollAfterDownLoad;
	g_frame_func[DEBUG_MATCH_AFTER_DOWNLOAD]= fsmDebugMatchAfterDownLoad;
	g_frame_func[DEBUG_RESET_TEMPLATE_STORAGE]=fsmDebugResetTemplateStorage;
	g_frame_func[DEBUG_READ_ALL_FLASH]=fsmDebugReadAllFlash;
	g_frame_func[Delete_MULTI_ID]=fsmDeleteMultiId;
	g_frame_func[DEBUG_READ_BURN_CODE_TIME]=fsmBurnCodeTime;
	g_frame_func[DEBUG_CHECK_DETECT_MODE]=fsmCheckDetectMode;
	g_frame_func[DEBUG_IS_FINGER_LEAVE]=fsmIsFingerLeave;
	g_frame_func[DEBUG_DOWNLOAD_DATA]=fsmDownData;
	g_frame_func[DEBUG_RECEIVE_DATA]=fsmReceiveData;
	g_frame_func[DEBUG_STORE_DATA]=fsmStoreData;
	g_frame_func[DEBUG_TEST_BUTTON1]=fsmTestButton1;
	g_frame_func[DEBUG_TEST_BUTTON2]=fsmTestButton2;
	g_frame_func[DEBUG_TEST_BUTTON3]=fsmTestButton3;
	g_frame_func[DEBUG_TEST_BUTTON4]=fsmTestButton4;
	g_frame_func[DEBUG_UPDATE_PRE_MOVE1]=fsmDebugUpdatePreMove1;
	g_frame_func[DEBUG_UPDATE_PRE_MOVE2]=fsmDebugUpdatePreMove2;
	g_fsm_state = STATE_IDLE;

	initUploadTag();
	initDownLoadTag();

#if PERIPH_BT_ENABLE && BT_PROTOCOL_MICROARRAY
	unsigned char cust_addr[6] = {0xFA, 0x23, 0x45, 0x00, 0x0F, 0x72};
	unsigned char ma_adv_frame[MA_BT_ADV_LEN] = {0x02, 0x01, 0x04, 0x07, 0xFF};

	platform_bluetooth_set_context(cust_addr);
	memcpy(&ma_adv_frame[5], cust_addr, 6);
	platform_bluetooth_set_adv_data(ma_adv_frame, MA_BT_ADV_LEN);
	platform_bluetooth_set_ble_name(bsp_ctx.bt_adv_name, strlen((char *)(bsp_ctx.bt_adv_name)));
#endif
}

U8  fsmCRC(U8 *dat, U32 len)
{
	U8 crc8 = 0;
	while(len--){
		crc8 = CRC8Table[crc8 ^ *dat];
		dat++;
	}
	return crc8;
}


/*add for compatible uart and BT begin*/
uint8_t fsmFrameCheck(uint8_t const* frame,uint8_t recv_len)
{
	U32 device_addr;
	U16 frame_len=0;

	if(recv_len < FRAME_STA_LEN) {
		return PS_FRAME_LENGTH_ERR;
	}

	/*verify frame head*/
	if (!(frame[0] == (FRAME_START>>8) && frame[1] == (FRAME_START&0x00ff))) {
		return PS_FRAME_HEAD_ERR;
	}

	/*verify device addr whether correct*/
	device_addr=(frame[2] << 8) + frame[3];
	device_addr=(device_addr << 16) + (frame[4] << 8) + frame[5];
	if( (device_addr!=Sys_ParaTag.device_add) && (device_addr != 0)) {
		return PS_DEVICE_ADDR_ERR;
	}

	/*verify frame lenght */
	frame_len=(frame[FRAME_LEN_HIGH ]);
	frame_len<<=8;
	frame_len|=(frame[FRAME_LEN_LOW ]);
	if(frame_len>FRAME_MOST_LEN) {
		return PS_RECV_ERR;
	}

	return PS_OK;
}


static S32 fsmGetFrame_v2(uint8_t const* frame,uint8_t recv_len)
{

	U16 frame_len=0;
	U8 pid=0;
	U8 tmp[2]={0};
	tmp[0]=0;
	tmp[1]=PS_OK;
	uint8_t ret;

	ret = fsmFrameCheck(frame, recv_len);
	if(ret != PS_OK) {
		MALOGE("check frame err: 0x%x", ret);
		tmp[1]=ret;
		fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
		return 0;
	}

	memcpy(g_recv_buff, frame, recv_len);
	frame_len = (g_recv_buff[FRAME_LEN_HIGH]);
	frame_len <<= 8;
	frame_len |= (g_recv_buff[FRAME_LEN_LOW]);
	frame_len += FRAME_STA_LEN;

	if(recv_len >= frame_len) {
		if( fsmCRC(g_recv_buff,frame_len-1) ==  g_recv_buff[frame_len-1]) {
			pid=g_recv_buff[FRAME_PID];
			if( (pid==PID_COMMAND) ||  (pid == PID_DATA )|| (pid==PID_DATA_ACK)) {
				Last_Data_Flag=0;
			} else if(pid == PID_LAST_DATA) {
				Last_Data_Flag=1;
			} else {
				MALOGE("fetch pid error");
				tmp[1]=PS_PID_ERR ;
				fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
				return 0;
			}
			return frame_len;
		} else {
			MALOGE("CRC error");
			tmp[1]=PS_COMM_ERR;
			//if(err_flag)
				fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
			return 1;
		}
	}

	return 0;
}


void maFsmTask_v2(uint8_t const* frame, uint8_t len)
{
	U8 command;
	U8 tmp_buf[2]={0};

#ifdef DEBUG_LOG
	U8 i;

	printf("frame receive:");
	for(i = 0; i < len; i++) {
		printf("0x%x ", frame[i]);
	}
	printf("\n");
#endif

	if (fsmGetFrame_v2(frame, len))
	{
		/* if enable passwd verify*/
		if(Sys_ParaTag.en_passwd) {
			if( (g_recv_buff[9]==VFY_PWD) && (PID_COMMAND ==g_recv_buff[FRAME_PID])) {
				fsmVfyPwd();
				return;
			}

			if((!Gl_Password)&&(g_recv_buff[9]!=INIT_SYSTEM)) {
				tmp_buf[0]=VFY_PWD;//ָ��
				tmp_buf[1]=PS_MUST_VERIFY_PWD;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
				return ;
			}
		}

		/*handle each command */
		if(PID_COMMAND ==g_recv_buff[FRAME_PID]) {
			command = g_recv_buff[FRAME_STA_LEN];
			if( (command>0) && (command<FRAME_MAX) && (g_frame_func[command])) {
				g_frame_func[command]();
			} else {
				tmp_buf[0]=0;
				tmp_buf[1]=PS_COMMAND_ERR ;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			}
		}
		/*if it is upload command*/
		else if( (PID_DATA  ==g_recv_buff[FRAME_PID] ) || (PID_LAST_DATA  == g_recv_buff[FRAME_PID]) )
		{
			fsmDownLoadTask();
		}
		else if(PID_DATA_ACK  == g_recv_buff[FRAME_PID])
		{
			setUpLoadTaskDoneFlag();
		}
	} else if(g_fsm_state == STATE_UPLOAD) {
		setUpLoadTaskDoneFlag();
	}
}
/*add for compatible uart and BT end*/


void fsmTask(S32 ch)
{

	switch(Protocol)
	{
	case PROTOCOL_MICROARRAY_COMPATIBLE_SYNOCHIP:
		maOpenCmdForOtherProtocol(ch);
		//synocFsmTask(ch);
		break;

	case PROTOCOL_MICROARRAY_COMPATIBLE_YALE:
		maOpenCmdForOtherProtocol(ch);
		//yaleFsmTask(ch);
		break;

	default:
		maFsmTask(ch);
		break;
	}
}


static void maFsmTask(S32 ch)
{
	U8 command;
	U8 tmp_buf[2]={0};
	recvTimeoutProcess();
	if (ch >= 0)
	{
		if (fsmGetFrame(ch,0))
		{
			if(Sys_ParaTag.en_passwd)
			{
				if( (g_recv_buff[9]==VFY_PWD) && (PID_COMMAND ==g_recv_buff[FRAME_PID]))
				{
					fsmVfyPwd();
					return;
				}

				if((!Gl_Password)&&(g_recv_buff[9]!=INIT_SYSTEM))
				{
					tmp_buf[0]=VFY_PWD;
					tmp_buf[1]=PS_MUST_VERIFY_PWD;
					fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
					return ;
				}
			}
			if(PID_COMMAND ==g_recv_buff[FRAME_PID])
			{
				command = g_recv_buff[9];
				if( (command>0) && (command<FRAME_MAX) &&(g_frame_func[command]) )
				{
					g_frame_func[command]();
				}
				else
				{
					tmp_buf[0]=0;
					tmp_buf[1]=PS_COMMAND_ERR ;
					fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
				}
			}
			else if( (PID_DATA  ==g_recv_buff[FRAME_PID] ) || (PID_LAST_DATA  == g_recv_buff[FRAME_PID]) )
			{
				fsmDownLoadTask();
			}
			else if(PID_DATA_ACK  ==g_recv_buff[FRAME_PID])
			{
				setUpLoadTaskDoneFlag();
			}
		}
	}
	else if(g_fsm_state == STATE_UPLOAD)
	{
		fsmUpLoadTask();
	}
}

static void maOpenCmdForOtherProtocol(S32 ch)
{
	U8 command;
	recvTimeoutProcess();
	if(ch>=0)
	{
		if (fsmGetFrame(ch,0))
		{
			if(PID_COMMAND ==g_recv_buff[FRAME_PID])
			{
				command = g_recv_buff[9];
				if( (command>0) && (command<FRAME_MAX) &&(g_frame_func[command])&&
				    (IS_MICROARRAY_COMPATIBLE_SYNOCHIP_VAILD_FUNC(command)) )
				{
					g_frame_func[command]();
				}
			}
		}
	}
}



/////////////////////////////////////////////////////////tool func ////////////////////////////////////////////

static U16 frameSetPack(U16 _data_len,U8* _data_buf,U8 _type,U8 * _send_buff)
{

	U8 nwCHK = 0;
	if(_send_buff&&_data_buf)
	{
		/*make packet head*/
		_send_buff[0] = (FRAME_START>>8);
		_send_buff[1] = FRAME_START &0x00ff;
		_send_buff[2] = (Sys_ParaTag.device_add>>24)&0xff;
		_send_buff[3] = (Sys_ParaTag.device_add>>16)&0xff;
		_send_buff[4] = (Sys_ParaTag.device_add>>8)&0xff;
		_send_buff[5] = Sys_ParaTag.device_add&0xff;
		_send_buff[6] = _type;
		_send_buff[7] = ((_data_len+FRAME_CRC) >> 8) & 0xff;
		_send_buff[8] = (_data_len+FRAME_CRC) & 0xff;

		memcpy(&g_send_buff[FRAME_STA_LEN],_data_buf,_data_len);
		nwCHK=fsmCRC(g_send_buff,_data_len+FRAME_STA_LEN);

		g_send_buff[_data_len+FRAME_STA_LEN]=nwCHK;

		return (_data_len+FRAME_CRC+FRAME_STA_LEN);
	}
	else
	{
		return 0;
	}

}


static void fsmSendFrame(U8 _ack,U16 _data_len,U8 *_data_buf)
{
	U16 len;
	if(_data_buf)
	{
		len=frameSetPack(_data_len, _data_buf, _ack, g_send_buff);
		
#ifdef DEBUG_LOG
	U8 i;

	printf("frame send:");
	for(i = 0; i < len; i++) {
		printf("0x%x ", g_send_buff[i]);
	}
	printf("\n");
#endif
		
		if(g_packet_type == TYPE_UART_PACKAGE) platform_uart_send_buff(g_send_buff, len);
		else if(g_packet_type == TYPE_BT_PACKAGE) {
			platform_bluetooth_send_notification(g_send_buff, len);
		}
	}
}


/*static void fsmSendFrameForPostEnroll(U8 _ack,U16 _data_len,U8 *_data_buf,S32 (*mafp_post_enroll)(void))
{
	U16 len;
	if(_data_buf)
	{
		len=frameSetPack(_data_len, _data_buf, _ack, g_send_buff);
		if(g_packet_type == TYPE_UART_PACKAGE) platform_uart_send_buff(g_send_buff, 6);
		else if(g_packet_type == TYPE_BT_PACKAGE) platform_bluetooth_send_notification(g_send_buff, 6); 
		mafp_post_enroll();
		if(g_packet_type == TYPE_UART_PACKAGE) platform_uart_send_buff(g_send_buff+6, len-6);
		else if(g_packet_type == TYPE_BT_PACKAGE) platform_bluetooth_send_notification(g_send_buff+6, len-6);
	}
}*/



static U16 frameSetPackTmp(U16 _data_len,U8* _data_buf,U8 _type,U8 * _send_buff,U32 addr)
{
	U8 nwCHK = 0;
	if(_send_buff&&_data_buf)
	{
		/*make packet head*/
		_send_buff[0] = (FRAME_START>>8);
		_send_buff[1] = FRAME_START &0x00ff;
		_send_buff[2] = (addr>>24)&0xff;
		_send_buff[3] = (addr>>16)&0xff;
		_send_buff[4] = (addr>>8)&0xff;
		_send_buff[5] = addr&0xff;
		_send_buff[6] = _type;
		_send_buff[7] = ((_data_len+FRAME_CRC) >> 8) & 0xff;
		_send_buff[8] = (_data_len+FRAME_CRC) & 0xff;
		memcpy(&g_send_buff[FRAME_STA_LEN],_data_buf,_data_len);
		nwCHK=fsmCRC(g_send_buff,_data_len+FRAME_STA_LEN);
		g_send_buff[_data_len+FRAME_STA_LEN]=nwCHK;
		return (_data_len+FRAME_CRC+FRAME_STA_LEN);
	}
	else
	{
		return 0;
	}

}

static void fsmSendFrameTmp(U8 _ack,U16 _data_len,U8 *_data_buf,U32 addr)
{
	U16 len;
	if(_data_buf)
	{
		len=frameSetPackTmp(_data_len, _data_buf, _ack, g_send_buff, addr);
		if(g_packet_type == TYPE_UART_PACKAGE) platform_uart_send_buff(g_send_buff, len);
		else if(g_packet_type == TYPE_BT_PACKAGE) platform_bluetooth_send_notification(g_send_buff, len);
	}
}

static S32 fsmGetFrame(S32 ch,U8 err_flag)
{
	U32 device_addr;
	U16 frame_len=0;
	U8 pid=0;
	U8 tmp[2]={0};
	tmp[0]=0;
	tmp[1]=PS_OK;
	if (recv_len == 0)
	{
		if ( ch == (FRAME_START>>8) )
		{
			g_recv_buff[recv_len++] = ch;
		}
	}
	else if(recv_len == 1)
	{
		if ( ch == (FRAME_START&0x00ff) )
		{
			g_recv_buff[recv_len++] = ch;
		}
		else
		{
			recv_len=0;
			return 0;
		}
	}
	else
	{
		g_recv_buff[recv_len++] = ch;
		if(recv_len == 6)
		{
			device_addr=( (g_recv_buff[2]<<8)+g_recv_buff[3]);
			device_addr=( ( device_addr<<16)+(g_recv_buff[4]<<8)+g_recv_buff[5]);
			if( (device_addr!=Sys_ParaTag.device_add) && (device_addr!=0))
			{
				recv_len=0;
				tmp[1]=PS_DEVICE_ADDR_ERR;
				if(err_flag)
					fsmSendFrameTmp(PID_ACK ,0x02,&tmp[0],0);
				return 0;
			}

		}
		else if(recv_len >= FRAME_STA_LEN)
		{

			frame_len=(g_recv_buff[FRAME_LEN_HIGH ]);
			frame_len<<=8;
			frame_len|=(g_recv_buff[FRAME_LEN_LOW ]);

			if(frame_len>FRAME_MOST_LEN)
			{
				recv_len=0;
				tmp[1]=PS_RECV_ERR;
				if(err_flag)
					fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
				return 0;
			}

			frame_len+=FRAME_STA_LEN;

			if(recv_len >=frame_len)
			{
				recv_len=0;
				if( fsmCRC(g_recv_buff,frame_len-1) ==  g_recv_buff[frame_len-1]  )
				{
					pid=g_recv_buff[FRAME_PID];
					if( (pid==PID_COMMAND) ||  (pid == PID_DATA )|| (pid==PID_DATA_ACK ))
					{
						Last_Data_Flag=0;
					}
					else if(pid == PID_LAST_DATA)
					{
						Last_Data_Flag=1;
					}
					else
					{
						tmp[1]=PS_PID_ERR ;
						if(err_flag)
							fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
						return 0;
					}
					return frame_len;
				}
				else
				{
					tmp[1]=PS_COMM_ERR;
					if(err_flag)
						fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
					return 0;

				}
			}
		}
	}
	return 0;
}







/////////////////////////////////////////////////////////recv timeout////////////////////////////////////////////////
#define NREC_TIMEOUT (20) //ms
static	U16 nold_RecNum=0;
volatile static  U32 nrec_TimeOut=0;
volatile static  U32 base_TimeOut=0;

static void recvTimeoutProcess(void)
{
	if(recv_len==0)
	{
		nrec_TimeOut=0;
		nold_RecNum=0;
	}

	if(nold_RecNum!=recv_len)
	{
		base_TimeOut=platform_timer_ms_tick();
		nold_RecNum=recv_len;

	}
	else
	{
		nrec_TimeOut=platform_timer_ms_tick();
		if(recv_len&&(nrec_TimeOut>(NREC_TIMEOUT+base_TimeOut)))
		{
			recv_len=0;
		}
	}
}

static void  refreshRecTimeout(void)
{
	base_TimeOut=platform_timer_ms_tick();
}







//////////////////////////////////////////down func///////////////////////////////////////////////////


typedef struct
{
	U8* download_buff;
	U32 download_len;
	U32 download_data_offset;
	U32 nums;
	U32 last_nums;
	U8  is_download_image_value;
	S8  name[256];
}_DownLoadTag;

static _DownLoadTag DownLoad_Tag={0};

static void initDownLoadTag(void)
{
	DownLoad_Tag.download_buff=NULL;
	DownLoad_Tag.download_data_offset=0;
	DownLoad_Tag.download_len=0;
	DownLoad_Tag.nums=0;
	DownLoad_Tag.last_nums=0;
	DownLoad_Tag.is_download_image_value=0;
	memset(&DownLoad_Tag.name[0],0,sizeof(DownLoad_Tag.name));
}

static void fsmDownImage(void)
{
	U8 tmp_buf[2]={0}, *dst=NULL;
	U32 len=0, buflen;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	initDownLoadTag();
	g_fsm_state = STATE_IDLE;
	len=(g_recv_buff[10] << 16) | (g_recv_buff[11] << 8) | g_recv_buff[12];

	buflen = sensor_get_download_buf((uint8_t *)"raw_image.bmp", &dst, len);
	if( (len>0) && (buflen>0) && dst)
	{
		g_fsm_state = STATE_DOWNLOAD;
		DownLoad_Tag.download_buff=dst;
		DownLoad_Tag.download_len=len;
	}
	else
	{
		tmp_buf[1]=PS_PARAM_ERROR;
		g_fsm_state = STATE_IDLE;
	}
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);

}



static void fsmDownData(void)
{
	U8 tmp_buf[2]={0}, *dst=NULL;
	U32 len=0, buflen;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	initDownLoadTag();
	g_fsm_state = STATE_IDLE;
	fsmDebugPrint("DownData\n");
	len=(g_recv_buff[10] << 16) | (g_recv_buff[11] << 8) | g_recv_buff[12];
	memcpy(&DownLoad_Tag.name[0],&g_recv_buff[13],251);
	DownLoad_Tag.name[250]='\0';
	extern int32_t sensor_get_download_buf(uint8_t *name, uint8_t **dst_addr, uint32_t size);
	buflen = sensor_get_download_buf((uint8_t *)DownLoad_Tag.name, &dst, len);
	if( (len>0) && (buflen>0) && dst)
	{
		g_fsm_state = STATE_DOWNLOAD;
		DownLoad_Tag.download_buff=dst;
		DownLoad_Tag.download_len=len;
	}
	else
	{
		tmp_buf[1]=PS_PARAM_ERROR;
		g_fsm_state = STATE_IDLE;
	}
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmDownLoadTask(void)
{
	U32 nums=0,data_len=0;
	U8 tmp[4];

	if(g_fsm_state == STATE_DOWNLOAD)
	{
		tmp[0]=g_recv_buff[FRAME_STA_LEN ];
		tmp[1]=g_recv_buff[FRAME_STA_LEN +1];
		tmp[2]=PS_DOWN_IMG_ERR;

		if( DownLoad_Tag.download_buff != NULL)
		{
			data_len = ( ( (g_recv_buff[FRAME_LEN_HIGH] << 8) | g_recv_buff[FRAME_LEN_HIGH+1])-3);
			nums = ((g_recv_buff[9] << 8) | g_recv_buff[10]);

			if( (DownLoad_Tag.download_data_offset+data_len) <= DownLoad_Tag.download_len)
			{
				if( nums == DownLoad_Tag.nums)
				{
					memcpy(DownLoad_Tag.download_buff+DownLoad_Tag.download_data_offset,&g_recv_buff[FRAME_STA_LEN+2],data_len);
					DownLoad_Tag.download_data_offset+=data_len;
					DownLoad_Tag.nums++;
					tmp[2]=PS_OK;
				}
				else if(nums == DownLoad_Tag.last_nums)
				{
					tmp[2]=PS_OK;
				}
				DownLoad_Tag.last_nums=nums;
			}
		}

		if( Last_Data_Flag)
		{
			g_fsm_state=STATE_IDLE;
			Last_Data_Flag=0;
			if(DownLoad_Tag.download_data_offset == DownLoad_Tag.download_len)
			{
				tmp[2]=PS_OK;
				DownLoad_Tag.is_download_image_value=1;
			}
		}
		fsmSendFrame(PID_DATA_ACK ,0x03,&tmp[0]);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////upload func///////////////////////////////////

typedef struct
{
	U8 * upload_buff;
	U8 upload_cmd;
	S32 upload_len;
	U32 upload_data_offset;
	U32 nums;
	U32 timeout;
	U16 pos;
	U16 off;
	U16 len;
	U16 resend_now_times;
	U16 resend_max_times;
	_Status status;
	U32 start_tick;
	U8 tmp_buff[256];
}_UploadTag;

static _UploadTag UpLoad_Tag={0};

static void initUploadTag(void)
{
	UpLoad_Tag.upload_buff=NULL;
	UpLoad_Tag.upload_len=0;
	UpLoad_Tag.upload_data_offset=0;
	UpLoad_Tag.nums=0;
	UpLoad_Tag.timeout=3*1000*1000;
	UpLoad_Tag.off=0;
	UpLoad_Tag.pos=0;
	UpLoad_Tag.resend_max_times=5;
	UpLoad_Tag.resend_now_times=0;
	UpLoad_Tag.start_tick = platform_timer_us_tick();
	memset(UpLoad_Tag.tmp_buff,0,sizeof(UpLoad_Tag.tmp_buff));
	UpLoad_Tag.status=idle;
}

static void fsmUploadImage(void)
{
	U16 width=0,height=0;
	U8 tmp[10]={0},type=0;

	tmp[0]=g_recv_buff[FRAME_STA_LEN];
	tmp[1]=PS_OK;
	type=g_recv_buff[FRAME_STA_LEN+1];
	initUploadTag();
	g_fsm_state = STATE_IDLE;
	UpLoad_Tag.upload_cmd=UPLOAD_IMAGE;

	switch (type)
	{
	case 1:
		UpLoad_Tag.upload_len = sensor_get_upload_image_buf(IMAGE_REALTIME, &UpLoad_Tag.upload_buff, &width, &height);
		break;
	case 2:
		UpLoad_Tag.upload_len = sensor_get_upload_image_buf(IMAGE_BACKGROUD, &UpLoad_Tag.upload_buff, &width, &height);
		break;
	case 3:
		UpLoad_Tag.upload_len = sensor_get_upload_image_buf(IMAGE_RMV_BKG, &UpLoad_Tag.upload_buff, &width, &height);
		break;
	case 4:
		UpLoad_Tag.upload_len = sensor_get_upload_image_buf(IMAGE_ENROLL, &UpLoad_Tag.upload_buff, &width, &height);
		break;
	case 5:
		UpLoad_Tag.upload_len = sensor_get_upload_image_buf(IMAGE_AUTHEN, &UpLoad_Tag.upload_buff, &width, &height);
		break;
	case 6:
		UpLoad_Tag.upload_len = sensor_get_upload_image_buf(IMAGE_TESTING, &UpLoad_Tag.upload_buff, &width, &height);
		break;
	default:
		tmp[1]=PS_PARAM_ERROR;
		break;
	}
	if(UpLoad_Tag.upload_buff && (UpLoad_Tag.upload_len>0) )
	{
		g_fsm_state = STATE_UPLOAD;
		tmp[2]=(UpLoad_Tag.upload_len>>16)&0xff;
		tmp[3]=(UpLoad_Tag.upload_len>>8)&0xff;
		tmp[4]=(UpLoad_Tag.upload_len)&0xff;
		tmp[5]=(width>>8)&0xff;
		tmp[6]=width&0xff;
		tmp[7]=(height>>8)&0xff;
		tmp[8]=height&0xff;
		UpLoad_Tag.len=(Frame_Data_Size-3);
		UpLoad_Tag.pos=UpLoad_Tag.upload_len/UpLoad_Tag.len;
		UpLoad_Tag.off=UpLoad_Tag.upload_len%UpLoad_Tag.len;
		UpLoad_Tag.status=running;
	}
	else
	{
		tmp[1]= PS_UP_IMG_ERR;
	}
	fsmSendFrame(PID_ACK ,0x09,&tmp[0]);
	platform_msleep(5);

	lock_async_call_wrapper(BSP_uploadImage_process, NULL);
}

static void setUpLoadTaskDoneFlag(void)
{
	if(g_fsm_state == STATE_UPLOAD)
	{
		UpLoad_Tag.status=done;
		lock_async_call_wrapper(BSP_uploadImage_process, NULL);
	}
}


void fsmUpLoadTask(void)
{

	U8 res;
	U16 nums;
	U8 tmp[6]={0};

	if(g_fsm_state == STATE_UPLOAD)
	{
		switch(UpLoad_Tag.status)
		{
		case idle:
			g_fsm_state = STATE_IDLE;
			break;
		case running:
			if((UpLoad_Tag.upload_buff)&&(UpLoad_Tag.upload_data_offset<=UpLoad_Tag.upload_len)
			   &&(UpLoad_Tag.resend_now_times<UpLoad_Tag.resend_max_times))
			{
				UpLoad_Tag.status=busy;
				UpLoad_Tag.start_tick = platform_timer_us_tick();
				UpLoad_Tag.tmp_buff[0]=UpLoad_Tag.nums>>8;
				UpLoad_Tag.tmp_buff[1]=UpLoad_Tag.nums&0xff;

				if(UpLoad_Tag.nums<UpLoad_Tag.pos)
				{
					memcpy(&UpLoad_Tag.tmp_buff[2],UpLoad_Tag.upload_buff+UpLoad_Tag.nums*UpLoad_Tag.len,UpLoad_Tag.len);
					UpLoad_Tag.upload_data_offset=UpLoad_Tag.nums*UpLoad_Tag.len+UpLoad_Tag.len;
					if( (UpLoad_Tag.nums==(UpLoad_Tag.pos-1) ) && (UpLoad_Tag.off==0))
					{
						fsmSendFrame(PID_LAST_DATA,UpLoad_Tag.len+2,&UpLoad_Tag.tmp_buff[0]);
					}
					else
					{
						fsmSendFrame(PID_DATA,UpLoad_Tag.len+2,&UpLoad_Tag.tmp_buff[0]);
					}

				}
				else if(UpLoad_Tag.nums==UpLoad_Tag.pos)
				{
					if(UpLoad_Tag.off>0)
					{
						memcpy(&UpLoad_Tag.tmp_buff[2],UpLoad_Tag.upload_buff+UpLoad_Tag.nums*UpLoad_Tag.len,UpLoad_Tag.off);
						UpLoad_Tag.upload_data_offset=UpLoad_Tag.nums*UpLoad_Tag.len+UpLoad_Tag.off;
						fsmSendFrame(PID_LAST_DATA,UpLoad_Tag.off+2,&UpLoad_Tag.tmp_buff[0]);
					}
				}
			}
			break;
		case busy:
			if( calculateTimeElapse(UpLoad_Tag.start_tick) > UpLoad_Tag.timeout)
			{
				UpLoad_Tag.status=running;
				UpLoad_Tag.resend_now_times++;
			}

			if(UpLoad_Tag.resend_now_times>=UpLoad_Tag.resend_max_times)
			{
				g_fsm_state = STATE_IDLE;
				tmp[0]=UpLoad_Tag.upload_cmd;
				tmp[1]=PS_TIMEOUT;
				fsmSendFrame(PID_ACK ,0x05,&tmp[0]);
			}
			break;

		case done:
			nums=g_recv_buff[FRAME_STA_LEN ];
			nums=(nums<<8)+g_recv_buff[FRAME_STA_LEN +1];
			res=g_recv_buff[FRAME_STA_LEN+2];
			if(res==PS_OK )
			{
				UpLoad_Tag.status=running;
				UpLoad_Tag.resend_now_times=0;
				if(UpLoad_Tag.nums == nums)
				{
					UpLoad_Tag.nums++;
					//MALOGE("%d %d %d", res, UpLoad_Tag.upload_data_offset, UpLoad_Tag.upload_len);
					if(UpLoad_Tag.upload_data_offset == UpLoad_Tag.upload_len)
						g_fsm_state = STATE_IDLE;
				}

				lock_async_call_wrapper(BSP_uploadImage_process, NULL);
			}
			else if((res == PS_UP_IMG_ERR)|| (res == PS_UP_CHAR_ERR))
			{
				g_fsm_state = STATE_IDLE;
				tmp[0]=UpLoad_Tag.upload_cmd;
				tmp[1]=res;
				fsmSendFrame(PID_ACK ,0x05,&tmp[0]);
			}
			else
				UpLoad_Tag.status=busy;
			break;
		default:
			g_fsm_state = STATE_IDLE;
			break;
		}
		refreshRecTimeout();
	}
}


///////////////////////////////////////////////////////////////enroll func///////////////////////////////////////////////////////

void fsmEnrollCallback(u8 step)
{	
	u8 result[2];

	result[0] = Enroll_Tag.enroll_cmd;
	if(step >= Enroll_Tag.enroll_press_times) {
		result[1] = PS_OK;
	} else {
		result[1] = PS_NO_ERROR;
	}
	fsmSendFrame(PID_ACK ,0x02,&result[0]);
}
static void fsmEnroll(void)
{
	U8 tmp[2]={0};
	U16 id;
	tmp[0]=g_recv_buff[FRAME_STA_LEN];
	g_fsm_state = STATE_IDLE;

	tmp[1] = PS_RESPONSE;
	fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
	id = (g_recv_buff[FRAME_STA_LEN + 1] << 8) | g_recv_buff[FRAME_STA_LEN + 2];
	mafp_cancel_enroll();
	Enroll_Tag.enroll_press_times = DEFAULT_ENROLL_TIMES;
	Enroll_Tag.enroll_timeout = ENROLL_TIMEOUT_DEFAULT;
	Enroll_Tag.enroll_id = id;
	Enroll_Tag.enroll_cb = fsmEnrollCallback;
	if ( Enroll_Tag.enroll_id >= MAX_ID)
	{
		platform_msleep(5);
		tmp[1]=PS_ADDRESS_OVER;
		fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
	}
	else if( (mafp_get_enrollid_status(Enroll_Tag.enroll_id))== 1)
	{
		platform_msleep(5);
		tmp[1]=PS_ID_ALREADY_EXIST;
		fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
	}
	else
	{
		g_fsm_state = STATE_ENROLL;
		Enroll_Tag.start_tick = platform_timer_us_tick();
		Enroll_Tag.enroll_cmd=ENROLL;
	}
}


static void fsmConfigEnroll(void)
{
	U8 tmp[2]={0},timeout=0;
	U16 id;
	tmp[0] = g_recv_buff[FRAME_STA_LEN];
	g_fsm_state = STATE_IDLE;
	tmp[1]=PS_RESPONSE;
	fsmSendFrame(PID_ACK ,0x02,&tmp[0]);

	mafp_cancel_enroll();
	Enroll_Tag.enroll_timeout = ENROLL_TIMEOUT_DEFAULT;
	id = (g_recv_buff[FRAME_STA_LEN + 1] << 8) | g_recv_buff[FRAME_STA_LEN + 2];
	Enroll_Tag.enroll_id = id;
	Enroll_Tag.enroll_press_times = g_recv_buff[FRAME_STA_LEN+3];
	timeout = g_recv_buff[FRAME_STA_LEN+4];
	Enroll_Tag.enroll_cb = fsmEnrollCallback;

	if( (Enroll_Tag.enroll_press_times == 0) )//|| (Enroll_Tag.enroll_press_times > mafp_get_max_subtpl_num()) )
		Enroll_Tag.enroll_press_times = DEFAULT_ENROLL_TIMES;

	if(timeout <= 60)
		Enroll_Tag.enroll_timeout = timeout*1000*1000;

	if ( (Enroll_Tag.enroll_id >= MAX_ID))
	{
		platform_msleep(5);
		tmp[1]=PS_ADDRESS_OVER;
		fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
	}
	else if( (mafp_get_enrollid_status(Enroll_Tag.enroll_id)) == 1)
	{
		platform_msleep(5);
		tmp[1]=PS_ID_ALREADY_EXIST;
		fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
	}
	else
	{
		g_fsm_state = STATE_ENROLL;
		Enroll_Tag.start_tick = platform_timer_us_tick();
		Enroll_Tag.enroll_cmd=CONFIG_ENROLL;
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////Match Func/////////////////////////////////////////////////////
static void fsmMatch(void)
{
	U8 tmp[4]={0};
	tmp[0]=g_recv_buff[FRAME_STA_LEN];
	tmp[1]=PS_RESPONSE;
	fsmSendFrame(PID_ACK ,0x04,&tmp[0]);
	Match_Tag.match_id=0xff;
	Match_Tag.match_timeout=MATCH_TIMEOUT_DEFAULT;
	Match_Tag.match_time=0;
	Match_Tag.isShow_timeoutInfo=1;
	Match_Tag.match_cmd=SERACH;
	g_fsm_state = STATE_MATCH;
	Match_Tag.start_tick = platform_timer_us_tick();
}


static void fsmConfigMatch(void)
{
	U8 tmp[6]={0};
	U16 timeout=0;
	tmp[0]=g_recv_buff[FRAME_STA_LEN];
	tmp[1]=PS_RESPONSE;
	fsmSendFrame(PID_ACK ,0x06,&tmp[0]);
	Match_Tag.match_id=0xff;
	Match_Tag.match_timeout=MATCH_TIMEOUT_DEFAULT;
	Match_Tag.match_time=0;
	Match_Tag.match_cmd=CONFIG_MATCH;
	timeout=g_recv_buff[FRAME_STA_LEN+5];
	Match_Tag.isShow_timeoutInfo=g_recv_buff[FRAME_STA_LEN+6];
	if(timeout<=60)
		Match_Tag.match_timeout=timeout*1000*1000;
	g_fsm_state = STATE_MATCH;
	Match_Tag.start_tick = platform_timer_us_tick();
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////SendData func///////////////////////////////////////////////////////

typedef struct
{
	U8 *buff;
	U32 len;
	U8 tmp_buff[256];
	U32 start_tick;
	U32 timeout;
	U8 resend_times;
}_SendDataTag;


static _SendDataTag SendData_Tag={0};
U8 SendData(char *name,U8 *buf,U32 len)
{

	platform_msleep(3);
	U8 tmp[256]={0},flag=0;

	if((len>0)&&(buf)&&(name))
	{
		strcpy((char *)&tmp[4],(char *)name);
		tmp[0]=DEBUG_UPLOAD;
		tmp[1]=(len>>16)&0xff;
		tmp[2]=(len>>8)&0xff;
		tmp[3]=(len)&0xff;
		fsmSendFrame(PID_COMMAND ,0xff,&tmp[0]);

		platform_msleep(3);
		SendData_Tag.len=len;
		SendData_Tag.buff=buf;
		fsmSendDataTask(FSM_SEND_DATA_IMAGE);
	}
	else
	{
		flag=1;
	}
	platform_msleep(3);
	return flag;
}



static U8 fsmTaskForSendData(S32 ch)
{
	if (ch >= 0)
	{
		if (fsmGetFrame(ch,1))
		{
			if(PID_DATA_ACK  ==g_recv_buff[FRAME_PID])
			{
				return 0;
			}
			else if(PID_COMMAND  ==g_recv_buff[FRAME_PID])
			{
				return 1;
			}
		}
	}
	return 2;
}


// flag = 0 send image
// flag = 1 send eflash data
static void fsmSendDataTask(U8 flag)
{
	S32 ch;
	U32 len=(Frame_Data_Size-3);
	U32 pos=SendData_Tag.len/len;
	U32 off=SendData_Tag.len%len;
	U16 i=0,frameNum=0;
	U8 ret=1,res;
	U8 end=0;

	SendData_Tag.start_tick = platform_timer_us_tick();
	SendData_Tag.timeout=4*1000*1000;
	SendData_Tag.resend_times=10;
	while(1)
	{
		SendData_Tag.start_tick = platform_timer_us_tick();
		SendData_Tag.tmp_buff[0]=i>>8;
		SendData_Tag.tmp_buff[1]=i&0xff;
		if(i<pos)
		{
			if( (i==(pos-1) ) && (off==0))
			{
				if(flag == FSM_SEND_DATA_IMAGE)
					memcpy(&SendData_Tag.tmp_buff[2],SendData_Tag.buff+i*len,len);
				else if(flag == FSM_SEND_DATA_EFLASH1_DATA)
					memcpy(&SendData_Tag.tmp_buff[2],(U8 *)(FSM_EFLASH1_READ_START_ADDR+i*len),len);


				fsmSendFrame(PID_LAST_DATA,len+2,&SendData_Tag.tmp_buff[0]);
				end=1;
			}
			else
			{
				if(flag == FSM_SEND_DATA_IMAGE)
					memcpy(&SendData_Tag.tmp_buff[2],SendData_Tag.buff+i*len,len);
				else if(flag == FSM_SEND_DATA_EFLASH1_DATA)
					memcpy(&SendData_Tag.tmp_buff[2],(U8 *)(FSM_EFLASH1_READ_START_ADDR+i*len),len);

				fsmSendFrame(PID_DATA,len+2,&SendData_Tag.tmp_buff[0]);
			}

		}
		if(i==pos)
		{
			if(off>0)
			{
				if(flag == FSM_SEND_DATA_IMAGE)
					memcpy(&SendData_Tag.tmp_buff[2],SendData_Tag.buff+i*len,off);
				else if(flag == FSM_SEND_DATA_EFLASH1_DATA)
					memcpy(&SendData_Tag.tmp_buff[2],(U8 *)(FSM_EFLASH1_READ_START_ADDR+i*len),off);

				fsmSendFrame(PID_LAST_DATA,off+2,&SendData_Tag.tmp_buff[0]);
				end=1;
			}
			else
			{
				break;
			}
		}
		while( calculateTimeElapse(SendData_Tag.start_tick) < SendData_Tag.timeout)
		{
			platform_uart_read_byte(&ch);
			ret=fsmTaskForSendData(ch);

			if(ret==0)
			{
				res=g_recv_buff[FRAME_STA_LEN+2];        //��ȡ�����s
				if(res==PS_OK)
				{
					i++;
				}
				else if(res==PS_END_UPLOAD)
				{
					end=1;
				}
				else
				{
					frameNum=g_recv_buff[FRAME_STA_LEN ];
					frameNum=frameNum<<8;
					frameNum=frameNum|g_recv_buff[FRAME_STA_LEN +1];
					if(frameNum>pos)
					{
						i=0;
					}
					else
					{
						i=frameNum;
					}
					end=0;
				}
				break;
			}
			else if(ret==1)
			{
				end=1;
				break;
			}
		}
		if(calculateTimeElapse(SendData_Tag.start_tick) >= SendData_Tag.timeout)
		{
			SendData_Tag.resend_times--;
			if(SendData_Tag.resend_times==0)
				break;
			else
				continue;
		}

		if( end ||(SendData_Tag.resend_times==0))
			break;
	}
}



///////////////////////////////////////////////////////////////normal func/////////////////////////////////////////////

static void fsmVfyPwd(void)
{
	U32 passwd;
	U8 tmp_buf[2]={0};
	ReadParaTab(&Sys_ParaTag,sizeof(_SysParaTag) );
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	passwd=g_recv_buff[FRAME_STA_LEN+1];
	passwd=passwd<<8|g_recv_buff[FRAME_STA_LEN+2];
	passwd=passwd<<8|g_recv_buff[FRAME_STA_LEN+3];
	passwd=passwd<<8|g_recv_buff[FRAME_STA_LEN+4];

	//MALOGD("passwd 0x%x, sys_pwd 0x%x", passwd, Sys_ParaTag.pwd);
	if(passwd!=Sys_ParaTag.pwd)
	{
		tmp_buf[1]=PS_INVALID_PASSWORD;
		Gl_Password=0;
	}
	else
	{
		Gl_Password=1;
	}
	g_fsm_state = STATE_IDLE;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}




static void fsmSetPwd(void)
{
	U32 passwd;
	U8 tmp_buf[2]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	passwd=g_recv_buff[FRAME_STA_LEN+1];
	passwd=passwd<<8|g_recv_buff[FRAME_STA_LEN+2];
	passwd=passwd<<8|g_recv_buff[FRAME_STA_LEN+3];
	passwd=passwd<<8|g_recv_buff[FRAME_STA_LEN+4];
	Sys_ParaTag.en_passwd=1;
	Sys_ParaTag.pwd=passwd;
	Gl_Password=0;
	WriteParaTab(&Sys_ParaTag,sizeof(Sys_ParaTag));
	g_fsm_state = STATE_IDLE;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}



static void fsmSetAddr(void)
{
	U32 addr,addr_tmp;
	U8 tmp_buf[2]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];   //ָ��
	tmp_buf[1]=PS_OK;
	addr=g_recv_buff[FRAME_STA_LEN+1];
	addr=addr<<8|g_recv_buff[FRAME_STA_LEN+2];
	addr=addr<<8|g_recv_buff[FRAME_STA_LEN+3];
	addr=addr<<8|g_recv_buff[FRAME_STA_LEN+4];
	addr_tmp=Sys_ParaTag.device_add;
	Sys_ParaTag.device_add=addr;
	WriteParaTab(&Sys_ParaTag,sizeof(Sys_ParaTag));
	g_fsm_state = STATE_IDLE;
	fsmSendFrameTmp(PID_ACK ,0x02,&tmp_buf[0],addr_tmp);
}



static void fsmSetSysPara(void)
{
	U8 type,para,flag=0;
	U8 tmp_buf[2]={0};
	U32 timeout=0xffffff;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];     //ָ��
	tmp_buf[1]=PS_OK;
	type=g_recv_buff[FRAME_STA_LEN+1];
	para=g_recv_buff[FRAME_STA_LEN+2];
	switch(type)
	{
	case SYS_PARA_BAUDRATE:
		if(para>=1)
		{
			flag|=0x01;
			Baud_Rate=para;
			Sys_ParaTag.baudrate=Baud_Rate;
			WriteParaTab(&Sys_ParaTag,sizeof(Sys_ParaTag));

#if PROTOCOL ==  PROTOCOL_MICROARRAY_COMPATIBLE_SYNOCHIP
			Synoc_Sys_ParaTag.cfg_baudrate=Baud_Rate;
			writeSynocParaTab(&Synoc_Sys_ParaTag,sizeof(_SynocSysParaTag));
#endif
		}
		else
		{
			tmp_buf[1]=PS_PARAM_ERROR;
		}
		break;
	case SYS_PARA_SECLVL:
		break;
	case SYS_PARA_PACKLEN:
		if(para<=3)
		{
			Sys_ParaTag.pkt_size=para;
			WriteParaTab(&Sys_ParaTag,sizeof(Sys_ParaTag));
			switch(para)
			{
			case 0: Frame_Data_Size=32; break;
			case 1: Frame_Data_Size=64; break;
			case 2: Frame_Data_Size=128; break;
			case 3: Frame_Data_Size=256; break;
			default:Frame_Data_Size=256;break;
			}
		}
		else
		{
			tmp_buf[1]=PS_PARAM_ERROR;
		}
		break;
	default:
		tmp_buf[1]=PS_INVALID_REG;
		break;
	}
	g_fsm_state = STATE_IDLE;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
	if(flag&0x01)
	{
		platform_msleep(20);
		while((!platform_uart_send_empty())&&(timeout--));
		platform_uart_set_baudrate(Baud_Rate*9600);
		platform_msleep(2);
	}
}


static void fsmGetSysPara(void)
{
	U8 tmp_buf[19]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	tmp_buf[2]=Sys_ParaTag.version[0];
	tmp_buf[3]=Sys_ParaTag.version[1];
	tmp_buf[4]=Sys_ParaTag.version[2];
	tmp_buf[5]=Sys_ParaTag.version[3];
	tmp_buf[6]=Sys_ParaTag.version[4];
	tmp_buf[7]=Sys_ParaTag.version[5];
	tmp_buf[8]=Sys_ParaTag.version[6];
	tmp_buf[9]=Sys_ParaTag.version[7];
	tmp_buf[10]=(Sys_ParaTag.index>>8)&0xff;
	tmp_buf[11]=Sys_ParaTag.index&0xff;
	tmp_buf[12]=Sys_ParaTag.device_add>>24;
	tmp_buf[13]=Sys_ParaTag.device_add>>16;
	tmp_buf[14]=Sys_ParaTag.device_add>>8;
	tmp_buf[15]=Sys_ParaTag.device_add;
	tmp_buf[16]=Sys_ParaTag.pkt_size;
	tmp_buf[17]=Baud_Rate;
	tmp_buf[18]=Protocol;
	g_fsm_state = STATE_IDLE;
	fsmSendFrame(PID_ACK ,0x13,&tmp_buf[0]);
}


static void fsmGetIdList(void)
{
	U8 tmp_buf[34]={0};
	U8 page=g_recv_buff[FRAME_STA_LEN+1];
	U16 i=0;
	memset(Index_Tab,0,sizeof(Index_Tab));
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	if( page<4)
	{
		for(i=0;i<MAX_ID;i++)
		{
			if(mafp_get_enrollid_status(i)==1)
			{
				Index_Tab[i/PAGE_SIZE][(i%PAGE_SIZE)/PAGE_TAP]|=1<<(i%PAGE_TAP);
			}
		}
	}
	else
	{
		page=0;
		tmp_buf[1]=PS_PARAM_ERROR;
	}
	memcpy(&tmp_buf[2],Index_Tab[page]+0,sizeof(Index_Tab)/4);
	g_fsm_state = STATE_IDLE;
	
	fsmSendFrame(PID_ACK ,0x22,&tmp_buf[0]);
}


static void fsmGetIdNum(void)
{
	U16 num;
	U8 tmp_buf[4]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	num=mafp_get_used_enrollids();
	tmp_buf[2]=num>>8;
	tmp_buf[3]=num;
	g_fsm_state = STATE_IDLE;
	fsmSendFrame(PID_ACK ,0x4,&tmp_buf[0]);
}


static void fsmDeleteID(void)
{
	U16 id;
	U8 tmp_buf[2]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_DEL_TEMP_ERR;
	id=g_recv_buff[FRAME_STA_LEN+1]<<8|g_recv_buff[FRAME_STA_LEN+2];
	if (id < MAX_ID)
	{
		if( mafp_get_enrollid_status(id)==0)
			tmp_buf[1]= PS_ID_INEXIST;
		else if (mafp_remove_enrollid(id)== 0)
			tmp_buf[1]= PS_OK ;


	}
	g_fsm_state = STATE_IDLE;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmEmptyId(void)
{
	U8 tmp_buf[2]={0};
	g_fsm_state = STATE_IDLE;

	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	if(mafp_clear_all_enrollids() == ERROR_CLEAR_FIDS)
		tmp_buf[1]=PS_CLEAR_TEMP_ERR ;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}



static void fsmInitSystem(void)
{
	/*U32 addr;
	
	g_fsm_state = STATE_IDLE;
	U8 tmp_buf[2]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	ReadParaTab(&Sys_ParaTag,sizeof(Sys_ParaTag));
	addr=Sys_ParaTag.device_add;
	initDeviceErase();
	//hardwareInit();
	if(mafp_factory_init())
		tmp_buf[1]=PS_INITSYSTEM_ERR;
	initDeviceInfo();
	fsmSendFrameTmp(PID_ACK ,0x02,&tmp_buf[0],addr);
	platform_msleep(20);
	while(!platform_uart_send_empty());
	platform_uart_set_baudrate(Baud_Rate*9600);
	platform_msleep(2);*/

	static factory_test_t item_t;

	item_t.item = ALL_TEST;
	item_t.factoryTestCallback = factoryTestfsmCallback;
	lock_async_call_wrapper(Factory_test_process , &item_t);
}




static void fsmInitSensor(void)
{
	U8 tmp_buf[2]={0};
	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	if(mafp_reinit_sensor_parameters())
		tmp_buf[1]=PS_INITSEBSOR_ERR;
	else
		tmp_buf[1]=PS_OK;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmHandshake(void)
{
	g_fsm_state = STATE_IDLE;
	U8 tmp_buf[2]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];   //ָ��
	tmp_buf[1]=PS_OK;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


void deviceReady(void)
{
	S32 res,bad_blocks;
	U8 tmp_buf[4]={0};
	tmp_buf[0]=DEVICE_READY;

	res=mafp_init(&bad_blocks);

	if(res == ERROR_LOAD_SENSOR_PARAM)
	{
		Device_Ready_Flag|=DEVICE_READY_SENSOR_CRC_FAILE;
	}
	else if( (res!=0))
	{
		Device_Ready_Flag|=DEVICE_READY_SENSOR_BREAKDOWN;
	}
	else
	{
		Device_Ready_Flag&=~(DEVICE_READY_SENSOR_BREAKDOWN|DEVICE_READY_SENSOR_CRC_FAILE);
	}
	tmp_buf[1]=Device_Ready_Flag;
	tmp_buf[2]=(bad_blocks>>8)&0xff;
	tmp_buf[3]=(bad_blocks&0xff);

	if(Protocol == PROTOCOL_MICROARRAY)
	{
		fsmSendFrame(PID_ACK ,0x04,&tmp_buf[0]);
	}
	else  if(Protocol == PROTOCOL_MICROARRAY_COMPATIBLE_SYNOCHIP)
	{
		U8 synoc_start_flag=0x55;
		platform_uart_send_buff(&synoc_start_flag,1);
	}

}


void fsmDebugPrint(const char *fmt, ...)
{
	if(Sys_ParaTag.en_debug_print)
	{
		platform_msleep(3);
		U8 tmp_buf[256];
		va_list args;
		va_start(args, fmt);
#ifdef PLATFORM_AC693X
		sprintf((char *)&tmp_buf[1],fmt, args);
#else
		vsprintf((char *)&tmp_buf[1],fmt, args);
#endif	
		va_end(args);
		tmp_buf[0]= DEBUG_PRINT_MODE;
		fsmSendFrame(PID_DEBUG_PRINT ,sizeof(tmp_buf)-2,&tmp_buf[0]);
		platform_msleep(30);
	}
	return ;
}



static void fsmEnDebugPrint(void)
{
	g_fsm_state = STATE_IDLE;
	U8 tmp_buf[2]={0},flag=0;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	flag=g_recv_buff[FRAME_STA_LEN+1];
	if(flag)
	{
		Sys_ParaTag.en_debug_print=1;
	}
	else
	{
		Sys_ParaTag.en_debug_print=0;
	}
	WriteParaTab(&Sys_ParaTag,sizeof(Sys_ParaTag));
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}



static void fsmDebugGetPara(void)
{
	U16 sensor_id = 0, qflash_id = 0;
	S32 ret=1;
	g_fsm_state = STATE_IDLE;
	U8 tmp_buf[32]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	sensor_id=mafp_get_chipid();
	if(ret > 0)
	{
		tmp_buf[2]=0;
		tmp_buf[3]=sensor_id&0xff;
	}
	else
	{
		tmp_buf[2]=0;
		tmp_buf[3]=0;
	}
	//��ȡ���flash ���� for cui
	qflash_id= 0xffff;
	tmp_buf[4]=qflash_id>>8;
	tmp_buf[5]=qflash_id&0xff;
	fsmSendFrame(PID_ACK ,0x20,&tmp_buf[0]);
}




static void fsmDebugUpdate(void)
{
	U8 tmp_buf[2]={0};

	g_fsm_state = STATE_IDLE;

	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];   //ָ��
	//tmp_buf[1]=PS_UPDATE_FAIL;
	tmp_buf[1]=PS_OK;

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
	platform_msleep(3);
	while(!platform_uart_send_empty());
	platform_sys_reset(1);
}


static void fsmDebugEnrollAfterDownLoad(void)
{
	S32 ret;
	U16 enroll_id;
	U8 tmp[2]={0},post_enroll_flag=0;
	tmp[0]=g_recv_buff[FRAME_STA_LEN];
	g_fsm_state = STATE_IDLE;
	enroll_id = (g_recv_buff[FRAME_STA_LEN+1]<<8)|g_recv_buff[FRAME_STA_LEN+2];
	post_enroll_flag=g_recv_buff[FRAME_STA_LEN+3];
	if ( (enroll_id >= MAX_ID))
	{
		tmp[1]=PS_ADDRESS_OVER;
	}
	else if( (mafp_get_enrollid_status(enroll_id))== 1)
	{
		tmp[1]=PS_ID_ALREADY_EXIST;
	}
	else
	{
		if(post_enroll_flag)
		{
			ret=mafp_post_enroll();
			if(!ret)
				tmp[1]=PS_OK;
			else
				tmp[1]=PS_ENROLL_ERR;
		}
		else if(DownLoad_Tag.is_download_image_value)
		{
			DownLoad_Tag.is_download_image_value=0;
			sensor_save_download_buf();
			/*
			 * ERROR_ENROLL_LAST_INCOMPLETE
			 * ERROR_ENROLL_EXCEED_MAX_TIMES
			 * ERROR_BAD_IMAGE
			 * ERROR_ENROLL_ALGO_FAIL
			 * */
			ret=sensor_enroll_image_testing(enroll_id);

			if(ret>0)
				tmp[1]=PS_NO_ERROR;
			else
				tmp[1]=PS_GET_IMG_ERR;
		}
		else
		{
			tmp[1]=PS_GET_IMG_ERR;
		}
	}
	fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
}



static void fsmDebugMatchAfterDownLoad(void)
{
	S32 ret;
	U8 tmp[4]={0};

	tmp[0]=g_recv_buff[FRAME_STA_LEN];

	g_fsm_state = STATE_IDLE;

	if(DownLoad_Tag.is_download_image_value)
	{
		DownLoad_Tag.is_download_image_value=0;
		sensor_save_download_buf();
		/*
		 * ERROR_BAD_IMAGE
		 * ERROR_AUTH_NO_MATCH
		 * */
		ret=sensor_authenticate_image_testing();

		if( ret == ERROR_BAD_IMAGE )
			tmp[1]=PS_GET_IMG_ERR;
		else if(ret == ERROR_AUTH_NO_MATCH)
			tmp[1]=PS_NOT_SEARCHED ;
		else
		{
			tmp[2]=(ret>>8)&0xff;
			tmp[3]=ret&0xff;
			tmp[1]=PS_OK;
		}
	}
	else
	{
		tmp[1]=PS_GET_IMG_ERR;
	}

	fsmSendFrame(PID_ACK ,0x04,&tmp[0]);
}



static void fsmDebugResetTemplateStorage(void)
{
	g_fsm_state = STATE_IDLE;
	U8 tmp_buf[2]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;

	if(mafp_reset_templates_storage())
		tmp_buf[1]=PS_CLEAR_BADBLOCKS_ERR;

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmDebugReadAllFlash(void)
{
	U8 tmp[256]={0};
	g_fsm_state = STATE_IDLE;
	tmp[0]=g_recv_buff[FRAME_STA_LEN];
	tmp[1]=PS_OK;
	fsmSendFrame(PID_ACK ,0x02,&tmp[0]);
	platform_msleep(5);
	strcpy((char *)&tmp[4],"EFLASH1_DATA.hex");
	tmp[0]=DEBUG_UPLOAD;
	tmp[1]=(FSM_EFLASH1_READ_SIZE>>16)&0xff;
	tmp[2]=(FSM_EFLASH1_READ_SIZE>>8)&0xff;
	tmp[3]=(FSM_EFLASH1_READ_SIZE)&0xff;
	fsmSendFrame(PID_COMMAND ,0xff,&tmp[0]);
	platform_msleep(5);
	SendData_Tag.len=FSM_EFLASH1_READ_SIZE;
	SendData_Tag.buff=NULL;
	fsmSendDataTask(FSM_SEND_DATA_EFLASH1_DATA);
}


static void fsmSwitchProtocol(void)
{
	g_fsm_state = STATE_IDLE;
	U8 tmp_buf[2]={0},protocol,post_flag;
	protocol=g_recv_buff[FRAME_STA_LEN+1];
	post_flag=g_recv_buff[FRAME_STA_LEN+2];
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_SWITCH_PROTOCOL_FAIL;
	switch(protocol)
	{
	case PROTOCOL_MICROARRAY_COMPATIBLE_SYNOCHIP:
	case PROTOCOL_MICROARRAY_COMPATIBLE_YALE:
	case PROTOCOL_MICROARRAY:
		Protocol=protocol;
		if(post_flag)
		{
			Sys_ParaTag.protocol=Protocol;
			WriteParaTab(&Sys_ParaTag,sizeof(Sys_ParaTag));
		}
		tmp_buf[1]=PS_OK;
		break;
	default:
		break;

	}
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmDeleteMultiId(void)
{
	U16 start,nums,i;
	U8 tmp_buf[2]={0};
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_DEL_TEMP_ERR;
	start=g_recv_buff[FRAME_STA_LEN+1]<<8|g_recv_buff[FRAME_STA_LEN+2];
	nums=g_recv_buff[FRAME_STA_LEN+3]<<8|g_recv_buff[FRAME_STA_LEN+4];
	if((start+nums) <= MAX_ID)
	{
		for(i=0;i<nums;i++)
		{
			if (mafp_remove_enrollid(start+i) == 0)
				tmp_buf[1]= PS_OK ;
			else
			{
				tmp_buf[1]=PS_DEL_TEMP_ERR;
				break;
			}
		}
	}
	g_fsm_state = STATE_IDLE;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}

static void fsmBurnCodeTime(void)
{
	g_fsm_state = STATE_IDLE;
	Burn_Code_Time_Buff[0]=g_recv_buff[FRAME_STA_LEN];
	Burn_Code_Time_Buff[1]=PS_OK;
	readBurnCodeTime(Burn_Code_Time_Buff+2,sizeof(Burn_Code_Time_Buff)-2);
	fsmSendFrame(PID_ACK ,sizeof(Burn_Code_Time_Buff),&Burn_Code_Time_Buff[0]);
}



static void fsmIsFingerLeave(void)
{
	U8 tmp_buf[2]={0};
	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_FINGER_EXIST;

	if (mafp_finger_leave() == 1)
		tmp_buf[1]=PS_OK;

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}



static void fsmCheckDetectMode(void)
{
	U8 tmp_buf[2]={0};
	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_DETECT_MODE_FAIL;
	if (mafp_detect_mode()==0)
		tmp_buf[1]=PS_OK;

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}

static void fsmStoreData(void)
{
	U8 tmp_buf[2]={0};
	fsmDebugPrint("StoreData\n");
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	g_fsm_state = STATE_IDLE;
	memcpy(&DownLoad_Tag.name[0],&g_recv_buff[13],251);
	DownLoad_Tag.name[250]='\0';
	if (sensor_save_download_buf() < 0) {
		tmp_buf[1] = PS_PARAM_ERROR;
	}
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}

static void fsmReceiveData(void)
{
	U8 tmp_buf[2]={0};
	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	//sensor_upload_subtpls();
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmReadBoardCfg(void)
{
	uint8_t tmp_buf[0x0A] = {0};

	tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1] = 0x00;
	tmp_buf[2] = bsp_ctx.configBox.policy;
	tmp_buf[3] = bsp_ctx.configBox.ver;
	tmp_buf[4] = bsp_ctx.configBox.mode;
	tmp_buf[5] = bsp_ctx.configBox.adv;
	tmp_buf[6] = bsp_ctx.configBox.interval;
	tmp_buf[7] = bsp_ctx.configBox.duty;
	tmp_buf[8] = bsp_ctx.configBox.hint;
	tmp_buf[9] = bsp_ctx.configBox.adc;
	fsmSendFrame(PID_ACK, 0x0A, &tmp_buf[0]);
	platform_msleep(5);
	memset(tmp_buf, 0x00, 0x0A);
	tmp_buf[0] =  g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1] = 0x01;
	tmp_buf[2] = bsp_ctx.configBox.block;
	tmp_buf[3] = bsp_ctx.configBox.delay;
	tmp_buf[4] = (bsp_ctx.configBox.wait >> 8) & 0xff;
	tmp_buf[5] = bsp_ctx.configBox.wait & 0xff;
	tmp_buf[6] = bsp_ctx.configBox.roll;
	tmp_buf[7] = bsp_ctx.configBox.frun;
	tmp_buf[8] = bsp_ctx.configBox.brun;
	tmp_buf[9] = bsp_ctx.configBox.sflash;
	fsmSendFrame(PID_ACK, 0x0A, &tmp_buf[0]);
	platform_msleep(5);
	memset(tmp_buf, 0x00, 0x0A);
	tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1] = 0x02;
	tmp_buf[2] = bsp_ctx.configBox.qflash;
	tmp_buf[3] = bsp_ctx.configBox.light;
	tmp_buf[4] = bsp_ctx.configBox.breath;
	tmp_buf[5] = bsp_ctx.configBox.bfreq;
	fsmSendFrame(PID_ACK, 0x0A, &tmp_buf[0]);
}

static void fsmWriteBoardCfg(void)
{
	uint8_t group;
	U8 tmp_buf[2]={0};
	
	group = g_recv_buff[FRAME_STA_LEN + 1];
	switch(group){
		case 0x00:
			bsp_ctx.configBox.policy = g_recv_buff[FRAME_STA_LEN + 2];
			bsp_ctx.configBox.ver = g_recv_buff[FRAME_STA_LEN + 3];
			bsp_ctx.configBox.mode = g_recv_buff[FRAME_STA_LEN + 4];
			bsp_ctx.configBox.adv = g_recv_buff[FRAME_STA_LEN + 5];
			bsp_ctx.configBox.interval = g_recv_buff[FRAME_STA_LEN + 6];
			bsp_ctx.configBox.duty = g_recv_buff[FRAME_STA_LEN + 7];
			bsp_ctx.configBox.hint = g_recv_buff[FRAME_STA_LEN + 8];
			bsp_ctx.configBox.adc = g_recv_buff[FRAME_STA_LEN + 9];
			break;
		case 0x01:
			bsp_ctx.configBox.block = g_recv_buff[FRAME_STA_LEN + 2];
			bsp_ctx.configBox.delay = g_recv_buff[FRAME_STA_LEN + 3];
			bsp_ctx.configBox.wait = ((g_recv_buff[FRAME_STA_LEN + 4] << 8) & 0xff) | g_recv_buff[FRAME_STA_LEN + 5];
			bsp_ctx.configBox.roll = g_recv_buff[FRAME_STA_LEN + 6];
			bsp_ctx.configBox.frun = g_recv_buff[FRAME_STA_LEN + 7];
			bsp_ctx.configBox.brun = g_recv_buff[FRAME_STA_LEN + 8];
			bsp_ctx.configBox.sflash = g_recv_buff[FRAME_STA_LEN + 9];
			break;
		case 0x02:
			bsp_ctx.configBox.qflash = g_recv_buff[FRAME_STA_LEN + 2];
			bsp_ctx.configBox.light = g_recv_buff[FRAME_STA_LEN + 3];
			bsp_ctx.configBox.breath = g_recv_buff[FRAME_STA_LEN + 4];
			bsp_ctx.configBox.bfreq = g_recv_buff[FRAME_STA_LEN + 5];
			break;
		default:
			break;
	}
	/*printf("config box: %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x\n", 
																   bsp_ctx.configBox.policy, bsp_ctx.configBox.ver, bsp_ctx.configBox.mode,
																   bsp_ctx.configBox.adv, bsp_ctx.configBox.interval, bsp_ctx.configBox.duty,
																   bsp_ctx.configBox.hint, bsp_ctx.configBox.adc, bsp_ctx.configBox.block,
																   bsp_ctx.configBox.delay, bsp_ctx.configBox.wait, bsp_ctx.configBox.roll,
																   bsp_ctx.configBox.frun, bsp_ctx.configBox.brun, bsp_ctx.configBox.sflash,
																   bsp_ctx.configBox.qflash, bsp_ctx.configBox.light, bsp_ctx.configBox.breath,
																   bsp_ctx.configBox.bfreq);*/
	update_bsp_property(&bsp_ctx.configBox);
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[0]=PS_OK;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}

static void fsmFactoryTestVfy(void)
{
	U32 passwd;
	U8 tmp_buf[2]={0};
	
	ReadParaTab(&Sys_ParaTag,sizeof(_SysParaTag) );
	tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
	passwd = g_recv_buff[FRAME_STA_LEN+1];
	passwd = passwd << 8 | g_recv_buff[FRAME_STA_LEN+2];
	passwd = passwd << 8 | g_recv_buff[FRAME_STA_LEN+3];
	passwd = passwd << 8 | g_recv_buff[FRAME_STA_LEN+4];

	if(passwd != Sys_ParaTag.pwd) {
		tmp_buf[1] = 0x01;	
	} else {
		tmp_buf[1] = 0x00;
	}

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}

void factoryTestfsmCallback(MmiTestCmdRes res, uint8_t result)
{
	U8 tmp_buf[2]={0};

	switch(res) {
		case CMD_TEST_ALL_RES:
			if(result == CMD_SUCCESS) {
				fsmDebugPrint("TestMode pass");
				tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
				tmp_buf[1] = PS_OK;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			} else {
				fsmDebugPrint("TestMode failed");
			}
			break;
		case CMD_INIT_SENSOR_RES:
			if(result == CMD_START) {
				fsmDebugPrint("Data_Calibration test now ...");
			} else if(result == CMD_SUCCESS) {
				fsmDebugPrint("Data_Calibration pass");
			} else {
				fsmDebugPrint("Data_Calibration failed over 15s");
				tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
				tmp_buf[1] = ERR_MMI_RESTORE;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			}	
			break;
		case CMD_TEST_ADC_RES:
			if(result == CMD_START) {
				fsmDebugPrint("POWER ADC now ...");
			} else if(result == CMD_SUCCESS) {
				fsmDebugPrint("ADC_Power_Test pass");
			} else {
				fsmDebugPrint("ADC_Power_Test failed");
				tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
				tmp_buf[1] = ERR_ADC;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			}	
			break;
		case CMD_TEST_LED_RES:
			if(result == CMD_START) {
				fsmDebugPrint("LED_Test ...");
			} else if(result == CMD_SUCCESS) {
				fsmDebugPrint("Fsm_LED_status pass");
			} else {
				fsmDebugPrint("Fsm_LED_status failed");
			}	
			break;
		case CMD_TEST_MOTOR_RES:
			if(result == CMD_SUCCESS) {
				fsmDebugPrint("Fsm_Motor_status pass");
			} else if(result == CMD_START) {
				fsmDebugPrint("Motor_Test ...");
			} else {
				fsmDebugPrint("Fsm_Motor_status failed");
			}		
			break;
		case CMD_TEST_FP_ID_RES:
			if(result == CMD_START) {
				fsmDebugPrint("get_chip_id_Test ...");
			} else if(result == CMD_SUCCESS) {
				fsmDebugPrint("get_chip_id_Test pass");
			} else if(result == CMD_FAIL) {
				fsmDebugPrint("get_chip_id_Test failed");
			}
			break;
		case CMD_TEST_FP_ENROLL_RES:
			if(result == CMD_START) {
				fsmDebugPrint("Enroll_Test ...");
			} else if(result == CMD_SUCCESS) {
				fsmDebugPrint("Fsm_Enroll_status pass");
			} else if(result == CMD_FAIL) {
				fsmDebugPrint("Fsm_Enroll_status failed");
				tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
				tmp_buf[1] = ERR_FP_ENROLL;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			}else if(result == ERR_TIMEOUT) {
				fsmDebugPrint("Fsm_Enroll_status failed  over 15s");
				tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
				tmp_buf[1] = ERR_TIMEOUT;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			} 
			break;
		case CMD_TEST_FP_MATCH_RES:
			if(result == CMD_START) {
				fsmDebugPrint("Match_Test ...");
			} else if(result == CMD_SUCCESS) { 
				fsmDebugPrint("Fsm_Match_status  pass");
			} else if(result == CMD_FAIL) {
				fsmDebugPrint("Fsm_Match_status failed");
				tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
				tmp_buf[1] = ERR_FP_MATCH;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			} else if(result == ERR_TIMEOUT) {
				fsmDebugPrint("Fsm_Match_status failed  over 15s");
				tmp_buf[0] = g_recv_buff[FRAME_STA_LEN];
				tmp_buf[1] = ERR_TIMEOUT;
				fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
			}
			break;
		case CMD_TEST_BT_RES:
			break;
		case CMD_TEST_BT_RESULT_RES:
			break;
		default :
			break;
	}
}


static void fsmFactoryTest(void)
{
	static factory_test_t item_t;

	item_t.item = ALL_TEST;
	item_t.factoryTestCallback = factoryTestfsmCallback;
	lock_async_call_wrapper(Factory_test_process , &item_t);
}

static void fsmTestButton1(void)
{
	U8 tmp_buf[2]={0};

	g_fsm_state = STATE_IDLE;
	tmp_buf[0]= g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;

	//storage_test();

	fsmSendFrame(PID_COMMAND,0x02,&tmp_buf[0]);
}


static void fsmTestButton2(void)
{
	U8 tmp_buf[2]={0};
//	subtpl_t subtpl;

	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;

//	static  uint8_t idx = 0;
	SET_KEY_0();
	//policy_save_fidtmp_subtpl(idx++, &subtpl);

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmTestButton3(void)
{
	U8 tmp_buf[2]={0};

	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;

	static uint16_t fid = 0;
	int32_t amount;
	LOGE("---> FID %d", fid);
	amount = 0;//policy_setup_fidtmp_valid_fid(fid);
	LOGE("---> amount %d", amount);
	if (amount > 0) {
		LOGE("---> fid %d, amount %d", fid, amount);
		sensor_set_fid_used(fid);
	}
	fid++;

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmTestButton4(void)
{
	U8 tmp_buf[2]={0};

	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;

	//policy_clear_fidtmp();

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmResetSensorConfig(void)
{
	U8 tmp_buf[2]={0};

	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;

	//mafp_reset_sensor_config();

	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmDebugUpdatePreMove1(void)
{
	U8 tmp_buf[2]={0};
	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	Debug_Update_flag|=DEBUG_UPDATE_FLAG_FRE1;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}


static void fsmDebugUpdatePreMove2(void)
{
	U8 tmp_buf[2]={0};
	g_fsm_state = STATE_IDLE;
	tmp_buf[0]=g_recv_buff[FRAME_STA_LEN];
	tmp_buf[1]=PS_OK;
	Debug_Update_flag|=DEBUG_UPDATE_FLAG_FRE2;
	fsmSendFrame(PID_ACK ,0x02,&tmp_buf[0]);
}



