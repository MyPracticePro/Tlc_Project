
#include "dragonpal.h"
#include "malog.h"
#include "xn_aes.h"
#include "globalvar.h"
#include "hardware_bsp.h"
#include "mg_api.h"
#include "projectConfig.h"


static u8 dragon_Recv_Buff[DG_FRAME_LENGTH];
static u8 dragon_Send_Buff[DG_FRAME_LENGTH * DG_MAX_FRAMES];

const uint8_t dragon_aes_skey[AES_KEY_LEN] = 
{0x57, 0x61, 0x6C, 0x6B, 0x69, 0x7A, 0x35, 0x32, 
 0x38, 0x33, 0x32, 0x69, 0x4C, 0x6F, 0x63, 0x6B};

const int8_t dragon_pwd[6] = {0x31, 0x31, 0x30, 0x30, 0x36, 0x34};

const int8_t product_code[2] = {0x48, 0x53};
const int8_t product_id[2] = {0x5A, 0x5A};
const int8_t ver_id[2] = {23,12};

unsigned char cust_addr[6] = {0xFA, 0x23, 0x45, 0x00, 0x0F, 0x72};
static unsigned char dg_adv_frame[DG_BT_ADV_LEN] = {0x02, 0x01, 0x04, 0x0D, 0xFF};

static dragonPrivateZone dragon_ctx;



static void dragonExecFunc(DragonCmd cmd);

void storeKeyData(void)
{
	platform_filesystem_write(DG_USER_DATA_FLASH_ADDR, &dragon_ctx, sizeof(dragonPrivateZone));
	platform_filesystem_read(DG_USER_DATA_FLASH_ADDR, &dragon_ctx, sizeof(dragonPrivateZone));
}

void dragonFsmInit(void) 
{
	unsigned char tmp[6];
	int i;
	
	platform_bluetooth_set_context(cust_addr);
	for(i = 0; i < 6; i++) {
		tmp[i] = cust_addr[5 - i];  //ensure bt address is unique between ios and android
	}
	
	memcpy(dg_adv_frame + 5, product_code, 2);
	memcpy(&dg_adv_frame[7], tmp, 6);
	memcpy(&dg_adv_frame[13], product_id, 2);
	memcpy(&dg_adv_frame[15], ver_id, 2);
	platform_bluetooth_set_adv_data(dg_adv_frame, DG_BT_ADV_LEN);

	platform_bluetooth_set_ble_name(bsp_ctx.bt_adv_name, strlen((char *)(bsp_ctx.bt_adv_name)));

	platform_filesystem_read(DG_USER_DATA_FLASH_ADDR, &dragon_ctx, sizeof(dragonPrivateZone));
	if(dragon_ctx.saved != DATA_VFY_KEY) {
		MALOGD("get default key len %d", sizeof(dragonPrivateZone));
		memcpy(dragon_ctx.aes_skey, dragon_aes_skey, AES_KEY_LEN);
		memcpy(dragon_ctx.g_pwd, dragon_pwd, 6);
		dragon_ctx.saved = DATA_VFY_KEY;
		storeKeyData(); 
	} else {
		MALOGD("load key from flash");
	}

#ifdef DEBUG_LOG
	MALOGD("AES KEY:\n %x %x %x %x %x %x %x %x \n %x %x %x %x %x %x %x %x",
			   dragon_ctx.aes_skey[0], dragon_ctx.aes_skey[1], dragon_ctx.aes_skey[2], dragon_ctx.aes_skey[3],
			   dragon_ctx.aes_skey[4], dragon_ctx.aes_skey[5], dragon_ctx.aes_skey[6], dragon_ctx.aes_skey[7],
			   dragon_ctx.aes_skey[8], dragon_ctx.aes_skey[9], dragon_ctx.aes_skey[10], dragon_ctx.aes_skey[11],
			   dragon_ctx.aes_skey[12], dragon_ctx.aes_skey[13], dragon_ctx.aes_skey[14], dragon_ctx.aes_skey[15]);
	MALOGD("passwd: %x %x %x %x %x %x", dragon_ctx.g_pwd[0], dragon_ctx.g_pwd[1], dragon_ctx.g_pwd[2], 
										dragon_ctx.g_pwd[3], dragon_ctx.g_pwd[4], dragon_ctx.g_pwd[5]);
#endif
}

static uint8_t dragonfsmFrameCheck(uint8_t const* frame, uint8_t len)
{

	if(len != DG_FRAME_LENGTH) {
		return DG_FRAME_LENGTH_ERR;
	}

	return DG_OK;
}

static uint8_t dragonCheckToken(void)
{
	uint8_t tkn_len;
	int32_t  token;
	int32_t ptr_token;
	
	tkn_len = platform_bluetooth_get_token(&ptr_token);
	if(tkn_len != 0 && ptr_token != NULL) {
		token = (dragon_Recv_Buff[12] << 24) |
				(dragon_Recv_Buff[13] << 16) |
				(dragon_Recv_Buff[14] << 8) |
				dragon_Recv_Buff[15];
		//MALOGD("%x %x %x %x, token %x", dragon_Recv_Buff[12], dragon_Recv_Buff[13], dragon_Recv_Buff[14], dragon_Recv_Buff[15], token);
		if(ptr_token != token) {
			MALOGE("chk token fail");
			return DG_CHK_TOKEN_ERR;
		}
	} else {
		MALOGE("get token fail");
		return DG_CHK_TOKEN_ERR;
	}

	return DG_OK;
}

static S32 dragonFsmGetFrame(uint8_t const* frame,uint8_t len)
{
	uint8_t i;

    if(!dragonfsmFrameCheck(frame, len)) {
		memcpy(dragon_Recv_Buff, frame, DG_FRAME_LENGTH);
	    printf("frame receive:");
	    for(i = 0; i < DG_FRAME_LENGTH; i++) {
	        printf("0x%x ", dragon_Recv_Buff[i]);
	    }
		printf("\n");
		return 1;	
	} else {
		//if needed, send error package to terminal
		MALOGE("chk frame failed");
		return 0;
	}
}

void dragonFsmTask(uint8_t const* frame, uint8_t len)
{
	U16 command = 0;
	uint8_t decrypt_frame[len];

#ifdef DG_FRAME_DECRYPT
	AES128_ECB_decrypt(frame, dragon_ctx.aes_skey, decrypt_frame);
#else
	memcpy(decrypt_frame, frame, len);
#endif
	if (dragonFsmGetFrame(decrypt_frame, len))
	{
		command = (dragon_Recv_Buff[DG_FRAME_PID_HIGH] << 8) + dragon_Recv_Buff[DG_FRAME_PID_LOW];
	    //MALOGD("PID high = 0x%x, PID low = 0x%x, command = %x", dragon_Recv_Buff[DG_FRAME_PID_HIGH], dragon_Recv_Buff[DG_FRAME_PID_LOW], command);
		MALOGD("fetch command: 0x%x", command);

		dragonExecFunc((DragonCmd)command);
	} 
}

static U16 dragonkFrameSetPack(U16 _data_len,u8* _data_buf,DragonCmd _type,u8 * _send_buff)
{
	uint16_t cmdRes;
	uint8_t decrypt_frame[DG_FRAME_LENGTH] = {0};
	uint8_t i;

	if(_send_buff&&_data_buf) { 
	    memset(decrypt_frame, 0x00, DG_FRAME_LENGTH);
		cmdRes = CMD_RES(_type);
		decrypt_frame[0] = (cmdRes >> 8) & 0xff;
		decrypt_frame[1] = cmdRes & 0xff;
		memcpy(decrypt_frame + 2, _data_buf, _data_len);
		memset(_send_buff,  0x00, DG_FRAME_LENGTH);
		printf("frame send:");
	    for(i = 0; i < DG_FRAME_LENGTH; i++) {
	        printf("0x%x ", decrypt_frame[i]);
	    }
		printf("\n");
#ifdef DG_FRAME_DECRYPT 
		AES128_ECB_encrypt(decrypt_frame, dragon_ctx.aes_skey, _send_buff);
#else
		memcpy(_send_buff, decrypt_frame, DG_FRAME_LENGTH);
#endif
		return _data_len;
	} else {
	    MALOGE("end, send or data buff is null");
		return 0;
	}

}


static void dragonFsmSendFrame(DragonCmd _ack,U16 _data_len,u8 *_data_buf)
{
	U16 len;
	
	if(_data_buf)
	{
		len=dragonkFrameSetPack(_data_len,_data_buf,_ack,dragon_Send_Buff);
		//MALOGD("UART send respose frame:%d", len / DG_FRAME_LENGTH);
		if(len > 0) {
			platform_bluetooth_send_notification(dragon_Send_Buff, DG_FRAME_LENGTH);
		}
	}
}

void dragonWRFactoryCfg(void) 
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	ConfigBox_t s_conf;

	s_conf.policy = dragon_Recv_Buff[2];
	s_conf.ver = dragon_Recv_Buff[3];
	s_conf.mode = dragon_Recv_Buff[4];
	s_conf.adv = dragon_Recv_Buff[5];
	s_conf.interval = dragon_Recv_Buff[6];
	s_conf.duty = dragon_Recv_Buff[7];
	s_conf.hint = dragon_Recv_Buff[8];
	s_conf.adc = dragon_Recv_Buff[9];
	s_conf.block = dragon_Recv_Buff[10];
	s_conf.delay = dragon_Recv_Buff[11];
	s_conf.wait = dragon_Recv_Buff[12] << 8 | dragon_Recv_Buff[13];
	s_conf.roll = dragon_Recv_Buff[14];
	s_conf.reserved = dragon_Recv_Buff[15];

	result[0] = update_bsp_property(&s_conf);
	
	dragonFsmSendFrame(CMD_DG_WR_FACTORY_CFG, 14, result);	
}

void dragonRDFactoryCfg(void) 
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	result[0] = bsp_ctx.configBox.policy;
	result[1] = bsp_ctx.configBox.ver;
	result[2] = bsp_ctx.configBox.mode;
	result[3] = bsp_ctx.configBox.adv;
	result[4] = bsp_ctx.configBox.interval;
	result[5] = bsp_ctx.configBox.duty;
	result[6] = bsp_ctx.configBox.hint;
	result[7] = bsp_ctx.configBox.adc;
	result[8] = bsp_ctx.configBox.block;
	result[9] = bsp_ctx.configBox.delay;
	result[10] = (bsp_ctx.configBox.wait >> 8) & 0xff;
	result[11] = bsp_ctx.configBox.wait & 0xff;
	result[12] = bsp_ctx.configBox.roll;
	result[13] = bsp_ctx.configBox.reserved;
	
	dragonFsmSendFrame(CMD_DG_RD_FACTORY_CFG, 14, result);	
}


void dragonGetToken(void) 
{
	uint8_t tkn_len;
	uint8_t result[DG_FRAME_LENGTH] = {0};
	int32_t ptr_token;

	tkn_len = platform_bluetooth_get_token(&ptr_token);
	if(tkn_len != 0 && ptr_token != NULL) {
		result[0] = (ptr_token >> 24) & 0xff;
		result[1] =	(ptr_token >> 16) & 0xff; 
		result[2] =	(ptr_token >> 8) & 0xff; 
		result[3] =	ptr_token & 0xff;
		MALOGD("token %x ", ptr_token);
	} else {
		result[0] = DG_FAIL;
		MALOGE("get token fail");
		dragonFsmSendFrame(CMD_DG_WR_TOKEN, DG_FRAME_LENGTH - 2, result);
		return;
	}

	memcpy(result + 4, product_id, 2);
	memcpy(result + 6, ver_id, 2);

	result[8] = platform_battery_get_value() & 0xff;
	dragonFsmSendFrame(CMD_DG_WR_TOKEN, DG_FRAME_LENGTH - 2, result);
	
}

void dragonSetDate(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint32_t utc_time;
	uint8_t ret;
	tm_date date;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	date.year = dragon_Recv_Buff[2] + 2000;
	date.mon = dragon_Recv_Buff[3];
	date.mday = dragon_Recv_Buff[4];
	date.hour = dragon_Recv_Buff[5];
	date.min = dragon_Recv_Buff[6];
	date.sec = dragon_Recv_Buff[7];
	utc_time = localTime_to_unixTimestamp(date);
	MALOGD("utc %lu", utc_time);
	ret = platform_rtc_set_sys_time((uint64_t)utc_time);
	if(ret) {
		MALOGE("set date error");
		result[0] = DG_FAIL;
		dragonFsmSendFrame(CMD_DG_SET_DATE, DG_FRAME_LENGTH - 2, result);
		return ;
	}

	dragonFsmSendFrame(CMD_DG_SET_DATE, DG_FRAME_LENGTH - 2, result);
}

void dragonGetDate(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	time_t utc_time;
	tm_date date;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	utc_time = platform_rtc_get_sys_time();
	date = unixTimestamp_to_localTime(utc_time);
	result[0] = DG_OK;
	result[1] = date.year - 2000;
	result[2] = date.mon;
	result[3] = date.mday;
	result[4] = date.hour;
	result[5] = date.min;
	result[6] = date.sec;
	
	dragonFsmSendFrame(CMD_DG_GET_DATE, DG_FRAME_LENGTH - 2, result);
}


void dragonGetBattery(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint16_t voltage;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	voltage = platform_battery_get_value();

	result[0] = getBatteryPercent() & 0xff;
	
	result[1] = (voltage >> 8)& 0xff;
	result[2] = voltage & 0xff;
	
	dragonFsmSendFrame(CMD_DG_GET_BAT, DG_FRAME_LENGTH - 2, result);
}

void dragonModBtName(void)
{
	uint8_t new_name[10];
	uint8_t len;
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint8_t ret;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	len = dragon_Recv_Buff[2];
	memcpy(new_name, dragon_Recv_Buff + 3, len);
	ret = platform_bluetooth_set_ble_name(new_name, len);
	memset(bsp_ctx.bt_adv_name, 0x00, BLE_NAME_LENGTH);
	memcpy(bsp_ctx.bt_adv_name, new_name, len);
	storeUserCfgProp();
	if(ret) {
		result[0] = DG_FAIL;
		MALOGE("set ble name error");
		dragonFsmSendFrame(CMD_DG_MOD_BT_NAME, DG_FRAME_LENGTH - 2, result);
		return;
	}

	result[0] = DG_OK;
	dragonFsmSendFrame(CMD_DG_MOD_BT_NAME, DG_FRAME_LENGTH - 2, result);
}

void dragonModAESKey(void)
{
	static uint8_t new_key[16];
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint8_t ret;
	static uint8_t mod_lock = 0;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	if(dragon_Recv_Buff[1] == 0x00) {
		memcpy(new_key, dragon_Recv_Buff + 2, 8);
		mod_lock = 1;
		return ;
	} else if(dragon_Recv_Buff[1] == 0x01) {
		if(!mod_lock) {
			result[0]  = DG_FAIL;
			dragonFsmSendFrame(CMD_DG_MOD_AES_SKEY_L, DG_FRAME_LENGTH - 2, result);
			MALOGE("set skey error!");
			return;
		}
	}

	mod_lock = 0;
	memcpy(new_key + 8, dragon_Recv_Buff + 2, 8);
	memcpy(dragon_ctx.aes_skey, new_key, 16);	
	storeKeyData();
	
	result[0] = ret;
	dragonFsmSendFrame(CMD_DG_MOD_AES_SKEY_L, DG_FRAME_LENGTH - 2, result);
}


void dragonModPwd(void)
{
	static int8_t passwd[6];
	uint8_t result[DG_FRAME_LENGTH] = {0};
	static uint8_t mod_lock = 0;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	if(dragon_Recv_Buff[1] == 0x00) {   //verify old passwd
		memcpy(passwd, dragon_Recv_Buff + 2, 6);
		if(!array_cmp(dragon_ctx.g_pwd, passwd, 6)) {
			mod_lock = 1;
		} else {
			MALOGD("verify pwd err");
			result[0] = DG_PWD_ERR;
			dragonFsmSendFrame(CMD_DG_MOD_UNLOCK_PWD_O, DG_FRAME_LENGTH - 2, result);
		}
		return ;
	} else if(dragon_Recv_Buff[1] == 0x01) {  //receive new passwd 
		if(!mod_lock) {
			result[0]  = DG_FAIL;
			dragonFsmSendFrame(CMD_DG_MOD_UNLOCK_PWD_O, DG_FRAME_LENGTH - 2, result);
			MALOGE("verify old pwd error!");
			return;
		}
	}

	//update new passwd
	mod_lock = 0;
	memcpy(dragon_ctx.g_pwd, dragon_Recv_Buff + 2, 6);
	storeKeyData();

	MALOGD("new pwd: %x %x %x %x %x %x", dragon_ctx.g_pwd[0], dragon_ctx.g_pwd[1], dragon_ctx.g_pwd[2],
										 dragon_ctx.g_pwd[3], dragon_ctx.g_pwd[4], dragon_ctx.g_pwd[5]);
	
	result[0] = 0x00;
	dragonFsmSendFrame(CMD_DG_MOD_UNLOCK_PWD_O, DG_FRAME_LENGTH - 2, result);
}

void dragonUnlock(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	int8_t passwd[6];
	uint8_t unlock_sn[4];

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	memcpy(passwd, dragon_Recv_Buff + 2, 6);
	memcpy(unlock_sn, dragon_Recv_Buff + 8, 4);
	if(!array_cmp(passwd, dragon_ctx.g_pwd, 6)) {
		result[0] = DG_OK;
		platform_motor_unlock();
	} else {
		result[0] = DG_PWD_ERR;
		MALOGE("unlock error");
	}
	
	dragonFsmSendFrame(CMD_DG_UNLOCK, DG_FRAME_LENGTH - 2, result);
}

void dragonLock(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}
	
	dragonFsmSendFrame(CMD_DG_LOCK, DG_FRAME_LENGTH - 2, result);
}

void dragonGetLockState(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}
	
	dragonFsmSendFrame(CMD_DG_GET_LOCK_STE, DG_FRAME_LENGTH - 2, result);
}

void dragonSystemReset(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}
	
	dragonFsmSendFrame(CMD_DG_SYSTEM_RESET, DG_FRAME_LENGTH - 2, result);

	platform_sys_reset(0);
}

void dragonGetFingerNum(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	int32_t num;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}
	
	num = mafp_get_used_enrollids();
	result[0] = num;
	result[1] = num >> 8;

	MALOGD("finger num %d", num);
	
	dragonFsmSendFrame(CMD_DG_GET_FINGER_NUM, DG_FRAME_LENGTH - 2, result);
}

void dragonGetFpAttr(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint16_t fpNo;
	int16_t fid;
	int8_t fp_attr = 0x00;
	uint8_t isUsed;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}
	
	fpNo = dragon_Recv_Buff[2] << 8 | dragon_Recv_Buff[3];
	if(fpNo > MAX_ID) {
		MALOGE("No sequence fp");
		result[0] = DG_FAIL;
		dragonFsmSendFrame(CMD_DG_GET_FP_ATTR, DG_FRAME_LENGTH - 2, result);
		return;
	}
	
	fid = bsp_ctx.fp_used_attr[fpNo - 1].fid;
	fp_attr = bsp_ctx.fp_used_attr[fpNo - 1].attribute;
	isUsed = bsp_ctx.fp_used_attr[fpNo - 1].used;
	if(!mafp_get_enrollid_status(fid) || !isUsed) {
		MALOGE("fid %d not used", fid);
		result[0] = DG_FAIL;
		dragonFsmSendFrame(CMD_DG_GET_FP_ATTR, DG_FRAME_LENGTH - 2, result);
		return;
	}

	result[0] = DG_OK;
	result[1] = (fpNo >> 8) & 0xff;
	result[2] = fpNo & 0xff;
	result[3] = (fid >> 8) & 0xff;
	result[4] = fid & 0xff;
	result[5] = fp_attr;  //atrr byte

	MALOGD("get fid %d attribute: No.%d, atrr %x", fid, fpNo, fp_attr);
	
	dragonFsmSendFrame(CMD_DG_GET_FP_ATTR, DG_FRAME_LENGTH - 2, result);
}

int8_t getFpAttr(uint8_t fid, uint8_t *fp_attr)
{
	uint16_t i;
	uint8_t isUsed;
	uint8_t id;

	for(i = 0; i < MAX_ID; i++) {
		isUsed = bsp_ctx.fp_used_attr[i].used;
		id = bsp_ctx.fp_used_attr[i].fid & 0xff;
		//MALOGD("fid %d Used %d", id, isUsed);
		if(isUsed && (id == fid))
			break;
	}
	
	if(i >= MAX_ID) {
		return DG_FAIL;
	}

	*fp_attr = bsp_ctx.fp_used_attr[i].attribute;
	//MALOGD("fid %d, attr %d", bsp_ctx.fp_used_attr[i].fid, *fp_attr);
	return DG_OK;
}

int8_t modifyFpAttr(uint8_t fid, int8_t fp_attr, uint8_t isClear)
{
	uint16_t i;
	uint8_t isUsed;
	uint8_t id;

	//MALOGD("id %d, attr %d, isclear %d", fid, fp_attr, isClear);
	for(i = 0; i < MAX_ID; i++) {
		isUsed = bsp_ctx.fp_used_attr[i].used;
		id = bsp_ctx.fp_used_attr[i].fid & 0xff;
		//MALOGD("fid %d is %d", id, isUsed);
		if(isUsed && (id == fid))
			break;
	}

	if(i >= MAX_ID) {
		return DG_FAIL;
	} 

	if(isClear) {
		//use behind data cover index i, last data need to clear as if used
		memcpy(&bsp_ctx.fp_used_attr[i], &bsp_ctx.fp_used_attr[i + 1], (MAX_ID - (i + 1) * sizeof(fpContext)));
		if(bsp_ctx.fp_used_attr[MAX_ID - 1].used) bsp_ctx.fp_used_attr[MAX_ID - 1].used = 0;		
	} else {
		bsp_ctx.fp_used_attr[i].attribute = fp_attr;
	}
	
	storeUserCfgProp();
	return DG_OK;
}


void dragonModFpAttr(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint16_t fid;
//	int8_t passwd[6];
	int8_t fp_attr = 0x00;
	uint8_t ret;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

//	memcpy(passwd, dragon_Recv_Buff + 2, 6);
//	if(array_cmp(passwd, dragon_ctx.g_pwd, 6)) {
//		result[0] = DG_PWD_ERR;
//		MALOGE("modify attr error");
//		dragonFsmSendFrame(CMD_DG_MOD_FP_ATTR, DG_FRAME_LENGTH - 2, result);
//		return;
//	} 
	
	fid = dragon_Recv_Buff[2] << 8 | dragon_Recv_Buff[3];
	if(!mafp_get_enrollid_status(fid)) {
		MALOGE("fid %d not used", fid);
		result[0] = DG_FAIL;
		dragonFsmSendFrame(CMD_DG_MOD_FP_ATTR, DG_FRAME_LENGTH - 2, result);
		return;
	}

	fp_attr = dragon_Recv_Buff[4];
	ret =  modifyFpAttr(fid, fp_attr, 0);
	if(ret == DG_FAIL) {
		MALOGE("can't update");
		result[0] = DG_FAIL;
		dragonFsmSendFrame(CMD_DG_MOD_FP_ATTR, DG_FRAME_LENGTH - 2, result);
		return;
	}
	
	dragonFsmSendFrame(CMD_DG_MOD_FP_ATTR, DG_FRAME_LENGTH - 2, result);
}

int8_t isFpFrozen(uint16_t fid)
{
	uint16_t i;
	uint8_t isUsed;
	uint16_t id;
	uint8_t fp_attr;

	for(i = 0; i < MAX_ID; i++) {
		isUsed = bsp_ctx.fp_used_attr[i].used;
		id = bsp_ctx.fp_used_attr[i].fid;
		//MALOGD("fid %d, used %d", id, isUsed);
		if(isUsed && (id == fid))
			break;
	}

	if(i >= MAX_ID) {
		return 0;
	} 

	fp_attr = bsp_ctx.fp_used_attr[i].attribute;
	//MALOGD("fid %d in index %d, attr %x", fid, i, fp_attr);
	if(fp_attr & 0x04) {
		return 1;
	} else {
		return 0;
	}

}

void dragonAuthCallback(MatchResult state, int16_t fid, int16_t levl)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	switch(state) {
		case MATCH_SUCCESS:
			if(isFpFrozen(fid)) {
				MALOGD("fp %d is frozen", fid & 0xff);
				app_impl.send_handle_msg(MSG_FP_MATCH_FROZEN, NULL);
			} else {
				app_impl.send_handle_msg(MSG_FP_MATCH_SUCC, NULL);
				storeUnlockRecord(fid);
			}
			result[0] = DG_OK;
			result[1] = (fid << 8) & 0xff;
			result[2] = fid & 0xff;
			result[3] = (levl << 8) & 0xff;
			result[4] = levl& 0xff; 
			break;
		case MATCH_FAIL:
			result[0] = DG_FAIL;
			app_impl.send_handle_msg(MSG_FP_MATCH_FAIL, NULL);
			break;
	}

	dragonFsmSendFrame(CMD_DG_FP_AUTHENTICATE, DG_FRAME_LENGTH - 2, result);
}

int8_t appendFpAttr(uint16_t fid)
{
	uint8_t used;
	uint16_t i;

	for(i = 0; i < MAX_ID; i++) {
		used = bsp_ctx.fp_used_attr[i].used;
		if(!used) break;
	}

	if(i >= MAX_ID) {
		MALOGE("fp attr full");
		return DG_FAIL;
	}

	MALOGD("append fid %d in index %d", fid, i);
		
	bsp_ctx.fp_used_attr[i].fid = fid;
	bsp_ctx.fp_used_attr[i].used = 1;
	bsp_ctx.fp_used_attr[i].attribute =  0x00;
	storeUserCfgProp();

	return DG_OK;
}

void dragonEnrollCallback(u8 step)
{	
	u8 result[DG_FRAME_LENGTH] = {0};

	if(step >= Enroll_Tag.enroll_press_times) {
		result[0] = DG_OK;
		result[1] = 0xff;
		result[2] = 0x00;
		result[3] = Enroll_Tag.enroll_id;
		result[4] = 100;
		dragonFsmSendFrame(CMD_DG_FP_ENROLL, DG_FRAME_LENGTH - 2, result);
		appendFpAttr(Enroll_Tag.enroll_id);
	} else {
		result[0] = DG_OK;
		result[1] = step;
		result[2] = 0x00;
		result[3] = Enroll_Tag.enroll_id;
		result[4] = ((float)step / Enroll_Tag.enroll_press_times) * 100;
		dragonFsmSendFrame(CMD_DG_FP_ENROLL, DG_FRAME_LENGTH - 2, result);
	}
}


void dragonEnroll(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint16_t fid;
	uint16_t i;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}
	
	g_fsm_state = STATE_IDLE;
	fid = (dragon_Recv_Buff[2] << 8) | dragon_Recv_Buff[3];
	mafp_cancel_enroll();
	Enroll_Tag.enroll_press_times = DG_ENROLL_TIMES;
	Enroll_Tag.enroll_timeout = ENROLL_TIMEOUT_DEFAULT;
	Enroll_Tag.enroll_cb = dragonEnrollCallback;

	if(fid == 0xffff) { 
    	for(i = 0; i < MAX_ID; i++) {
        	if(!mafp_get_enrollid_status(i)) {
            	break;
			}
		}

		Enroll_Tag.enroll_id = i;
	} else {
		Enroll_Tag.enroll_id = fid & 0xff;
	}

	MALOGD("enroll fid %d", Enroll_Tag.enroll_id);

	if ( Enroll_Tag.enroll_id >= MAX_ID) {
		result[0] = 0x01;
		dragonFsmSendFrame(CMD_DG_FP_ENROLL, DG_FRAME_LENGTH - 2, result);
	} else if((mafp_get_enrollid_status(Enroll_Tag.enroll_id))== 1) {
		MALOGE("fid enrolled");
		result[0] = 0x01;
		dragonFsmSendFrame(CMD_DG_FP_ENROLL, DG_FRAME_LENGTH - 2, result);
	}
	else
	{
		g_fsm_state = STATE_ENROLL;
		Enroll_Tag.start_tick = platform_timer_us_tick();
	}
	
}

void dragonCancelEnroll(void)
{	
	uint8_t result[DG_FRAME_LENGTH] = {0};

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	mafp_cancel_enroll();
	g_fsm_state = STATE_IDLE;

	dragonFsmSendFrame(CMD_DG_FP_ENROLL_CANCEL, DG_FRAME_LENGTH - 2, result);
}

void dragonFpDelete(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint16_t fid;
//	int8_t passwd[6];

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

//	memcpy(passwd, dragon_Recv_Buff + 2, 6);
//	MALOGD("pwd: %x %x %x %x %x %x", passwd[0], passwd[1], passwd[2],
//									 passwd[3], passwd[4], passwd[5]);
//	if(!array_cmp(passwd, dragon_ctx.g_pwd, 6)) {
		result[0] = 0x00;
		fid = dragon_Recv_Buff[2] << 8 | dragon_Recv_Buff[3];
		MALOGD("delete id %d", fid);
		if(fid == 0xffff) {
			result[0] = DG_OK;
			// to do update all fid attr
			memset(bsp_ctx.fp_used_attr, 0x00, MAX_ID * sizeof(fpContext));
			mafp_clear_all_enrollids();
		} else if (fid < MAX_ID) {
			if( mafp_get_enrollid_status(fid)==0) {
				result[0] = DG_FAIL;
			} else if (mafp_remove_enrollid(fid)== 0) {
				result[0] = DG_OK;
				modifyFpAttr(fid, 0x00, 1);
			}
		} else {
			result[0] = DG_FAIL;
		}
//	} else {
//		result[0] = DG_PWD_ERR;
//		MALOGE("delete error");
//	}

	result[1] = (fid >> 8) & 0xff;
	result[2] = fid & 0xff;
	
	dragonFsmSendFrame(CMD_DG_FP_DELETE, DG_FRAME_LENGTH - 2, result);
}

void dragonFpCalibrate(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	platform_msleep(5);
	if(mafp_reinit_sensor_parameters()) {
		result[0]= DG_FAIL;
	} else {
		result[0]= DG_OK;
	}

	dragonFsmSendFrame(CMD_DG_FP_CALIBRATE, DG_FRAME_LENGTH - 2, result);
}

void dragonGetUnlockRecordNum(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint16_t num;
	
	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	result[0] = DG_OK;
	num = getUnlockRecordNum();
	result[1] = (num >> 8) & 0xff;
	result[2] = num & 0xff;
	
	dragonFsmSendFrame(CMD_DG_GET_RECORD_NUM, DG_FRAME_LENGTH - 2, result);
}

void dragonGetUnlockRecord(void)
{
	uint16_t get_num;
	uint8_t record[UNLOCK_PER_ITEM_LEN * MAX_UNLOCK_ITEM];
	uint8_t data_buff[MAX_UNLOCK_ITEM * DG_UNLOCK_ITEM_LEN + 3] = {0};
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint16_t data_len;
	uint8_t record_num, i;
	uint64_t timestamp;
	tm_date date;
	uint8_t pac_num, pac_len, max_data_len;
	uint8_t ret, fp_attr, fid;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	get_num = dragon_Recv_Buff[2] << 8 | dragon_Recv_Buff[3];
	get_num = (get_num == 0xffff) ? 0 : get_num;
	MALOGD("get %d record", get_num);

	record_num = getUnlockRecord(record, &data_len, get_num);
	data_buff[0] = DG_OK;
	data_buff[1] = 0x00;
	data_buff[2] = record_num;
	if(record_num != 0) {
		for(i = 0; i < record_num; i++) {
			fid = record[0 + (i * UNLOCK_PER_ITEM_LEN)];
			data_buff[3 + (i * DG_UNLOCK_ITEM_LEN)] = fid;  //ID
			ret = getFpAttr(fid, &fp_attr);
			MALOGD("%d: ret %d, fid %d attr %d", i + 1, ret, fid, fp_attr);
			
			data_buff[4 + (i * DG_UNLOCK_ITEM_LEN)] = 0x00;
			data_buff[5 + (i * DG_UNLOCK_ITEM_LEN)] = i + 1;
			if(ret) {
				data_buff[6 + (i * DG_UNLOCK_ITEM_LEN)] = 0x00;   //properties
			} else {
				data_buff[6 + (i * DG_UNLOCK_ITEM_LEN)] = fp_attr;
			}
			timestamp = ((record[2 + (i * UNLOCK_PER_ITEM_LEN)] << 24) 
						| (record[3 + (i * UNLOCK_PER_ITEM_LEN)] << 16) 
						| (record[4 + (i * UNLOCK_PER_ITEM_LEN)] << 8) 
						| (record[5 + (i * UNLOCK_PER_ITEM_LEN)] & 0xff)) & 0xffffffff;
			date = unixTimestamp_to_localTime(timestamp);
			data_buff[7 + (i * DG_UNLOCK_ITEM_LEN)] = date.year - 2000;
			data_buff[8 + (i * DG_UNLOCK_ITEM_LEN)] = date.mon;
			data_buff[9 + (i * DG_UNLOCK_ITEM_LEN)] = date.mday;
			data_buff[10 + (i * DG_UNLOCK_ITEM_LEN)] = date.hour;
			data_buff[11 + (i * DG_UNLOCK_ITEM_LEN)] = date.min;
			data_buff[12 + (i * DG_UNLOCK_ITEM_LEN)] = date.sec;
		}
	} else {
		result[0] = DG_FAIL;
		dragonFsmSendFrame(CMD_DG_GET_RECORD, DG_FRAME_LENGTH - 2, result);
		return ;
	}

	data_len = (record_num * DG_UNLOCK_ITEM_LEN + 3);
	max_data_len = (DG_FRAME_LENGTH - 2 );
	pac_num = data_len / max_data_len;
	pac_len = pac_num ? max_data_len : (data_len % max_data_len);
	dragonFsmSendFrame(CMD_DG_GET_RECORD, pac_len, data_buff);
	i = 0;
	while(pac_num) {
		pac_num--;
		pac_len = pac_num ? max_data_len : (data_len % max_data_len);
		i++;
		dragonFsmSendFrame(CMD_DG_GET_RECORD_2, pac_len, data_buff + (i * max_data_len));
	}
}

void dragonClrUnlockRecord(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	if(!clearUnlockRecord())
		result[0] = DG_OK;
	else
		result[0] = DG_FAIL;

	dragonFsmSendFrame(CMD_DG_CLR_RECORD, DG_FRAME_LENGTH - 2, result);
}

void dragonGetFrozenID(void)
{
	uint8_t result[DG_FRAME_LENGTH] = {0};
	uint8_t frozen_list[MAX_ID] = {0};
	uint8_t i, j = 0, k = 0;
	uint8_t pac_num, pac_len;

	if(dragonCheckToken()) {
		MALOGE("token error");
		return;
	}

	for(i = 0; i < MAX_ID; i++) {
		if(isFpFrozen(i))
			frozen_list[j++] = i;
	}
	pac_num = j / 6;
	pac_len = pac_num ? 5 : (j % 5);
	//MALOGD("j %d, pac_num %d, pac_len %d", j, pac_num, pac_len);
	result[0] = DG_OK;
	result[1] = 0x00;
	result[2] = j;
	if(pac_len != 0) {
		for(i = 0; i < pac_len; i++) {
			result[4 + (i * 2)] = frozen_list[i];
		}
	}
	dragonFsmSendFrame(CMD_DG_GET_FROZEN, DG_FRAME_LENGTH - 2, result);
	k = 0;
	while(pac_num) {
		pac_num--;
		k++;
		pac_len = pac_num ? 6 : (j % 6);
		memset(result, 0x00, DG_FRAME_LENGTH);
		//MALOGD("i %d, pac_num %d, pac_len %d", i, pac_num, pac_len);
		result[0] = frozen_list[(k * 6) - 1];
		if(pac_len != 0) {
			for(i = 0; i < pac_len; i++) {
				result[2 + (i * 2)] = frozen_list[i + (k * 6)];
			}
		}
		dragonFsmSendFrame(CMD_DG_GET_FROZEN_2, DG_FRAME_LENGTH - 2, result);
	}
}

void sendCommAck(DragonCmd cmd) 
{
	uint8_t result[DG_FRAME_LENGTH] = {0};

	result[0] = (cmd >> 8) & 0xff;
	result[1] = cmd & 0xff;

	dragonFsmSendFrame(CMD_DG_COMM, DG_FRAME_LENGTH - 2, result);
}

static void dragonExecFunc(DragonCmd cmd)
{
	MALOGD("exec cmd 0x%x", cmd);

	switch(cmd)
	{
		case CMD_DG_QUERY_DBG:
			sendCommAck(cmd);
			break;
		case CMD_DG_OPEN_DBG:
			sendCommAck(cmd);
			break;
		case CMD_DG_CLOSE_DBG:
			sendCommAck(cmd);
			break;
		case CMD_DG_INTERACT_DBG:
			sendCommAck(cmd);
			break;
		case CMD_DG_WR_FACTORY_CFG:
			sendCommAck(cmd);
			dragonWRFactoryCfg();
			break;
		case CMD_DG_RD_FACTORY_CFG:
			sendCommAck(cmd);
			dragonRDFactoryCfg();
			break;
		case CMD_DG_WR_USER_DATA:
			sendCommAck(cmd);
			break;
		case CMD_DG_RD_USER_DATA:
			sendCommAck(cmd);
			break;
		case CMD_DG_WR_TOKEN:
			sendCommAck(cmd);
			dragonGetToken();
			break;
		case CMD_DG_SET_DATE:
			sendCommAck(cmd);
			dragonSetDate();
			break;
		case CMD_DG_GET_DATE:
			sendCommAck(cmd);
			dragonGetDate();
			break;
		case CMD_DG_GET_BAT:
			sendCommAck(cmd);
			dragonGetBattery();
			break;
		case CMD_DG_MOD_BT_NAME:
			sendCommAck(cmd);
			dragonModBtName();
			break;
		case CMD_DG_MOD_AES_SKEY_L:
		case CMD_DG_MOD_AES_SKEY_H:
			sendCommAck(cmd);
			dragonModAESKey();
			break;
		case CMD_DG_MOD_UNLOCK_PWD_O:
		case CMD_DG_MOD_UNLOCK_PWD_N:
			sendCommAck(cmd);
			dragonModPwd();
			break;
		case CMD_DG_UNLOCK:
			sendCommAck(cmd);
			dragonUnlock();
			break;
		case CMD_DG_LOCK:
			sendCommAck(cmd);
			dragonLock();
			break;
		case CMD_DG_LOCK_MUAL:
			sendCommAck(cmd);
			dragonLock();
			break;
		case CMD_DG_GET_LOCK_STE:
			sendCommAck(cmd);
			dragonGetLockState();
			break;
		case CMD_DG_SYSTEM_RESET:
			sendCommAck(cmd);
			dragonSystemReset();
			break;
		case CMD_DG_GET_FINGER_NUM:
			sendCommAck(cmd);
			dragonGetFingerNum();
			break;
		case CMD_DG_GET_FP_ATTR:
			sendCommAck(cmd);
			dragonGetFpAttr();
			break;
		case CMD_DG_MOD_FP_ATTR:
			sendCommAck(cmd);
			dragonModFpAttr();
			break;
		case CMD_DG_FP_ENROLL:
			sendCommAck(cmd);
			dragonEnroll();
			break;
		case CMD_DG_FP_ENROLL_CANCEL:
			sendCommAck(cmd);
			dragonCancelEnroll();
			break;
		case CMD_DG_FP_AUTHENTICATE:
			sendCommAck(cmd);
			break;
		case CMD_DG_FP_DELETE:
			sendCommAck(cmd);
			dragonFpDelete();
			break;
		case CMD_DG_FP_CALIBRATE:
			sendCommAck(cmd);
			dragonFpCalibrate();
			break;
		case CMD_DG_GET_RECORD_NUM:
			sendCommAck(cmd);
			dragonGetUnlockRecordNum();
			break;
		case CMD_DG_GET_RECORD:
			sendCommAck(cmd);
			dragonGetUnlockRecord();
			break;
		case CMD_DG_CLR_RECORD:
			sendCommAck(cmd);
			dragonClrUnlockRecord();
			break;
		case CMD_DG_GET_FROZEN:
			sendCommAck(cmd);
			dragonGetFrozenID();
			break;
		default:
			MALOGD("no such cmd");
			break;
	}
	
}
