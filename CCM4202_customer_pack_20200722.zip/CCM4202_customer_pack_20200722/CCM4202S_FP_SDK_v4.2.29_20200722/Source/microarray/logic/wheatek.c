#include "wheatek.h"
#include "malog.h"
#include "hardware_bsp.h"
#include "kg_utils.h"
#include "mafp_sensor.h"
#include "globalvar.h"

static u8 wheatek_Recv_Buff[WH_FRAME_LENGTH];
static u8 wheatek_Send_Buff[WH_FRAME_LENGTH * WH_MAX_FRAMES];
static u8 frameData_Buff[WH_FRAME_LENGTH * WH_MAX_FRAMES + 1];  //index 0 mean the data length 

static void wheatekExcFunc(WheatekCmd cmd);

void wheatekfsmInit(void)
{
	g_fsm_state = STATE_IDLE;
	memcpy(UART_SVC_ADV_NAME, DEFAULT_UART_SVC_ADV_NAME, sizeof(DEFAULT_UART_SVC_ADV_NAME));
}

u8 checkSum(u8 *check_buff)
{
    u8 chk_sum = 0;
	u8 i;

	for(i = 2; i < WH_FRAME_LENGTH - 1; i++) chk_sum += check_buff[i];
	MALOGD("chk_sum = 0x%x, pos = 0x%x", chk_sum, check_buff[WH_FRAME_LENGTH - 1]);
    return check_buff[WH_FRAME_LENGTH - 1] == (chk_sum & 0xff);
}

static S32 wheatekFsmGetFrame(uint8_t const* frame,U8 err_flag)
{
	if(!(frame[0] == (WH_FRAME_START >> 8) && frame[1] == (WH_FRAME_START & 0x00ff)))
	{
        return 0;
	}
	else
	{
		memcpy(wheatek_Recv_Buff, frame, WH_FRAME_LENGTH);
	    if(checkSum(wheatek_Recv_Buff))
		{
		   /* debugPrint("frame receive:");
		    for(i = 0; i < WH_FRAME_LENGTH; i++) {
		        debugPrint("0x%x ", wheatek_Recv_Buff[i]);
		    }
			debugPrint("\n");*/
			return 1;	
		}
		else
		{
			//if needed, send error package to terminal
			MALOGE("chk sum failed");
			return 0;
		}
	}

}

u8 fetchDataFromFrame(void)
{
	u8 data_len, frame_seq, frame_count;
    static u8 all_data_len = 0;
	u8 i;

    frame_count = wheatek_Recv_Buff[WH_FRAME_COUNT_POS];
	data_len = wheatek_Recv_Buff[WH_FRAME_DATA_LEN_POS];
	frame_seq = wheatek_Recv_Buff[WH_FRAME_SEQ_POS];
	all_data_len += wheatek_Recv_Buff[WH_FRAME_DATA_LEN_POS];
	//memcpy((frameData_Buff + (frame_seq - 1) * FRAME_DATA_MAX_LEN) + 1, (void)wheatek_Recv_Buff[WH_FRAME_DATA_STA_POS], data_len);
	for(i = 0; i < data_len; i++) {
        frameData_Buff[i + 1 + (frame_seq - 1) * FRAME_DATA_MAX_LEN] = wheatek_Recv_Buff[WH_FRAME_DATA_STA_POS + i];
	}
    if (frame_seq == frame_count){
		frameData_Buff[0] = all_data_len;
		all_data_len = 0;
		return 1;
	}

	return 0;
}

void wheatekFsmTask(uint8_t const* frame)
{
	U16 command = 0;
	u8 isFetchFinish;

	if (wheatekFsmGetFrame(frame,0))
	{
	    //MALOGD("PID high = 0x%x, PID low = 0x%x, command = %x", wheatek_Recv_Buff[WH_FRAME_PID_HIGH], wheatek_Recv_Buff[WH_FRAME_PID_LOW], command);
		command = (wheatek_Recv_Buff[WH_FRAME_PID_HIGH] << 8) + wheatek_Recv_Buff[WH_FRAME_PID_LOW];
		MALOGD("fetch command: 0x%x, data length:%d", command, wheatek_Recv_Buff[WH_FRAME_DATA_LEN_POS]);
		isFetchFinish = fetchDataFromFrame();
		if (isFetchFinish) {
			isFetchFinish = 0;
		    //print receive data
		    /*for(i = 1; i < frameData_Buff[0] + 1; i++) {
                debugPrint("0x%x ", frameData_Buff[i]);
		    }
			debugPrint("\n:");*/
			
			wheatekExcFunc((WheatekCmd)command);
		}
	} 
}

static U16 wheatekFrameSetPack(U16 _data_len,u8* _data_buf,WheatekCmdRes _type,u8 * _send_buff)
{

	U16 i,j;
	u8 frameCount;
	u8 lastFrameData;

	if(_send_buff&&_data_buf)   
	{ 
	   // frameCount = (_data_len / FRAME_DATA_MAX_LEN) ? (_data_len / FRAME_DATA_MAX_LEN) : 1;
	   frameCount = (_data_len + FRAME_DATA_MAX_LEN - 1) / FRAME_DATA_MAX_LEN;
	   frameCount = frameCount ? frameCount : 1;
	    memset(_send_buff, 0x00, WH_FRAME_LENGTH * WH_MAX_FRAMES);
	    for(i = 0; i < frameCount; i++)
	    {
	    	/*make packet head*/
		    _send_buff[0 + (i * WH_FRAME_LENGTH)] = (WH_FRAME_START>>8);
		    _send_buff[1 + (i * WH_FRAME_LENGTH)] = (WH_FRAME_START & 0xff);

		    //if package more than WH_FRAME_LENGTH bytes then need judge
		    _send_buff[2 + (i * WH_FRAME_LENGTH)] = frameCount;
		    _send_buff[3 + (i * WH_FRAME_LENGTH)] = i + 1;
		    _send_buff[4 + (i * WH_FRAME_LENGTH)] = _type >> 8;
		    _send_buff[5 + (i * WH_FRAME_LENGTH)] = _type & 0x00ff;
			lastFrameData = (frameCount - (i + 1)) ?  FRAME_DATA_MAX_LEN : (_data_len - i * FRAME_DATA_MAX_LEN);
		    _send_buff[6 + (i * WH_FRAME_LENGTH)] = lastFrameData;

			//MALOGD("%dth frame, frame data len: %d", i+1, lastFrameData);
		    memcpy(&_send_buff[7 + (i * WH_FRAME_LENGTH)], _data_buf + (i * FRAME_DATA_MAX_LEN), lastFrameData);
			
		    //add checksum byte, sumary bytes exclude frame head 
		    for(j = 2; j < WH_FRAME_LENGTH - 1; j++)
		        _send_buff[19 + (i * WH_FRAME_LENGTH)] += _send_buff[j + (i * WH_FRAME_LENGTH)];
	    }

		/*MALOGD("all send data len: %d, total frame: %d", _data_len, frameCount);
		for(j = 0; j < frameCount * WH_FRAME_LENGTH; j++)
		{
			debugPrint("0x%x ", _send_buff[j]);
			if((j + 1) % WH_FRAME_LENGTH == 0) debugPrint("\n");
		}*/
		
		return frameCount * WH_FRAME_LENGTH;
	}
	else
	{
	    //MALOGE("end, send or data buff is null");
		return 0;
	}

}

static void wheatekFsmSendFrame(WheatekCmdRes _ack,U16 _data_len,u8 *_data_buf)
{
	U16 len;
	u8 i;

	if(_data_buf)
	{
		len=wheatekFrameSetPack(_data_len,_data_buf,_ack,wheatek_Send_Buff);

		//divid package to send
		//MALOGD("UART send respose frame:%d", len / WH_FRAME_LENGTH);
		for(i = 0; i < len / WH_FRAME_LENGTH; i++){
			//first send front frame of package
		    //uartSendBuff(wheatek_Send_Buff + i * WH_FRAME_LENGTH, WH_FRAME_LENGTH);
		    platform_bluetooth_send_notification(wheatek_Send_Buff + i * WH_FRAME_LENGTH, WH_FRAME_LENGTH);	
		}
	}
}

void wheatekFsmUnlock()
{
	u8 result = WHEATEK_SUCCESS;;

    //need to unlock 		
	platform_motor_unlock();
	
	//motor has no call back value, so result is always 0
	wheatekFsmSendFrame(CMD_WH_UNLOCK_RES, 1, &result);
}

void wheatekFsmMotorRun()
{
    u8 result = WHEATEK_SUCCESS;;
    u8 direction; 

	direction = frameData_Buff[1];    
	//motor run according direction
    if(direction) {	
		platform_motor_unlock();
	} else {		
		platform_motor_unlock();
	}

    //send respose to terminal
	wheatekFsmSendFrame(CMD_WH_MOTOR_RUN_RES, 1, &result);
}

void wheatekFsmFactoryReset()
{
    u8 result = WHEATEK_SUCCESS;
	u8 unlock_record[WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1];
	
    //delete all enrolled fingerprint
	memcpy(UART_SVC_ADV_NAME, DEFAULT_UART_SVC_ADV_NAME, sizeof(DEFAULT_UART_SVC_ADV_NAME));
    if(mafp_clear_all_enrollids() == ERROR_CLEAR_FIDS) 
	{
        result = WHEATEK_FAIL;
	} 
	else
	{
		//reset sensor calibration data
		//ret = platform_fs_erase_page(SYS_PARA_ADDR, 0xffff);
		initDeviceErase();
		platform_fs_erase_page(SENSOR_PROPERTY_ADDR, 0xffff);
		
		//delete all unlock record
		memset(unlock_record, 0x00, WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1);
		platform_filesystem_write(WHEATEK_PARA_ADDR, (U32 *)unlock_record, WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1);
	}
	lock_async_call_wrapper(BSP_touch_process, NULL);
	//send respose to terminal
    wheatekFsmSendFrame(CMD_WH_FACTORY_RESET_RES, 1, &result);	
}

void wheatekEnrollCallback(u8 step)
{	
	u8 result[2];

	if(step >= Enroll_Tag.enroll_press_times)
	{
		result[0] = 0;
		result[1] = 0;
	}
	else 
	{
		result[0] = step;
		result[1] = 0;
	}
	wheatekFsmSendFrame(CMD_WH_ENROLL_RES , 2, result);
}

void wheatekFsmEnroll()
{
    u8 result[2];
    u8 fid, isStop;
	
	fid = frameData_Buff[1];
	isStop = frameData_Buff[2];

	//Enroll a finger flow
    if(isStop) {
		Enroll_Tag.stop_flag = 1;
		lock_async_call_wrapper(BSP_touch_process, NULL);
	} else {
        g_fsm_state = STATE_IDLE;
		Enroll_Tag.enroll_press_times = DEFAULT_ENROLL_TIMES;	 //4
		Enroll_Tag.enroll_timeout = ENROLL_TIMEOUT_DEFAULT;			 //(3 * 1000 * 1000)
		Enroll_Tag.enroll_cb = wheatekEnrollCallback;
		Enroll_Tag.enroll_id = fid - 1;

		MALOGD("fid = %d", Enroll_Tag.enroll_id);
		if (fid > WH_MAX_FINGER_NUM || fid <= 0)
		{
			//MALOGD("Enroll_Tag.enroll_id >= MAX_ID\n");
			result[0] = 0x00;
			result[1] = ERR_FP_ID_ERR;
			wheatekFsmSendFrame(CMD_WH_ENROLL_RES , 2, result);
		}
		else if( (mafp_get_enrollid_status(Enroll_Tag.enroll_id))== 1)
		{
			//MALOGD("(mafp_get_enrollid_status(Enroll_Tag.enroll_id))== 1");
			platform_msleep(5);
			result[0] = 0x00;
			result[1] = ERR_FP_ID_ENROLLED;
			wheatekFsmSendFrame(CMD_WH_ENROLL_RES , 2, result);
		} else {
			//MALOGD("g_fsm_state = STATE_ENROLL	now !!");
			g_fsm_state = STATE_ENROLL;
			Enroll_Tag.start_tick = platform_timer_us_tick();
		}
	}
}

void wheatekFsmDelete()
{
    u8 result;
	u8 fid;

	fid = frameData_Buff[1];
	if(fid == 0){
        //delete all enrolled fingerprint
		if(mafp_clear_all_enrollids() == ERROR_CLEAR_FIDS) {
            result = WHEATEK_FAIL;
		} else {
            result = WHEATEK_SUCCESS;
		}
	} else {
        //delete fingerprint belong fid
        if(mafp_remove_enrollid(fid - 1) == 0) {
            result = WHEATEK_SUCCESS;
		} else {
            result = WHEATEK_FAIL;
		}
	}

	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_DELET_RES, 1, &result);

}

void wheatekFsmSetDate()
{
    u8 result;
	time_t t_unix;

	// use 4 bytes calculate unix timestamp, frameData_Buff[5] reserved
	t_unix = (frameData_Buff[2] << 24) + (frameData_Buff[3] << 16) + (frameData_Buff[4] << 8) + frameData_Buff[5];
    //MALOGD("set time : %d-%d-%d %d:%d:%d, unix time stamp: %lu", local_date.year, local_date.mon, local_date.mday, local_date.hour, local_date.min, local_date.sec, t_unix);
	//set the date
    result = platform_rtc_set_sys_time(t_unix);

	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_SET_DATE_RES, 1, &result);
}

void wheatekFsmDelUnlockRecord()
{
    u8 result;
	u8 unlock_record[WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1];

	//delete record
	memset(unlock_record, 0x00, WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1);
	platform_filesystem_write(WHEATEK_PARA_ADDR, (U32 *)unlock_record, WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1);
	result = WHEATEK_SUCCESS;
	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_DEL_UNLOCK_RECORD_RES, 1, &result);
}

void wheatekFsmModBleName()
{
    u8 result = WHEATEK_SUCCESS;
    u8 name_len;

	name_len = frameData_Buff[0];
	if(name_len > MAX_BLE_NAME_LEN || name_len <= 0) 
	{
		result = WHEATEK_FAIL;
	}
	else
	{
		memset(UART_SVC_ADV_NAME, 0x0, sizeof(UART_SVC_ADV_NAME));
		memcpy(UART_SVC_ADV_NAME, &frameData_Buff[1], name_len);
	}
	
    //send respose to terminal
	wheatekFsmSendFrame(CMD_WH_MOD_BLE_NAME_RES, 1, &result);
}


void wheatekFsmFpManage()
{
    u8 result = WHEATEK_SUCCESS;
	u8 isClose;

	isClose = frameData_Buff[1];
	if(isClose) {
        //close fp manager
	} else {
        //enter fp manager
	}

	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_FP_MANAGE_RES, 1, &result);
}

void wheatekFsmGetDate()
{
    u8 result[5];    
    uint64_t timeStamp;	
    
    timeStamp = platform_rtc_get_sys_time();
	//MALOGD("now time is %d-%d-%d %d:%d:%d, unix time stamp: %lu", date.year, date.mon, date.mday, date.hour, date.min, date.sec, timeStamp);
	
	//send respose to terminal
	result[0] = 0;//(timeStamp >> 32) & 0xff;
	result[1] = (timeStamp >> 24) & 0xff;
	result[2] = (timeStamp >> 16) & 0xff;
	result[3] = (timeStamp >> 8) & 0xff;
	result[4] = timeStamp & 0xff;
	wheatekFsmSendFrame(CMD_WH_GET_DATE_RES, 5, result);

}


void wheatekFsmEnumerateFp()
{
    u8 result[4] = {0};
	u8 INDEX_STEP = 8;
    u8 i;

	//enumerate 20 fingerprints into result[0] ~ result[2]; result[3] is the operation result 
    for(i = 0; i <= WH_MAX_FINGER_NUM; i++) {
        if(mafp_get_enrollid_status(i)) {
            result[ 2 - (i / INDEX_STEP)] |= 1 << (i % INDEX_STEP);
		}
	} 
	
	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_ENROLLED_FP_NUM_RES, 4, result);
	MALOGD("end,fid list = 0x%x%x%x%x", result[2], result[1], result[0], result[3]);
}

void wheatekFsmGetUnlockRecord()
{
    u8 result[WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM];
	u8 get_num, record_data_len, recorded_num;
	u8 unlock_record[WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1];
	u8 i, cur_index = 0;
	
	/*unlock_record[WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM] is the record num*/
	memcpy(unlock_record, (u8 *)WHEATEK_PARA_ADDR, WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1);
	get_num = frameData_Buff[1];
	get_num = get_num? get_num : WHEATEK_MAX_UNLOCK_ITEM;
	recorded_num = unlock_record[0];
	recorded_num = recorded_num == 0xff ? 0 : recorded_num; 
	cur_index = recorded_num % WHEATEK_MAX_UNLOCK_ITEM;
	MALOGD("has %d records, cur_index = %d, get %d items", recorded_num, cur_index, get_num);
	if(recorded_num <= 0)
	{
		record_data_len = 0;
	} 
	else if(recorded_num >= WHEATEK_MAX_UNLOCK_ITEM) 
	{
		get_num = get_num > recorded_num? recorded_num : get_num;
		record_data_len = get_num * WHEATEK_PER_ITEM_LEN;
		for(i=0; i<get_num; i++)
		{
			memcpy(result + (i * WHEATEK_PER_ITEM_LEN), 
				   unlock_record + 1 + ((cur_index + i) % WHEATEK_MAX_UNLOCK_ITEM) * WHEATEK_PER_ITEM_LEN,
				   WHEATEK_PER_ITEM_LEN);
		} 
	} 
	else
	{
		get_num = get_num > recorded_num? recorded_num : get_num;
		record_data_len = get_num * WHEATEK_PER_ITEM_LEN;
		memcpy(result, unlock_record + 1, record_data_len);
	}

	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_UNLOCK_RECORD_RES, record_data_len, result);
}

void wheatekFsmGetBattery()
{
    u8 result;

	result  = getBatteryPercent();
	
    //send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_BATTERY_RES, 1, &result);
	MALOGD("end, battery is %d", result);
}

void wheatekFsmGetBleAddr()
{
    u8 result[6] = {0}, i;
    unsigned char * address;

	address = platform_bluetooth_get_address();
	//sprintf(address,"%02x%02x%02x%02x%02x%02x",mac[5],mac[4],mac[3],mac[2],mac[1],mac[0]);
	//MALOGD("mac_address = %s",address);
	//memcpy(result, bd_ad_data, NVDS_LEN_BD_ADDRESS);
	for(i=0; i<6; i++) result[i] = address[i];
	
    //send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_BLE_ADDR_RES, 6, result);
}

void wheatekFsmGetBleRSSI()
{
    u8 result = WHEATEK_SUCCESS;

    //send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_BLE_RSSI_RES, 1, &result);
}

void wheatekFsmGetVendorID()
{
    u8 result[MAX_STR_LEN];
	u8 len;

	len = sizeof(OEM);
	if(len < MAX_STR_LEN)
	{
		memcpy(result,OEM, len);
		len = len - 1;   //delete string stop flag
		//MALOGD("made by %s", result);
	} else {
		result[0] = WHEATEK_FAIL;
		len = 1;
	}
	
	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_VENDOR_ID_RES, len, result);
}

void wheatekFsmGetDeviceModel()
{
    u8 result[MAX_STR_LEN];
	u8 len;

	len = sizeof(DEVICE_NAME);
	if(len < MAX_STR_LEN)
	{
    	memcpy(result,DEVICE_NAME, len);
		len = len - 1;   //delete string stop flag
		//MALOGD("model No.  %s", result);
	} else {
		result[0] = WHEATEK_FAIL;
		len = 1;
	}
	
	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_DEVICE_MODEL_RES, len, result);
}

void wheatekFsmGetSWVer()
{
    u8 result[MAX_STR_LEN];
	u8 len;

	len = sizeof(VERSION_INFO);
	if(len < MAX_STR_LEN)
	{
	    memcpy(result,VERSION_INFO, len);
		len = len - 1;   //delete string stop flag
		//MALOGD("SW version :  %s", result);
	} else {
		result[0] = WHEATEK_FAIL;
		len = 1;
	}
	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_SW_VER_RES, len, result);
}

void wheatekFsmGetBleName()
{
    u8 result[MAX_STR_LEN];
	u8 len;

	len = sizeof(UART_SVC_ADV_NAME);
	if(len <= MAX_STR_LEN) {
    	memcpy(result,UART_SVC_ADV_NAME, len);
		//MALOGD("BLE Name :  %s", result);
	} else {
		result[0] = WHEATEK_FAIL;
		len = 1;
	}
	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_BLE_NAME_RES, len, result);
}

void wheatekFsmGetMinFpID()
{
    u8 result[2];

    u8 i;

	//enumerate 20 fingerprints into result[0] ~ result[2]; result[3] is the operation result 
    for(i = 0; i < WH_MAX_FINGER_NUM; i++) {
        if(!mafp_get_enrollid_status(i)) {
            break;
		}
	}
    result[0] = i + 1;
	result[1] = 0;

	//send respose to terminal
	wheatekFsmSendFrame(CMD_WH_GET_FP_MIN_ID_RES, 2, result);
}

static void wheatekExcFunc(WheatekCmd cmd)
{
	switch(cmd)
	{
	case CMD_WH_UNLOCK:
        wheatekFsmUnlock();
		break;
	case CMD_WH_MOTOR_RUN:
        wheatekFsmMotorRun();
		break;
	case CMD_WH_FACTORY_RESET:
        wheatekFsmFactoryReset();
		break;
	case CMD_WH_ENROLL:
        wheatekFsmEnroll();
		break;
	case CMD_WH_DELET:
        wheatekFsmDelete();
		break;
	case CMD_WH_SET_DATE:
        wheatekFsmSetDate();
		break;
	case CMD_WH_DEL_UNLOCK_RECORD:
        wheatekFsmDelUnlockRecord();
		break;
	case CMD_WH_MOD_BLE_NAME:
        wheatekFsmModBleName();
		break;
	case CMD_WH_FP_MANAGE:
        wheatekFsmFpManage();
		break;
	case CMD_WH_GET_DATE:
        wheatekFsmGetDate();
		break;
	case CMD_WH_GET_ENROLLED_FP_NUM:
        wheatekFsmEnumerateFp();
		break;
	case CMD_WH_GET_UNLOCK_RECORD:
        wheatekFsmGetUnlockRecord();
		break;
	case CMD_WH_GET_BATTERY:
        wheatekFsmGetBattery();
		break;
	case CMD_WH_GET_BLE_ADDR:
        wheatekFsmGetBleAddr();
		break;
	case CMD_WH_GET_BLE_RSSI:
        wheatekFsmGetBleRSSI();
		break;
	case CMD_WH_GET_VENDOR_ID:
        wheatekFsmGetVendorID();
		break;
	case CMD_WH_GET_DEVICE_MODEL:
        wheatekFsmGetDeviceModel();
		break;
	case CMD_WH_GET_SW_VER:
        wheatekFsmGetSWVer();
		break;
	case CMD_WH_GET_BLE_NAME:
        wheatekFsmGetBleName();
		break;
	case CMD_WH_GET_FP_MIN_ID:
        wheatekFsmGetMinFpID();
		break;
	default:
		break;
	}

}

void wheatekStoreUnlockRecord(u8 fid)
{
    u8 unlock_record[WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1];
	u8 ptr_unlock_item = 0;
	//tm_date date;
    uint64_t timeStamp;

	memcpy(unlock_record, (u8 *)WHEATEK_PARA_ADDR, WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1);
	ptr_unlock_item = unlock_record[0];
    timeStamp = platform_rtc_get_sys_time();//localTime_to_unixTimestamp(date);

    //ptr_unlock_item++; //index is start from 0
	unlock_record[1 + (ptr_unlock_item % WHEATEK_MAX_UNLOCK_ITEM) * WHEATEK_PER_ITEM_LEN] = fid;
	unlock_record[2 + (ptr_unlock_item % WHEATEK_MAX_UNLOCK_ITEM) * WHEATEK_PER_ITEM_LEN] = 0;//(timeStamp >> 32) & 0xff;
	unlock_record[3 + (ptr_unlock_item % WHEATEK_MAX_UNLOCK_ITEM) * WHEATEK_PER_ITEM_LEN] = (timeStamp >> 24) & 0xff;
	unlock_record[4 + (ptr_unlock_item % WHEATEK_MAX_UNLOCK_ITEM) * WHEATEK_PER_ITEM_LEN] = (timeStamp >> 16) & 0xff;
	unlock_record[5 + (ptr_unlock_item % WHEATEK_MAX_UNLOCK_ITEM) * WHEATEK_PER_ITEM_LEN] = (timeStamp >> 8) & 0xff;
	unlock_record[6 + (ptr_unlock_item % WHEATEK_MAX_UNLOCK_ITEM) * WHEATEK_PER_ITEM_LEN] = timeStamp & 0xff;
	ptr_unlock_item++;
	//if(ptr_unlock_item > WHEATEK_MAX_UNLOCK_ITEM) ptr_unlock_item = 0;
	//more than 256 records, something terrible will be happened
	unlock_record[0] = ptr_unlock_item;
	//MALOGD("ptr_unlock_item=%d, record timestamp = %lu",ptr_unlock_item, timeStamp);    //this log cause auth image partial????????
	platform_filesystem_write(WHEATEK_PARA_ADDR, (U32 *)unlock_record, WHEATEK_PER_ITEM_LEN * WHEATEK_MAX_UNLOCK_ITEM + 1);
	
}





