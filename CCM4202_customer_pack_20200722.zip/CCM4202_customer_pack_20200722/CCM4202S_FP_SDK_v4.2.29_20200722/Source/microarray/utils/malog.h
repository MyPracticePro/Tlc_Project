#ifndef MA_LOG_H
#define MA_LOG_H

#define  PLATFORM_CCM4202
#define  SENSOR_E120N

#ifdef PLATFORM_BX2400
#include "m_uart.h"
#include "log.h"
#endif

#ifdef PLATFORM_AC693X
#include "generic/printf.h"
#endif

#define BSP_UART_DEBUG_LOG

#ifdef PLATFORM_BX2400
#ifdef BSP_UART_DEBUG_LOG
#define MALOGD(format, ...) debugPrint("[%s:%d] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGI(format, ...) debugPrint("[%s:%d][info] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGE(format, ...) debugPrint("[%s:%d][error] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#else
#ifdef BSP_SYS_DEBUG_LOG
#define MALOGD(format, ...) LOG(LOG_LVL_INFO, "[%s:%d] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGI(format, ...) LOG(LOG_LVL_INFO, "[%s:%d][info] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGE(format, ...) LOG(LOG_LVL_ERROR, "[%s:%d][error] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#else
#define MALOGD(format, ...)
#define MALOGI(format, ...)
#define MALOGE(format, ...)
#endif
#endif
#endif

#ifdef PLATFORM_AC693X
#ifdef BSP_UART_DEBUG_LOG
#define MALOGD(format, ...) printf("[%s:%d] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGI(format, ...) printf("[%s:%d][info] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGE(format, ...) printf("[%s:%d][error] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#else
#define MALOGD(format, ...)
#define MALOGI(format, ...)
#define MALOGE(format, ...)
#endif
#endif

#ifdef PLATFORM_CCM4202
#ifdef BSP_UART_DEBUG_LOG
#define MALOGD(format, ...) printf("[%s:%d] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGI(format, ...) printf("[%s:%d][info] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#define MALOGE(format, ...) printf("[%s:%d][error] " format "\r\n", __func__, __LINE__, ##__VA_ARGS__ )
#else
#define MALOGD(format, ...)
#define MALOGI(format, ...)
#define MALOGE(format, ...)
#endif
#endif


#endif
