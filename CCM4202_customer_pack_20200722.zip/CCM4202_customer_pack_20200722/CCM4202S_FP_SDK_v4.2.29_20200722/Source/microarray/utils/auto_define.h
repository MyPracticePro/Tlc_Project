#ifndef __AUTO_DEFINE_H__
#define __AUTO_DEFINE_H__

#define PROJECT "RL1"

#define CUSTOMER "LXD"

#define OEM_MICROARRAY 1

#define OEM "MICROARRAY"

#define BOARD "MPB010"

#define PLATFORM "CCM4202"

#define SENSOR "E120N"

#define PRODUCT "padlock"

#define DEFAULT_UART_SVC_ADV_NAME "MPB010"

#define BLE_BEGIN_MAC "C7:00:00:00:00:01"

#define COM_PROTOCOL "LXD"

#define ENROLL_TIMES 4

#define MATCH_RETRYTIMES 1

#define MOTOR_FORWARD 120

#define MOTOR_BACKWARD 70

#define MOTOR_INTERVAL 400

#define LED_FLASH_COUNT 2

#define LED_FLASH_DURA 2

#define LED_LIGHT_DURA 400

#define LOW_BATTERY 20

#define PROJECT_NAME "RL1-LXD-MICROARRAY-MPB010-CCM4202-E120N-padlock"

#define DEVICE_NAME "RL1-MPB010"

#define VERSION_INFO "RL1_LXD_V4.2.35_S0730"

#define GIT_LONG_VERSION "d82eac516bd034745ab8d08b6cf3e0c13a1e2d51"

#define COMPILE_USER "desktop-r4dmuef\sheph"

#define GIT_TAG "v4.2-35-gd82eac5"

#define GIT_USER "Young"

#define GIT_BRANCH "refs/heads/master"

#define GIT_SHORT_VERSION "d82eac5"

#endif /*__AUTO_DEFINE_H__*/
