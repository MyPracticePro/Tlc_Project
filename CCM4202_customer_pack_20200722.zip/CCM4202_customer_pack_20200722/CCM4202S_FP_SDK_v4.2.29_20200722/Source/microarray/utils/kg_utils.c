#include "kg_utils.h"

static char daytab[2][13]= {
	{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
	{0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
};


extern uint32_t platform_timer_us_tick(void);


/************************************************************************/
/* day_of_year : set day of year from month & day */
/************************************************************************/
int day_of_year(int year, int month, int day) 
{
	int i, leap; 	
	leap = year % 4 == 0 && year % 100 != 0 || year % 400 == 0; 	
	for (i = 1; i < month ; i++) {		
		day += daytab[leap][i];	
	}	
	return day;
} 
	
/************************************************************************/
/* set month, day from day of year */
/************************************************************************/
void month_day(int year, int yearday, int *pmonth, int *pday) 
{	
	int i, leap; 	
	leap = year % 4 == 0 && year % 100 != 0 || year % 400 == 0;	
	for (i = 1; yearday > daytab[leap][i]; i ++) {		
		yearday -= daytab[leap][i];	
	}	
	*pmonth = i;	
	*pday = yearday == 0 ? 1 : yearday;
}

uint32_t calculateTimeElapse(uint32_t startTick)
{
	uint32_t round_tick = 0x00;
    uint32_t us_value   = 0;
	uint32_t post_tick = 0;

    post_tick = platform_timer_us_tick();

    if (post_tick < startTick)
    {
        round_tick = 0xFFFFFFFF - startTick;
        round_tick += post_tick;
        us_value = round_tick;
    }else{
        us_value = post_tick - startTick;
    }

    return us_value;
}

tm_date unixTimestamp_to_localTime(uint64_t time)
{
    time_t t_unix;
	struct tm *utcTime;
    tm_date local_date;

	t_unix = time + LOCAL_TIME_ZONE * 3600;
	utcTime = localtime(&t_unix);
	//MALOGD("UTC %d-%d-%d %d:%d:%d", utcTime->tm_year, utcTime->tm_mon, utcTime->tm_mday, utcTime->tm_hour, utcTime->tm_min, utcTime->tm_sec);
	local_date.year = utcTime->tm_year - 100 + 2000;
	local_date.mon = utcTime->tm_mon + 1;
	local_date.mday = utcTime->tm_mday;
	local_date.hour =  utcTime->tm_hour;
	local_date.min = utcTime->tm_min;
	local_date.sec = utcTime->tm_sec;

	return local_date;  
}

time_t localTime_to_unixTimestamp(tm_date local_date)
{
    time_t t_unix;
	struct tm utcTime;

	utcTime.tm_year = local_date.year - 2000 + 100;
	utcTime.tm_mon = local_date.mon - 1;
	utcTime.tm_mday = local_date.mday;
	utcTime.tm_hour = local_date.hour;
	utcTime.tm_min = local_date.min;
	utcTime.tm_sec = local_date.sec;
	//MALOGD("UTC %d-%d-%d %d:%d:%d", utcTime.tm_year, utcTime.tm_mon, utcTime.tm_mday, utcTime.tm_hour, utcTime.tm_min, utcTime.tm_sec);
	t_unix = mktime(&utcTime);

	return (t_unix - LOCAL_TIME_ZONE * 3600);
	
}

int8_t array_cmp(const int8_t *arrayA, const int8_t *arrayB, int16_t len)
{
	int16_t i;

	for(i = 0; i < len; i++) {
		if(arrayA[i] != arrayB[i]) {
			return 1;
		}
	}

	return 0;
}


