#ifndef GLOBAL_VAR_H
#define GLOBAL_VAR_H

#include "type_def.h"
#include "auto_define.h"
#include "system.h"
#include "hardware_bsp.h"
#include "malog.h"
#include "mafp_sensor.h"
#include "lock_task.h"
#include "kg_utils.h"
#include "Power.h"
#include "platform.h"
#include "projectConfig.h"

#define COMPILE_DATE  __DATE__" "__TIME__

#define DATA_VFY_KEY         0xA55A

typedef enum
{
	STATE_IDLE,
	STATE_UPLOAD,
	STATE_DOWNLOAD,
	STATE_ENROLL,
	STATE_MATCH,
	STATE_DELETE,
	STATE_FACTORY_TEST,
}_FsmState;

typedef enum  
{
    BT_CLOSE,
    BT_ADV,
    BT_CONNECTED,
}bt_status_t;

typedef enum {
	TYPE_BT_PACKAGE = 0x00,
	TYPE_UART_PACKAGE,
}ptclPackType;

typedef struct {
	uint8_t implApp_mode;
	uint8_t key_process;
	uint8_t hasfp;
	uint8_t uart_process;
	bt_status_t bt_status;
	uint16_t bt_connect_period;
	uint8_t is_low_battery;
	uint8_t is_sys_boot;
	boardContext* bsp_ctx;
	periphConfig* bsp_conf;
}projectContext;


extern volatile _FsmState g_fsm_state;
extern _EnrollTag Enroll_Tag;
extern _MatchTag  Match_Tag;

extern u8 g_factory_test;
extern u8 g_BT_test_result;
extern ptclPackType g_packet_type;

extern volatile bt_status_t g_bt_status;

extern application_impl_func app_impl;
extern projectContext project_ctx;; 
extern boardContext bsp_ctx;
extern periphConfig g_periph_config;

#endif
