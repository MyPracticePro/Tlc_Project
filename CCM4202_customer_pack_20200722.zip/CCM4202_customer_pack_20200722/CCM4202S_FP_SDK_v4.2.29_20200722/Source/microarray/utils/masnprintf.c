/*
 * snprintf.c
 *
 *  Created on: Jan 17, 2017
 *      Author: zhl
 */

//#include "config.h"
//#include "malib.h"
//#include "mastring.h"
//#include "masnprintf.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#ifndef PLATFORM_WATCHTRUST
#include <stdarg.h>
#endif

static int get_int_len(int value) {
    int valueLen = 0, isNag = 0;
    if (value < 0) {
        value *= -1;
        isNag = 1;
        valueLen++;
    }
    while (value != 0 || 0 == valueLen) {
        valueLen++;
        value /= 10;
    }
    return valueLen;
}

static void ma_snprintf_int(char* dest, int len, const char* src, int value)
{
    char valueStr[100] = {'\0'};
    int valueLen = 0;
    int isNag = 0;
    if (value < 0)
    {
        value *= -1;
        isNag = 1;
    }
    while (value != 0 || 0 == valueLen)
    {
        valueStr[valueLen++] = 48 + value % 10;
        value /= 10;
    }
    if (isNag)
    {
        valueStr[valueLen++] = '-';
    }

    int i=0, j = 0;
    for (; j < len; ++i, ++j)
    {
        if ('%' == src[i] && 'd' == src[i + 1])
        {
            ++i;
            while (valueLen != 0 && j < len)
            {
                dest[j] = valueStr[--valueLen];
                if(valueLen > 0) j++;
            }
        } else {
            dest[j] = src[i];
        }
    }
}

void ma_snprintf(char *buf, int len, const char *fmt, ...) {
#ifndef PLATFORM_WATCHTRUST
    va_list ap;
    static char des[2052];
    int i = 0, d, int_len = 0;
    char c, *s;
    (void)len;

//    LOGD("start\n");

    if(len > 2048) {
        //LOGE("pre length is not enough");
        memset(buf, 0, len);
        return;
    }
    memset(des, 0, sizeof(des));
    va_start(ap, fmt);
    while (*fmt)
    {
        if('%' == *fmt) {
            switch(*(++fmt)) {
                case 's':
                    s = va_arg(ap, char *);
                    //ma_strncat(des, s, strlen(s));
                    strncat(des, s, strlen(s));
                    break;
                case 'd':
                    d = va_arg(ap, int);
                    int_len = get_int_len(d);
                    ma_snprintf_int(des+strlen(des), int_len, "%d", d);
                    break;
                case 'c':
                    c = (char) va_arg(ap, int);
                    strncat(des, &c, 1);
                    break;
                default:
                    c = *fmt;
                    strncat(des, &c, 1);
                    break;
            }
        } else {
            c = *fmt;
            strncat(des, &c, 1);
        }
        ++fmt;
    }
    des[strlen(des)] = '\0';

    memcpy(buf, des, strlen(des));
    va_end(ap);

//    LOGD("end\n");
#endif
}

static int (*orig_printf)(const char *format, ...) = NULL;
static int (*orig_sprintf)(char * str,const char *format, ...) = NULL;
static int (*orig_snprintf)(char * str,size_t size,const char *format, ...) = NULL;
int new_vsprintf(char *str, const char *vsformat, va_list vsarg, ...);
int vsprintf(char *str, const char * format, va_list arg)
{
	new_vsprintf(str,format,arg);
	return 0;
}

int new_vsprintf(char *str, const char *vsformat, va_list vsarg, ...)
{
	int i=0;
	int out_int;
	int *out_n;
	int len;
	unsigned int out_hex_int;
	unsigned int out_unsigned_int;
	char out_char=0;
	char *out_string=NULL;
	char int_to_string[20];
	char final_string[1024];
	double out_f;
	double out_e;
	//
	double out_a;
	unsigned int out_o;
	unsigned int out_p;
	int k=0;
	//int circle=0;
	//int number;
	char number_array[6];
	//int loop;
	//
	//orig_fprintf=(int (*)(FILE *file,const char *format, ...))dlsym(RTLD_NEXT,"fprintf");
	orig_printf=printf;//(int (*)(const char *format, ...))dlsym(RTLD_NEXT,"printf");
	orig_sprintf=sprintf;//(int (*)(char *str,const char *format, ...))dlsym(RTLD_NEXT,"sprintf");
	int count=0;

	for (i=0;vsformat[i]!='\0';)
	{
		if (vsformat[i]=='%')
		{
			//
			i=i+1;
			while (vsformat[i]=='0'||vsformat[i]=='1'||vsformat[i]=='2'||vsformat[i]=='3'||vsformat[i]=='4'||vsformat[i]=='5'||vsformat[i]=='6'||vsformat[i]=='7'||vsformat[i]=='8'||vsformat[i]=='9'||vsformat[i]=='$'||vsformat[i]=='*'||vsformat[i]=='.')
			//while (!isalpha(vsformat[i]))
			{
				if (vsformat[i]=='%')
				{
					break;
				}
				else
				{
					number_array[k++]=vsformat[i];
					i=i+1;
				}
			}
			//number=findNumber(number_array);
			//
			if (vsformat[i]=='d')
			{
				out_int=va_arg(vsarg, int);
				(orig_sprintf)(int_to_string,"%d",out_int);
				count=count+strlen(int_to_string);
				strcat(final_string,int_to_string);
				i=i+1;			//
			}
			else if (vsformat[i]=='i')
			{
				out_int=va_arg(vsarg, int);
				(orig_sprintf)(int_to_string,"%i",out_int);
				count=count+strlen(int_to_string);
				strcat(final_string,int_to_string);
				i=i+1;			//
			}
			else if (vsformat[i]=='s')
			{
				out_string=va_arg(vsarg, char*);
				count=count+strlen(out_string);
				strcat(final_string,out_string);
				i=i+1;			//
			}
			else if (vsformat[i]=='c')
			{
				out_char=va_arg(vsarg, int);
				count++;
				len=strlen(final_string);
				final_string[len]=out_char;
				i=i+1;			//
			}
			else if (vsformat[i]=='x')
			{
				out_hex_int=va_arg(vsarg, int);
				(orig_sprintf)(int_to_string,"%x",out_hex_int);
				count=count+strlen(int_to_string);
				strcat(final_string,int_to_string);
				i=i+1;			//
			}
			else if (vsformat[i]=='X')
			{
				out_hex_int=va_arg(vsarg, int);
				(orig_sprintf)(int_to_string,"%X",out_hex_int);
				count=count+strlen(int_to_string);
				strcat(final_string,int_to_string);
				i=i+1;
			}
			else if (vsformat[i]=='f')
			{
				out_f=va_arg(vsarg,double);
				(orig_sprintf)(int_to_string,"%f",out_f);
				count=count+strlen(int_to_string);
				strcat(final_string,int_to_string);
				i=i+1;			//
			}
			else if (vsformat[i]=='u')
			{
				out_unsigned_int=va_arg(vsarg, int);
				(orig_sprintf)(int_to_string,"%u",out_unsigned_int);
				count=count+strlen(int_to_string);
				strcat(final_string,int_to_string);
				i=i+1;			//
			}
			//new
			else if (vsformat[i]=='h')
			{
				if (vsformat[i+1]=='n')
				{
					out_n=(int *)va_arg(vsarg,int*);
					//*out_n=count;
					i=i+2;
				}
				else
				{
					count++;
					(orig_printf)("%c",vsformat[i]);
					i=i+1;
				}
			}
			else if (vsformat[i]=='e')
			{
				out_e=va_arg(vsarg,double);
				(orig_sprintf)(int_to_string,"%e",out_e);
				count=count+strlen(int_to_string);
				(orig_printf)("%e",out_e);
				i=i+1;
			}
			else if (vsformat[i]=='o')
			{
				out_o=va_arg(vsarg, unsigned int);
				(orig_sprintf)(int_to_string,"%o",out_o);
				count=count+strlen(int_to_string);
				(orig_printf)("%o",out_o);
				i=i+1;
			}
			else if (vsformat[i]=='p')
			{
				out_p=va_arg(vsarg, unsigned int);
				(orig_sprintf)(int_to_string,"%p",out_p);
				count=count+strlen(int_to_string);
				(orig_printf)("%p",out_p);
				i=i+1;
			}
			else if (vsformat[i]=='a')
			{
				out_a=va_arg(vsarg,double);
				(orig_sprintf)(int_to_string,"%a",out_a);
				count=count+strlen(int_to_string);
				(orig_printf)("%a",out_a);
				i=i+1;
			}
			//new
			else if (vsformat[i]=='n')
			{
				out_n=(int *)va_arg(vsarg,int*);
				//*out_n=count;					//uncomment this for test1 and test2
				i=i+1;
			}
			else if (vsformat[i]=='%')
			{
				count++;
				len=strlen(final_string);
				final_string[len]=vsformat[i];
				i=i+1;
			}
			else
			{
				count++;
				i++;
			}
		}
		else
		{
			count++;
			len=strlen(final_string);
			final_string[len]=vsformat[i];
			i++;
		}
	}
	(orig_sprintf)(str,"%s",final_string);

	return 0;
}
