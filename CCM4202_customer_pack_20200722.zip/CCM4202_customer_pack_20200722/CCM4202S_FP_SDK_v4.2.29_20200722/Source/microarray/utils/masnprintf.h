
#ifndef __MA_SNPRINTF_H__
#define __MA_SNPRINTF_H__

void ma_snprintf(char *des, int len, const char *fmt, ...);


#endif /*__MA_SNPRINTF_H__*/
