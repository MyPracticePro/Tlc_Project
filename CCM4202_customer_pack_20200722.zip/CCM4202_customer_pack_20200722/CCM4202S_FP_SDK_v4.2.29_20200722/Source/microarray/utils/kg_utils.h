#ifndef KG_UTILS_H_
#define KG_UTILS_H_

#include "time.h"
#include "type_def.h"

#define LOCAL_TIME_ZONE          8

#define ENUM_TO_STR(x) case x: return #x;

typedef struct
{
    int   ms;
    int   sec;
    int   min;
    int   hour;
    int   mday;
    int   mon;
    int   year;
} tm_date;

extern uint32_t calculateTimeElapse(uint32_t startTick);
extern tm_date unixTimestamp_to_localTime(uint64_t time);
extern time_t localTime_to_unixTimestamp(tm_date local_date);
extern int8_t array_cmp(const int8_t *arrayA, const int8_t *arrayB, int16_t len);
extern int day_of_year(int year, int month, int day);
extern void month_day(int year, int yearday, int *pmonth, int *pday);

#endif


