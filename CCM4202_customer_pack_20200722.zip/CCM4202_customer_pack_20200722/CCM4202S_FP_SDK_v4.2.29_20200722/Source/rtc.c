// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : rtc_demo.c
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "rtc_drv.h"
#include "common.h"
//#include "iccemv.h"
#include "debug.h"
#include "delay.h"
#include "cpm_reg.h"

void RTC_Demo(void)
{
	tm time = {10, 10, 50, 50};
	
	RTC_Init(1);
//	RTC_Init(INTERNAL_CLK_SEL);
	
	DelayMS(1000);

	RTC_SetTime(time);
	time.second = 20;
	RTC_SetAlarm(time, SECOND_ALARM);
	DelayMS(1000);//������ʱ�䣬�������϶�ȡ����Ҫ��ʱһ��ʱ��
	while(1)
	{
		printf("g_rtc_int_sta = 0x%08x\n", g_rtc_int_sta);
		if (g_rtc_int_sta&Ala_intf)
		{
			g_rtc_int_sta &= ~Ala_intf;
			printf("alarm interrupt\n");
		}
		RTC_GetTime(&time);
		printf("time : D-%d [%d:%d:%d]\n", time.day, time.hour, time.minute, time.second);
		DelayMS(1000);
	}
}

