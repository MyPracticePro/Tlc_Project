#include "sys.h"
#include "debug.h"
#include "type.h"
#include "gpio.h"
#include "ClockAndPower.h"
#include "Timer.h"
#include "Flash.h"
#include "cache.h"
#include "ble_demo.h"
#include "rtc_drv.h"
#include "cpm_reg.h"
#include "trng_drv.h"
#include "pwm_drv.h"
#include "i2c_drv.h"
#include "c0_drv.h"
#include "ccm_mem.h"
#include "c0_drv.h"
#include "tc_reg.h"
#include "delay.h"
#include "lock_task.h"
#include "hardware_bsp.h"
#include "reboot_demo.h"

void WDT_FeedDog(void);
void CPM_VCC5V_Bypass(void);

int main()
{
	Sys_Init();
	CPM_VCC5V_Bypass();
	clockInit();
	
	I2C_Config_Gpio_Reboot(I2C_SDA, GPIO_INPUT);
	if (I2C_Read_Gpio_Data_Reboot(I2C_SDA) == Bit_SET)//L level
	{
		Reboot_Demo();
	}
	DCACHE_Init(cacheOff, cacheThrough, cacheOff, cacheOff);
	ICACHE_Init(cacheOff, cacheThrough, cacheOff, cacheOff);
	
	RTC_Init(EXTERNAL_CLK_SEL);	
	oslock_task_create(NULL);
	BSP_initialize();
	while(1)
	{
		oslock_task(NULL);
		WDT_FeedDog();
	}
	

}	

