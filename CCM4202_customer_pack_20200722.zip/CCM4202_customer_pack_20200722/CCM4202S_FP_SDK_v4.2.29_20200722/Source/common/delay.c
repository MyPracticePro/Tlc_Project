
#include "sys.h"
#include "delay.h"

/*******************************************************************************
* Function Name  : DelayMS
* Description    : Delay n MS
* Input          : delaymS��Delay Parame
* Output         : None
* Return         : None
*******************************************************************************/
void DelayMS(UINT32 delaymS)
{
	UINT32 counter=0;
	UINT32 k;
	UINT32 counter_ms = (g_sys_clk/1000000)*27;
	
	for(k=0; k<delaymS; k++)
	{
		for (counter=0; counter<counter_ms; counter++);
	}
	
//	if (g_sys_clk == EFLASH_SYS_CLK_60M)
//	{
//		for(k=0; k<delaymS; k++)
//		{
//			for (counter=0; counter<1668; counter++);
//		}
//	}
}

/*******************************************************************************
* Function Name  : delay
* Description    : Delay n nop
* Input          : time: n npo
* Output         : None
* Return         : None
*******************************************************************************/
void delay(vu32 time)
{
	while(time--){
		asm("nop");
	}
}

