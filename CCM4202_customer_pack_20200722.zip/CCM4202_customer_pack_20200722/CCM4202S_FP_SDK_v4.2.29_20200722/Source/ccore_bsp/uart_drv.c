// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : uart_drv.c
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#include "debug.h"
//#include "cpm_drv.h"
#include "iomacros.h"
#include "uart_drv.h"
#include "uart_reg.h"
#include "stddef.h"
#include "stdarg.h"
#include "stdlib.h"
#include "syscfg.h"

#define UART_RECV_MAX_LEN  512

typedef struct _uart_recv_buf
{
	UINT16 rp;//read pointer
	UINT16 wp;//write pointer
	UINT8  dat[UART_RECV_MAX_LEN];//buffer
}UartRecvBufStruct;

static UartRecvBufStruct g_Uart1RecvBufStruct = {0, 0};//uart1 buffer
static UartRecvBufStruct g_Uart2RecvBufStruct = {0, 0};//uart2 buffer
static UartRecvBufStruct g_Uart3RecvBufStruct = {0, 0};//uart3 buffer

UART_InitTypeDef  UART_BT_InitStruct;

/*******************************************************************************
* Function Name  : UART_ISR
* Description    : UART�жϴ���
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
static void UART_ISR(UART_TypeDef *UARTx, UartRecvBufStruct *UARTxRecvBufStruct)
{
	if((UARTx->SCISR1 & SCISR1_RDRF_MASK) == SCISR1_RDRF_MASK)
	{
		UARTxRecvBufStruct->dat[UARTxRecvBufStruct->wp] = UARTx->SCIDRL;
		UARTxRecvBufStruct->wp += 1;
		if (UARTxRecvBufStruct->wp >= UART_RECV_MAX_LEN)
			UARTxRecvBufStruct->wp = 0;
	}
}

/*******************************************************************************
* Function Name  : UART3_ISR
* Description    : UART2�жϴ���
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void SCI1_IRQHandler(void)
{
	UART_ISR(SCI1_REG_STR, &g_Uart1RecvBufStruct);
}


#if 0
/*******************************************************************************
* Function Name  : UART4_ISR
* Description    : UART4�жϴ���
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void SCI2_IRQHandler(void)
{
	UART_ISR(SCI2, &g_Uart2RecvBufStruct);
}
#endif


/*******************************************************************************
* Function Name  : UART2_ISR
* Description    : UART2�жϴ���
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void SCI3_IRQHandler(void)
{
	UART_ISR(SCI3_REG_STR, &g_Uart3RecvBufStruct);
}


/*******************************************************************************
* Function Name  : UART_Init
* Description    : UART��ʼ��
* Input          : - UARTx: ȡֵSCI2 or SCI_BT
*                  - UART_InitStruct��UARTx  initialization parameter structure Poniter
*
* Output         : None
* Return         : None
******************************************************************************/
void UART_Init(UART_TypeDef *UARTx, UART_InitTypeDef *UART_InitStruct)
{
	UINT16 bandrate_I;
	UINT8 bandrate_F;
	UINT8 bandrate_h;
	UINT8 bandrate_l;


	if (SCI1_REG_STR == UARTx)
	{
		g_Uart1RecvBufStruct.wp = 0;
		g_Uart1RecvBufStruct.rp = 0;
		if (UART_InitStruct->UART_Mode == UART_INT_MODE)
		{
			NVIC_Init(3, 3, SCI1_IRQn, 2);
		}
	}
	else 	if (SCI2_REG_STR == UARTx)
	{
		g_Uart2RecvBufStruct.wp = 0;
		g_Uart2RecvBufStruct.rp = 0;
		if (UART_InitStruct->UART_Mode == UART_INT_MODE)
		{
			NVIC_Init(3, 3, SCI2_IRQn, 2);
		}
	}
	else
	{
		g_Uart3RecvBufStruct.wp = 0;
		g_Uart3RecvBufStruct.rp = 0;
		if (UART_InitStruct->UART_Mode == UART_INT_MODE)
		{
			NVIC_Init(3, 3, SCI3_IRQn, 2);
		}
	}

	bandrate_I = ((UINT16)(g_ips_clk*4/UART_InitStruct->UART_BaudRate))>>6;
	bandrate_F = (((UINT16)(g_ips_clk*8/UART_InitStruct->UART_BaudRate)+1)/2)&0x003f;
	bandrate_h = (UINT8)((bandrate_I>>8)&0x00ff);
	bandrate_l = (UINT8)(bandrate_I&0x00ff);

	UARTx->SCIBRDF = bandrate_F;		//Write float before Interger
	UARTx->SCIBDH = bandrate_h;
	UARTx->SCIBDL = bandrate_l;

	UARTx->SCICR1 = 0x00;
	UARTx->SCICR1 |= UART_InitStruct->UART_FrameLength; //11 bit frame
	if (UART_InitStruct->UART_Parity == UART_PARITY_NONE)
	{
		UARTx->SCICR1 |= ParityDIS;	//parity disable
	}
	else
	{
		UARTx->SCICR1 |= ParityEN;	//parity disable
		UARTx->SCICR1 |= UART_InitStruct->UART_Parity;//odd parity
	}


	UARTx->SCICR2 = 0;

	if (UART_InitStruct->UART_Mode == UART_INT_MODE)
	{
		//Setup SCI interrupt
		UARTx->SCICR2 |= SCICR2_RIE_MASK|SCICR2_RE_MASK;
	}
}

/*******************************************************************************
* Function Name  : UART_ByteRecieved
* Description    : UART���յ�����
* Input          : - UARTx:ȡֵSCI1�� SCI2
*
* Output         : - None
*
* Return         : - TRUE:���յ�����
*                  - FALSE:û�н��յ�����
******************************************************************************/
INT8 UART_ByteRecieved(UART_TypeDef *UARTx)
{
	UartRecvBufStruct *UARTxRecvBufStruct;
	if (UARTx == SCI1_REG_STR)
	{
		 UARTxRecvBufStruct = &g_Uart1RecvBufStruct;
	}
	else
  {
			if (UARTx == SCI2_REG_STR)
	    {
		     UARTxRecvBufStruct = &g_Uart2RecvBufStruct;
	    }
			else
      {
		      UARTxRecvBufStruct = &g_Uart3RecvBufStruct;
      }
	}

	if (UARTxRecvBufStruct->wp != UARTxRecvBufStruct->rp)
	{
		return TRUE;
	}
	return FALSE;
}
/*******************************************************************************
* Function Name  : UART_RecvByte
* Description    : UART����һ���ֽ�
* Input          : - UARTx:ȡֵSCI2 or SCI1
*
*
* Output         : - dat���������ݻ���
*
* Return         : - TRUE:���յ�����
*                  - FALSE:û�н��յ�����
******************************************************************************/
INT8 UART_RecvByte(UART_TypeDef *UARTx, UINT8 *dat)
{
	UartRecvBufStruct *UARTxRecvBufStruct;
	if (UARTx == SCI1_REG_STR)
	{
		 UARTxRecvBufStruct = &g_Uart1RecvBufStruct;
	}
	else
  {
			if (UARTx == SCI2_REG_STR)
	    {
		     UARTxRecvBufStruct = &g_Uart2RecvBufStruct;
	    }
			else
      {
		      UARTxRecvBufStruct = &g_Uart3RecvBufStruct;
      }
	}
	if (UARTxRecvBufStruct->wp != UARTxRecvBufStruct->rp)
	{
		*dat = UARTxRecvBufStruct->dat[UARTxRecvBufStruct->rp];
		UARTxRecvBufStruct->rp += 1;
		if (UARTxRecvBufStruct->rp >= UART_RECV_MAX_LEN)
			UARTxRecvBufStruct->rp = 0;
		return TRUE;
	}
	return FALSE;
}

/*******************************************************************************
* Function Name  : UART_SendByte
* Description    : UART����һ���ֽ�
* Input          : - UARTx: ȡֵSCI2 or SCI_BT
*                  - SendByte�����͵��ֽ�
*
* Output         : None
* Return         : None
******************************************************************************/
void UART_SendByte(UART_TypeDef *UARTx, UINT8 SendByte)
{

	UARTx->SCICR2 |= SCICR2_TE_MASK;
	while((UARTx->SCISR1 & SCISR1_TDRE_MASK)==0);
	UARTx->SCIDRL = SendByte&0xff;
	while((UARTx->SCISR1 & SCISR1_TC_MASK)==0);
	UARTx->SCICR2 &= ~SCICR2_TE_MASK;
}


/*******************************************************************************
* Function Name  : UART_SendData
* Description    : UART���Ͷ���ֽ�
* Input          : - UARTx:ȡֵSCI2 or SCI_BT
*                  - send���������ݻ���
*                  - len�����͵����ݳ���
*
* Output         : None
* Return         : None
******************************************************************************/
void UART_SendData(UART_TypeDef *UARTx, UINT8 *send, UINT16 len)
{
	UINT16 i = 0;

	UARTx->SCICR2 |= SCICR2_TE_MASK;
	for ( ; i < len; i++)
	{
		while((UARTx->SCISR1 & SCISR1_TDRE_MASK)==0);
		UARTx->SCIDRL = send[i]&0xff;
		while((UARTx->SCISR1 & SCISR1_TC_MASK)==0);
	}
	UARTx->SCICR2 &= ~SCICR2_TE_MASK;
}


/*******************************************************************************
* Function Name  : UART_ConfigGpio
* Description    : UART���ó�GPIO��;
* Input          : - UARTx: ȡֵSCI2 or SCI_BT
*                  - UART_Pin��Ӧ��PIN�ţ�ȡֵUART_TX��UART_RX
*                  - UART_Dir������GPIO����   GPIO_OUTPUT�����  GPIO_INPUT������
*
* Output         : None
* Return         : None
******************************************************************************/
void UART_ConfigGpio(UART_TypeDef *UARTx, UART_PINx UART_Pin, UINT8 UART_Dir)
{
	UARTx->SCICR1 = 0x80;

	if (UART_Dir == GPIO_OUTPUT)
	{
		UARTx->SCIDDR |= (1<<UART_Pin);//output
	}
	else if (UART_Dir == GPIO_INPUT)
	{
		UARTx->SCIDDR &= (~(1<<UART_Pin));//input
	}

}

/*******************************************************************************
* Function Name  : UART_ReadGpioData
* Description    : ��ȡUART_Pin��Ӧ���ŵĵ�ƽ
* Input          : - UARTx: ȡֵSCI2 or SCI_BT
*                  - UART_Pin��Ӧ��PIN�ţ�ȡֵUART_TX��UART_RX
*
* Output         : None
* Return         : Bit_SET:�ߵ�ƽ  Bit_RESET���͵�ƽ
******************************************************************************/
INT8 UART_ReadGpioData(UART_TypeDef *UARTx, UART_PINx UART_Pin)
{
	INT8 bitstatus = 0x00;

	bitstatus = UARTx->SCIPORT;

	if (bitstatus &(Bit_SET<<UART_Pin))
		bitstatus = Bit_SET;
	else
		bitstatus = Bit_RESET;

	return bitstatus;
}

/*******************************************************************************
* Function Name  : UART_WriteGpioData
* Description    : ����UART_Pin��Ӧ���ŵĵ�ƽ
* Input          : - UARTx: ȡֵSCI2 or SCI_BT
*                  - UART_Pin��Ӧ��PIN�ţ�ȡֵUART_TX��UART_RX
*                  - bitVal�����õĵ�ƽ��Bit_SET������Ϊ�ߵ�ƽ  Bit_RESET������Ϊ�͵�ƽ
*
* Output         : None
* Return         : None
******************************************************************************/
void UART_WriteGpioData(UART_TypeDef *UARTx, UART_PINx UART_Pin, UINT8 bitVal)
{
	if (bitVal == Bit_SET)
		UARTx->SCIPORT |= (Bit_SET<<UART_Pin);
	else
		UARTx->SCIPORT &= (~(Bit_SET<<UART_Pin));
}



