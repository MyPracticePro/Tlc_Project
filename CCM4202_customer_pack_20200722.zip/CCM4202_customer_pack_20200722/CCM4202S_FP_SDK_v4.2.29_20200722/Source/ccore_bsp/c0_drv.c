// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : c0_drv.c
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "c0_drv.h"
#include "string.h"
#include "eport.h"

/*******************************************************************************
* Function Name  : C0_load_bin_to_mem
* Description    : ����bin��C0�ڴ�
* Input          : - bin_data: bin����
*                  - size����С
*
* Output         : None
* Return         : None
******************************************************************************/
void C0_load_bin_to_mem(UINT8 * bin_data, int size)
{
//  while(size--)
//    (*(volatile UINT8 *) (0x08100000 + size)) = *(bin_data+size);
	memcpy((void*)0x08100000, bin_data, size);
}

/*******************************************************************************
* Function Name  : C0_EPORT_ConfigGpio
* Description    : EPORT���ó�GPIO��;
* Input          :- GpioNo: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*                  - GpioDir������GPIO����   GPIO_OUTPUT�����  GPIO_INPUT������
*
* Output         : None
* Return         : None
******************************************************************************/
void C0_EPORT_ConfigGpio(EPORT_PINx GpioNo, UINT8 GpioDir)
{
	if (GpioNo > EPORT_PIN15)
		return;
	if(GpioDir == GPIO_INPUT)
	{
		if(GpioNo < EPORT_PIN8)
		{
			C0_EPORT0->EPDDR &= ~(1<<GpioNo);
		}
		else
		{
			C0_EPORT1->EPDDR &= ~(1<<(GpioNo-EPORT_PIN8));
		}
	}
	else
	{
		if(GpioNo < EPORT_PIN8)
		{
			C0_EPORT0->EPDDR |= (1<<GpioNo);
		}
		else
		{
			C0_EPORT1->EPDDR |= (1<<(GpioNo-EPORT_PIN8));
		}
	}
}

/*******************************************************************************
* Function Name  : C0_EPORT_WriteGpioData
* Description    : ����EPORT_PINx��Ӧ���ŵĵ�ƽ
* Input          : - GpioNo: where x can be 0~15 to select the EPORT peripheral.
*                  - bitVal�����õĵ�ƽ��Bit_SET������Ϊ�ߵ�ƽ  Bit_RESET������Ϊ�͵�ƽ
*
* Output         : None
* Return         : 0: ���óɹ�    other������ʧ��
******************************************************************************/
void C0_EPORT_WriteGpioData(EPORT_PINx GpioNo, UINT8 bitVal)
{
	
	if (GpioNo > EPORT_PIN15)
		return;
	if(GpioNo < EPORT_PIN8)
	{
		C0_EPORT0->EPDDR |= (1<<GpioNo);
		if (bitVal == Bit_SET)
		{
			C0_EPORT0->EPDR |= (Bit_SET<<GpioNo);
		}
		else
		{
			C0_EPORT0->EPDR &= ~(Bit_SET<<GpioNo);
		}
	}
	else
	{
		C0_EPORT1->EPDDR |= (1<<(GpioNo - EPORT_PIN8));
		if (bitVal == Bit_SET)
		{
				C0_EPORT1->EPDR |= (Bit_SET<<(GpioNo - EPORT_PIN8));
		}
		else
		{
			C0_EPORT1->EPDR &= ~(Bit_SET<<(GpioNo - EPORT_PIN8));
		}
	}
}

/*******************************************************************************
* Function Name  : C0_EPORT_ReadGpioData
* Description    : ��ȡEPORT_PINx��Ӧ���ŵĵ�ƽ
* Input          : - EPORT_PINx: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*
* Output         : None
* Return         : Bit_SET:�ߵ�ƽ  Bit_RESET���͵�ƽ 
******************************************************************************/
INT8 C0_EPORT_ReadGpioData(EPORT_PINx GpioNo)
{
	INT8  bitstatus = 0x00;

	if (GpioNo > EPORT_PIN15)
		return -1;
	if(GpioNo < EPORT_PIN8)
	{
		bitstatus = C0_EPORT0->EPPDR;
		if (bitstatus&(Bit_SET<<GpioNo))
		{
			return Bit_SET;
		}
		else
		{
			return Bit_RESET;
		}

	}
	else
	{
		bitstatus = C0_EPORT0->EPPDR;
		if (bitstatus&(Bit_SET<<(GpioNo - EPORT_PIN8)))
		{
			return Bit_SET;
		}
		else
		{
			return Bit_RESET;
		}
	}

	
}
