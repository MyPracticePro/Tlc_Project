// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : c0_drv.h
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#ifndef __C0_DRV_H__
#define __C0_DRV_H__

#include "c0_reg.h"
#include "c0_memmap.h"
//#include "wdt_drv.h"
//#include "tc_drv.h"
#include "eport.h"
#include "tc_reg.h"


#define C0_CPM        ((C0_CPM_TypeDef *)(C0_CPM_BASE_ADDR))
#define C0_WDT		    ((WDT_TypeDef *)(C0_WDT_BASE_ADDR))
#define C0_TC				  ((TC_TypeDef *)C0_TC_BASE_ADDR)
#define C0_EPORT0     ((EPORT_TypeDef *)(C0_EPORT0_BASE_ADDR))
#define C0_EPORT1     ((EPORT_TypeDef *)(C0_EPORT1_BASE_ADDR))

/*******************************************************************************
* Function Name  : C0_load_bin_to_mem
* Description    : ����bin��C0�ڴ�
* Input          : - bin_data: bin����
*                  - size����С
*
* Output         : None
* Return         : None
******************************************************************************/
void C0_load_bin_to_mem(UINT8 * bin_data, int size);

/*******************************************************************************
* Function Name  : C0_EPORT_ConfigGpio
* Description    : EPORT���ó�GPIO��;
* Input          :- GpioNo: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*                  - GpioDir������GPIO����   GPIO_OUTPUT�����  GPIO_INPUT������
*
* Output         : None
* Return         : None
******************************************************************************/
void C0_EPORT_ConfigGpio(EPORT_PINx GpioNo, UINT8 GpioDir);

/*******************************************************************************
* Function Name  : C0_EPORT_WriteGpioData
* Description    : ����EPORT_PINx��Ӧ���ŵĵ�ƽ
* Input          : - GpioNo: where x can be 0~15 to select the EPORT peripheral.
*                  - bitVal�����õĵ�ƽ��Bit_SET������Ϊ�ߵ�ƽ  Bit_RESET������Ϊ�͵�ƽ
*
* Output         : None
* Return         : 0: ���óɹ�    other������ʧ��
******************************************************************************/
void C0_EPORT_WriteGpioData(EPORT_PINx GpioNo, UINT8 bitVal);

/*******************************************************************************
* Function Name  : C0_EPORT_ReadGpioData
* Description    : ��ȡEPORT_PINx��Ӧ���ŵĵ�ƽ
* Input          : - GpioNo: EPORT Pin��where x can be 0~15 to select the EPORT peripheral.
*
* Output         : None
* Return         : Bit_SET:�ߵ�ƽ  Bit_RESET���͵�ƽ 
******************************************************************************/
INT8 C0_EPORT_ReadGpioData(EPORT_PINx GpioNo);

#endif /* __C0_DRV_H__ */
