// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// File name    : cpm_drv.c
// Version      : V0.1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#include "debug.h"
#include "delay.h"
#include "cpm_drv.h"
#include "ccm_drv.h"
#include "iomacros.h"
#include "cache_drv.h"
#include "apdu_drv.h"
#include "ioctrl_drv.h"
//#include "test_demo.h"


/*******************************************************************************
* Function Name  : PCI_IRQHandler
* Description    : PCI���������ж�
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void PCI_IRQHandler(void)
{
	CPM->CPM_PADWKINTCR |= 0x1F; //clear wake up flag;
}

static void CPM_overwrite_test_mode(unsigned int ovwr_data)
{
	unsigned int tmp = CPM->CPM_VCCCTMR & 0x3fffffff;
	CPM->CPM_VCCCTMR = tmp;
	CPM->CPM_VCCCTMR = tmp | 0x40000000;
	CPM->CPM_VCCCTMR = tmp | 0x80000000;
	CPM->CPM_VCCCTMR = tmp | 0xc0000000;
	CPM->CPM_VCCCTMR |= ovwr_data;
	CPM->CPM_VCCCTMR &= 0x3fffffff;
}

/*******************************************************************************
* Function Name  : CPM_Sleep
* Description    : CPU����Sleepģʽ
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void CPM_Sleep(void)
{
	#if SUPPER_EDGE_WAKEUP
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc600000))|0x1c600000);  //low power mode,eport 0~4 sleep enable,supper edge wake up
	#else
		CPM->CPM_SLPCFGR &= (~0xdc600000);  //low power mode,eport 0~4 sleep disable,don't supper edge wake up
	#endif
	CPM->CPM_SLPCFGR2 &= ~(VDD_WK_SWOFF|VDD_PD_RETENT|CPM_IPS_SLPEN);
	
	IOCTRL->SWAP_CONTROL_REG |=(1<<2)|(1<<7);    //sdclk/sddat[0:3] swap enable
	
	CPM->CPM_MPDSLPCR = 0X0028DF13;
	
//	CPM->CPM_VCCCTMR = 0X40000000;
//	CPM->CPM_VCCCTMR = 0X80000000;
//	CPM->CPM_VCCCTMR = 0XC0000000;
//	CPM->CPM_VCCCTMR |= (0XC0000000|0X00060000);  //overwrite OSCL/OSCH STABLE TRIM
	CPM_overwrite_test_mode(0x01860000);	//overwrite OSCL STABLE/OSCH STABLE/VCC/CARDLDO TRIM.
	
	CPM->CPM_SLPCNTR = 0X00000080;
	CPM->CPM_WKPCNTR = 0X00000080;
	CPM->CPM_FILTCNTR = 0X00000040;
	
	CPM->CPM_OSCLSTIMER = 0X00000000;
	CPM->CPM_OSCHSTIMER = 0X001001FF;
	
	CPM->CPM_CARDTRIMR = (CPM->CPM_CARDTRIMR | (WKP_DFILT_GTE | WKP_DFILT_EN | WKP_AFILT_BYPASS)) &~ WKP_DFILT_BYPASS;//wake-up digit filter enable, analog filter bypass.
	
	rETIMCFG = (rETIMCFG & 0xFFFFFF0F)|(0X04 << 4); //limit peri_clk_en = 30us
	
//#ifdef TSI_DEMO
	CPM->CPM_PADWKINTCR = 0x000303FF; //wake up -pad/disable pad ss3(ss3 �� TSI_CH4����)/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
//#else
	//CPM->CPM_PADWKINTCR = 0x001313FF; //wake up -pad/pad ss3/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
//#endif

	NVIC_Init(3, 3, PCI_IRQn, 2);

	Sys_Standby();
}

/*******************************************************************************
* Function Name  : CPM_PowerOff_1
* Description    : CPU����PowerOff_1ģʽ
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void CPM_PowerOff_1(void)
{
	#if SUPPER_EDGE_WAKEUP
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40280000);  //Power OFF 1 mode,eport 0 sleep enable,supper edge wake up
	#else
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40000000);  //Power OFF 1 mode,eport 0 sleep disable,don't supper edge wake up
	#endif
	
	CPM->CPM_SLPCFGR2 = ((CPM->CPM_SLPCFGR2 &(~(VDD_WK_SWOFF|CPM_IPS_SLPEN)))|VDD_PD_RETENT);
	
	IOCTRL->SWAP_CONTROL_REG |=(1<<2)|(1<<7);   //sdclk/sddat[0:3] swap enable
	
	CPM->CPM_MPDSLPCR = 0X00001000;

//	CPM->CPM_VCCCTMR = 0X40000000;
//	CPM->CPM_VCCCTMR = 0X80000000;
//	CPM->CPM_VCCCTMR = 0XC0000000;
//	CPM->CPM_VCCCTMR |= (0XC0000000|0X00860000);  //overwrite OSCL/OSCH STABLE TRIM
	CPM_overwrite_test_mode(0x01860000);	//overwrite OSCL STABLE/OSCH STABLE/VCC/CARDLDO TRIM.

	CPM->CPM_SLPCNTR = 0x000f0080;
	CPM->CPM_WKPCNTR = 0X00000080;
	CPM->CPM_FILTCNTR = 0x00000040;
	
	CPM->CPM_OSCLSTIMER = 0X00000000;
	CPM->CPM_OSCHSTIMER = 0X001001FF;
	
	CPM->CPM_CARDTRIMR = (CPM->CPM_CARDTRIMR | (WKP_DFILT_GTE | WKP_DFILT_EN | WKP_AFILT_BYPASS)) &~ WKP_DFILT_BYPASS;//wake-up digit filter enable, analog filter bypass.
	
	rETIMCFG = (rETIMCFG & 0xFFFFFF0F)|(0X04 << 4); //limit peri_clk_en = 30us
	
#ifdef TSI_DEMO
	CPM->CPM_PADWKINTCR = 0x000303FF; //wake up -pad/disable pad ss3(ss3 �� TSI_CH4����)/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
#else
	CPM->CPM_PADWKINTCR = 0x001313FF; //wake up -pad/pad ss3/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
#endif	

	CPM->CPM_VCCGTRIMR |= (1<<12) | (1<<13);	//auto latch & auto latch clear.
	
	NVIC_Init(3, 3, PCI_IRQn, 2);
	
	Sys_Standby();
}

/*******************************************************************************
* Function Name  : CPM_PowerOff_1p5
* Description    : CPU����PowerOff_1p5ģʽ
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void CPM_PowerOff_1p5(void)
{
	#if SUPPER_EDGE_WAKEUP
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40280000);  //Power OFF 1.5 mode,eport 0 sleep enable,supper edge wake up
	#else
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40000000);  //Power OFF 1.5 mode,eport 0 sleep disable,don't supper edge wake up
	#endif
//	CPM->CPM_SLPCFGR2 = ((CPM->CPM_SLPCFGR2 &(~VDD_WK_SWOFF))|VDD_PD_RETENT);?!!
	CPM->CPM_SLPCFGR2 = ((CPM->CPM_SLPCFGR2 &(~(VDD_PD_RETENT|CPM_IPS_SLPEN)))|VDD_WK_SWOFF);
	
	IOCTRL->SWAP_CONTROL_REG |=(1<<2)|(1<<7);   //sdclk/sddat[0:3] swap enable
	
	CPM->CPM_MPDSLPCR = 0X00000000;
	
//	CPM->CPM_VCCCTMR = 0X40000000;
//	CPM->CPM_VCCCTMR = 0X80000000;
//	CPM->CPM_VCCCTMR = 0XC0000000;
//	CPM->CPM_VCCCTMR |= (0XC0000000|0X00860000);   //overwrite OSCL/OSCH STABLE TRIM
	CPM_overwrite_test_mode(0x01860000);	//overwrite OSCL STABLE/OSCH STABLE/VCC/CARDLDO TRIM.
	
	CPM->CPM_SLPCNTR = 0x000f0080;
	CPM->CPM_WKPCNTR = 0X00000080;
	CPM->CPM_FILTCNTR = 0x00000040;
	
	CPM->CPM_OSCLSTIMER = 0X00000000;
	CPM->CPM_OSCHSTIMER = 0X001001FF;
	
	CPM->CPM_CARDTRIMR = (CPM->CPM_CARDTRIMR | (WKP_DFILT_GTE | WKP_DFILT_EN | WKP_AFILT_BYPASS)) &~ WKP_DFILT_BYPASS;//wake-up digit filter enable, analog filter bypass.
	
	rETIMCFG = (rETIMCFG & 0xFFFFFF0F)|(0X04 << 4); //limit peri_clk_en = 30us
	
#ifdef TSI_DEMO
	CPM->CPM_PADWKINTCR = 0x000303FF; //wake up -pad/disable pad ss3(ss3 �� TSI_CH4����)/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
#else
	CPM->CPM_PADWKINTCR = 0x001313FF; //wake up -pad/pad ss3/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
#endif	
	
	CPM->CPM_VCCGTRIMR |= (1<<12) | (1<<13);	//auto latch & auto latch clear.
	
	NVIC_Init(3, 3, PCI_IRQn, 2);
	
	Sys_Standby();
}

/*******************************************************************************
* Function Name  : CPM_PowerOff_2
* Description    : CPU����power off 2ģʽ
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void CPM_PowerOff_2(void)
{
	CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0Xdc600000))|0x80000000);  //Power OFF 2 mode,eport 1~4 sleep disable,don't supper edge wake up
	
	CPM->CPM_SLPCFGR2 &= ~(VDD_WK_SWOFF|VDD_PD_RETENT|CPM_IPS_SLPEN);
	
	IOCTRL->SWAP_CONTROL_REG |=(1<<2)|(1<<7);          //sdclk/sddat[0:3] swap enable
	
	CPM->CPM_MPDSLPCR = 0X0028df13;
	
//	CPM->CPM_VCCCTMR = 0X40000000;
//	CPM->CPM_VCCCTMR = 0X80000000;
//	CPM->CPM_VCCCTMR = 0XC0000000;
//	CPM->CPM_VCCCTMR |= (0XC0000000|0X00060000);    //overwrite OSCL/OSCH STABLE TRIM
	CPM_overwrite_test_mode(0x01860000);	//overwrite OSCL STABLE/OSCH STABLE/VCC/CARDLDO TRIM.
	
	CPM->CPM_SLPCNTR = 0X00000080;
	CPM->CPM_WKPCNTR = 0X00000080;
	CPM->CPM_FILTCNTR = 0x00000040;
	
	CPM->CPM_OSCLSTIMER = 0X00000000;
	CPM->CPM_OSCHSTIMER = 0X001001FF;
	
	CPM->CPM_CARDTRIMR = (CPM->CPM_CARDTRIMR | (WKP_DFILT_GTE | WKP_DFILT_EN | WKP_AFILT_BYPASS)) &~ WKP_DFILT_BYPASS;//wake-up digit filter enable, analog filter bypass.
	
	rETIMCFG = (rETIMCFG & 0xFFFFFF0F)|(0X04 << 4); //limit peri_clk_en = 30us
	
	CPM->CPM_PADWKINTCR = 0x001313FF; //wake up -pad/pad ss3/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale

	NVIC_Init(3, 3, PCI_IRQn, 2);

	Sys_Standby();
}

#if 0
/*******************************************************************************
* Function Name  : CPM_Card_Sleep
* Description    : ��ģʽ��CPU����sleepģʽ
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void CPM_Card_Sleep(void)
{
	//Start bit Interrupt Enable Bit
	USI_SB_IT_EN;
	#if SUPPER_EDGE_WAKEUP
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc600000))|0x1c600000);  //low power mode,eport 1~4 sleep enable,supper edge wake up
	#else
		CPM->CPM_SLPCFGR &= (~0xdc600000);  //low power mode,eport 1~4 sleep disable,don't supper edge wake up
	#endif
	CPM->CPM_SLPCFGR2 &= ~(VDD_WK_SWOFF|VDD_PD_RETENT|CPM_IPS_SLPEN);
	
	IOCTRL->SWAP_CONTROL_REG |=(1<<2)|(1<<7);    //sdclk/sddat[0:3] swap enable
	
	CPM->CPM_MPDSLPCR = 0X0028DF13;
	
//	CPM->CPM_VCCCTMR = 0X40000000;
//	CPM->CPM_VCCCTMR = 0X80000000;
//	CPM->CPM_VCCCTMR = 0XC0000000;
//	CPM->CPM_VCCCTMR |= (0XC0000000|0X01070000);  //overwrite OSCL/OSCH STABLE TRIM
	CPM_overwrite_test_mode(0x01860000);	//overwrite OSCL STABLE/OSCH STABLE/VCC/CARDLDO TRIM.
	
	CPM->CPM_SLPCNTR = 0X00000080;
	CPM->CPM_WKPCNTR = 0X00000080;
	CPM->CPM_FILTCNTR = 0X00000040;
	
	CPM->CPM_OSCLSTIMER = 0X00000000;
	CPM->CPM_OSCHSTIMER = 0X001001FF;
	
	CPM->CPM_CARDTRIMR = (CPM->CPM_CARDTRIMR | (WKP_DFILT_GTE | WKP_DFILT_EN | WKP_AFILT_BYPASS)) &~ WKP_DFILT_BYPASS;//wake-up digit filter enable, analog filter bypass.
	
	rETIMCFG = (rETIMCFG & 0xFFFFFF0F)|(0X04 << 4); //limit peri_clk_en = 30us
	
	CPM->CPM_PADWKINTCR = 0x001313FF; //wake up -pad/pad ss33/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
	
	USI_SB_IT_DIS;
	
	NVIC_Init(3, 3, PCI_IRQn, 2);

	Sys_Standby();
}
#endif

#if 0
/*******************************************************************************
* Function Name  : CPM_Card_PowerOff1
* Description    : ��ģʽ��CPU����power off 1ģʽ
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void CPM_Card_PowerOff1(void)
{
	//Start bit Interrupt Enable Bit
	USI_SB_IT_EN;

	#if SUPPER_EDGE_WAKEUP
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40280000);  //Power OFF 1 mode,eport 1~4 sleep enable,supper edge wake up
	#else
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40000000);;  //Power OFF 1 mode,eport 1~4 sleep disable,don't supper edge wake up
	#endif
	
	CPM->CPM_SLPCFGR2 = ((CPM->CPM_SLPCFGR2 &(~(VDD_WK_SWOFF|CPM_IPS_SLPEN)))|VDD_PD_RETENT);
	
	IOCTRL->SWAP_CONTROL_REG |=(1<<2)|(1<<7);   //sdclk/sddat[0:3] swap enable
	
	CPM->CPM_MPDSLPCR = 0X00001000;

//	CPM->CPM_VCCCTMR = 0X40000000;
//	CPM->CPM_VCCCTMR = 0X80000000;
//	CPM->CPM_VCCCTMR = 0XC0000000;
//	CPM->CPM_VCCCTMR |= (0XC0000000|0X01870000);  //overwrite OSCL/OSCH STABLE TRIM
	CPM_overwrite_test_mode(0x01860000);	//overwrite OSCL STABLE/OSCH STABLE/VCC/CARDLDO TRIM.

	CPM->CPM_SLPCNTR = 0x000f0080;
	CPM->CPM_WKPCNTR = 0X00000080;
	CPM->CPM_FILTCNTR = 0x00000040;
	
	CPM->CPM_OSCLSTIMER = 0X00000000;
	CPM->CPM_OSCHSTIMER = 0X001001FF;
	
	CPM->CPM_CARDTRIMR = (CPM->CPM_CARDTRIMR | (WKP_DFILT_GTE | WKP_DFILT_EN | WKP_AFILT_BYPASS)) &~ WKP_DFILT_BYPASS;//wake-up digit filter enable, analog filter bypass.
	
	rETIMCFG = (rETIMCFG & 0xFFFFFF0F)|(0X04 << 4); //limit peri_clk_en = 30us
	

	CPM->CPM_PADWKINTCR = 0x001313FF; //wake up -pad/pad ss33/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
	
	CPM->CPM_VCCGTRIMR |= (1<<12) | (1<<13);	//auto latch & auto latch clear.

	USI_SB_IT_DIS;
	NVIC_Init(3, 3, PCI_IRQn, 2);

	Sys_Standby();
}


/*******************************************************************************
* Function Name  : CPM_Card_PowerOff1p5
* Description    : ��ģʽ��CPU����power off 1.5ģʽ
* Input          : None
*
* Output         : None
* Return         : None
******************************************************************************/
void CPM_Card_PowerOff1p5(void)
{
	//Start bit Interrupt Enable Bit
	USI_SB_IT_EN;
	
	#if SUPPER_EDGE_WAKEUP
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40280000);  //Power OFF 1.5 mode,eport 1~4 sleep enable,supper edge wake up
	#else
		CPM->CPM_SLPCFGR = ((CPM->CPM_SLPCFGR & (~0xdc680000))|0x40000000);;  //Power OFF 1.5 mode,eport 1~4 sleep disable,don't supper edge wake up
	#endif
//	CPM->CPM_SLPCFGR2 = ((CPM->CPM_SLPCFGR2 &(~VDD_WK_SWOFF))|VDD_PD_RETENT);?!!
	CPM->CPM_SLPCFGR2 = ((CPM->CPM_SLPCFGR2 &(~(VDD_PD_RETENT|CPM_IPS_SLPEN)))|VDD_WK_SWOFF);
	
	IOCTRL->SWAP_CONTROL_REG |=(1<<2)|(1<<7);   //sdclk/sddat[0:3] swap enable
	
	CPM->CPM_MPDSLPCR = 0X00000000;
	
//	CPM->CPM_VCCCTMR = 0X40000000;
//	CPM->CPM_VCCCTMR = 0X80000000;
//	CPM->CPM_VCCCTMR = 0XC0000000;
//	CPM->CPM_VCCCTMR |= (0XC0000000|0X01870000);   //overwrite OSCL/OSCH STABLE TRIM
	CPM_overwrite_test_mode(0x01860000);	//overwrite OSCL STABLE/OSCH STABLE/VCC/CARDLDO TRIM.
	
	CPM->CPM_SLPCNTR = 0x000f0080;
	CPM->CPM_WKPCNTR = 0X00000080;
	CPM->CPM_FILTCNTR = 0x00000040;
	
	CPM->CPM_OSCLSTIMER = 0X00000000;
	CPM->CPM_OSCHSTIMER = 0X001001FF;
	
	CPM->CPM_CARDTRIMR = (CPM->CPM_CARDTRIMR | (WKP_DFILT_GTE | WKP_DFILT_EN | WKP_AFILT_BYPASS)) &~ WKP_DFILT_BYPASS;//wake-up digit filter enable, analog filter bypass.
	
	rETIMCFG = (rETIMCFG & 0xFFFFFF0F)|(0X04 << 4); //limit peri_clk_en = 30us
#ifdef TSI_DEMO
	CPM->CPM_PADWKINTCR = 0x000303FF; //wake up -pad/pad ss33/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
#else
	CPM->CPM_PADWKINTCR = 0x001313FF; //wake up -pad/pad ss33/usbdet wake up enable/sddc/cpi_atimer/pci_det wake up disbale
#endif	
	
	CPM->CPM_VCCGTRIMR |= (1<<12) | (1<<13);	//auto latch & auto latch clear.

	USI_SB_IT_DIS;
	NVIC_Init(3, 3, PCI_IRQn, 2);

	Sys_Standby();
}	
#endif
/******************************************************************************
* Function Name  : cpm_set_sysclk_div
* Description    : ����OSC120M��Ƶ��Ϊϵͳʱ��
* Input          :  div�� the divide value of OSC120M_CLK
*
* Output         : None
* Return         : None
******************************************************************************/
#if 0
static void cpm_set_sysclk_div(UINT32 div)
{
	CPM->CPM_SCDIVR &= ~(SYS_DIV_MASK);
	CPM->CPM_SCDIVR |= (div << SYS_DIV_SHIFT);
	
	CPM->CPM_CDIVUPDR |= SYSDIV_UPD;
}
#endif
/*******************************************************************************
* Function Name  : CPM_VCC5V_Bypass
* Description    : �ر�VCC5V LDO
* Input          : None
*															
* Output         : None
* Return         : None
******************************************************************************/
void CPM_VCC5V_Bypass(void)
{
	CPM->CPM_VCCCTMR = 0X40000000;
	CPM->CPM_VCCCTMR = 0X80000000;
	CPM->CPM_VCCCTMR = 0XC0000000;
	CPM->CPM_VCCCTMR |= (0XC0000000|0X00800000);
	
	CPM->CPM_VCCGTRIMR &= ~(0x80000000UL);  //V33 switch disable
}

#if 0
/*******************************************************************************
* Function Name  : CPM_Vref_Trim
* Description    : trim�ο���ѹ
* Input          : trim_value��b'00 is 1.05V; b'01 is 1.1V; b'10 is 1.15V; b'11 is 1.21V��
*															
* Output         : None
* Return         : None
******************************************************************************/
void CPM_Vref_Trim(unsigned int trim_value)
{
	CPM->CPM_VCCCTMR = 0x40000000;
	CPM->CPM_VCCCTMR = 0x80000000;
	CPM->CPM_VCCCTMR = 0xc0000000;
	CPM->CPM_VCCCTMR |= 1<<23;
	if(CPM_VREF_TRIM_090 == trim_value)
	{
		CPM->CPM_VCCGTRIMR = (CPM->CPM_VCCGTRIMR)|(1<<15);
	}
	else
	{
		CPM->CPM_VCCGTRIMR = (CPM->CPM_VCCGTRIMR)& ~(1<<15);
		CPM->CPM_VCCGTRIMR = (CPM->CPM_VCCGTRIMR&(~0x0f))|(trim_value &0x0f);
	}
}
#endif

#if 0
/*******************************************************************************
* Function Name  : CPM_SysClkSelect
* Description    : ����sys_sel��Ƶ��Ϊϵͳʱ��
* Input          :  - sys_sel�� ϵͳ��ʱ��ԴSYSCLK_SEL_OSC8M, SYSCLK_SEL_OSC160, SYSCLK_SEL_USBPHY or SYSCLK_SEL_OSCEXT
*                   - div��ʱ��Ԥ��Ƶ(�û�����ϣ���ķ�Ƶ)
*
* Output         :  - None
* Return         :  - None
******************************************************************************/
void CPM_SysClkSelect(UINT32 sys_sel, UINT32 div)
{
	switch(sys_sel)
	{
		case SYSCLK_OSC8M:
			CPM->CPM_OCSR |= OSC8M_EN;
			while(OSC8M_STABLE != (CPM->CPM_OCSR & OSC8M_STABLE));
		
			CPM->CPM_CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM->CPM_CSWCFGR |= SYSCLK_SEL_OSC8M;
			while(CLKSEL_ST_OSC8M != (CPM->CPM_CSWCFGR & CLKSEL_ST_OSC8M));
			break;
		
		case SYSCLK_OSC160M:
			
			if((CPM->CPM_VCCGTRIMR & 0x03) != CPM_VREF_TRIM_110)
			{
				CPM_Vref_Trim(CPM_VREF_TRIM_110);
			}

			CPM->CPM_OCSR |= OSC160M_EN;
			while(OSC160M_STABLE != (CPM->CPM_OCSR & OSC160M_STABLE));
		
			CPM->CPM_CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM->CPM_CSWCFGR |= SYSCLK_SEL_OSC160M;
			while(CLKSEL_ST_OSC160M != (CPM->CPM_CSWCFGR & CLKSEL_ST_OSC160M));
			break;
		
		case SYSCLK_USBPHY240M:
			CPM->CPM_OCSR |= USB_PHY240M_EN;
			while(USB_PHY240M_STABLE != (CPM->CPM_OCSR & USB_PHY240M_STABLE));
		
			CPM->CPM_CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM->CPM_CSWCFGR |= SYSCLK_SEL_USBPHY240M;
			while(CLKSEL_ST_USBPHY240M != (CPM->CPM_CSWCFGR & CLKSEL_ST_USBPHY240M));
			break;
				
		case SYSCLK_OSCEXT:
			CPM->CPM_OCSR |= OSCEXT_EN;
			while(OSCEXT_STABLE != (CPM->CPM_OCSR & OSCEXT_STABLE));
		
			CPM->CPM_CSWCFGR &= ~(SYSCLK_SEL_MASK);
			CPM->CPM_CSWCFGR |= SYSCLK_SEL_OSCEXT;
			while(CLKSEL_ST_OSCEXT != (CPM->CPM_CSWCFGR & CLKSEL_ST_OSCEXT));
			break;
		
		default:
			break;
	}
	
	cpm_set_sysclk_div(div-1);
}
#endif

/*******************************************************************************
* Function Name  : ModuleClk_On
* Description    : ��ĳ��ʱ��ģ��
* Input          :  - module�� ʱ��ģ��
* Output         : None
* Return         : None
******************************************************************************/
void ModuleClk_On(UINT32 module)
{
	if (module <= 31)
	{
		CPM->CPM_MULTICGTCR |= (1<<module);
	}
	else if (module <= 63)
	{
		CPM->CPM_SYSCGTCR |= (1<<(module-32));
	}
	else if (module <= 95)
	{
		CPM->CPM_IPSCGTCR |= (1<<(module-64));
	}
	else if (module <= 127)
	{
		CPM->CPM_ARITHCGTCR |= (1<<(module-96));
	}
	else
	{
		CPM->CPM_IPSCGTCR |= (1<<(module-128));
	}
}

/*******************************************************************************
* Function Name  : ModuleClk_Off
* Description    : �ر�ĳ��ʱ��ģ��
* Input          :  - module�� ʱ��ģ��
* Output         : None
* Return         : None
******************************************************************************/
void ModuleClk_Off(UINT32 module)
{
	if (module <= 31)
	{
		CPM->CPM_MULTICGTCR &= ~(1<<module);
	}
	else if (module <= 63)
	{
		CPM->CPM_SYSCGTCR &= ~(1<<(module-32));
	}
	else if (module <= 95)
	{
		CPM->CPM_IPSCGTCR &= ~(1<<(module-64));
	}
	else if (module <= 127)
	{
		CPM->CPM_ARITHCGTCR &= ~(1<<(module-96));
	}
	else
	{
		CPM->CPM_IPSCGTCR &= ~(1<<(module-128));
	}
}


/*******************************************************************************
* Function Name  : get_usb_det_sta
* Description    : ��ȡUSB_DET��״̬
* Input          : None
*
* Output         : None
* Return         : - TRUE��           ��⵽��USB����
*                  - FALSE:    �����USB����
******************************************************************************/
BOOL get_usb_det_sta(void)
{
	if(CPM->CPM_PADWKINTCR&1)
	{
		CPM->CPM_PADWKINTCR |= 1;//wirte 1  to clear USBDET_STAT
		return TRUE;
	}

	return FALSE;

}

/*******************************************************************************
* Function Name  : Clock_Out_Select
* Description    : clock out�ܽ����ʱ��Ƶ�ʵ�ѡ��
*
* Input          : clk - SELECT_SYSTEM_CLK��ϵͳʱ��
*                        SELECT_ARITH_CLK ���㷨ʱ��
*                        SELECT_EFLASH_CLK��Eflashʱ��
*                        SELECT_RTC32K_CLK���ⲿRTC32Kʱ��
* Output         : None
* Return         : None
******************************************************************************/
void Clock_Out_Select(unsigned char clk)
{
	CPM->CPM_CSWCFGR &= ~(CLKOUT_SEL_MASK);
	CPM->CPM_CSWCFGR |= (clk << CLKOUT_SEL_SHIFT);
}

#if 0
/*******************************************************************************
* Function Name  : Get_Sys_Clock
* Description    : ���ص�ǰϵͳƵ�ʣ���λHz
*
* Input          : ��
* Output         : ϵͳƵ��
* Return         : None
******************************************************************************/
UINT32 Get_Sys_Clock(void)
{
	UINT8 clk_src;
	UINT32 clk_freq;
	
	clk_src = CPM->CPM_CSWCFGR & SYSCLK_SEL_MASK;
	
	switch((clk_src & 0x3))
	{
		case SYSCLK_OSC8M:
			clk_freq = 8*1000*1000;
			break;
		case SYSCLK_OSC160M:
#if SYS_CLK_TRIM_108M
			clk_freq = OSC108M;
#endif
#if SYS_CLK_TRIM_120M
			clk_freq = OSC120M;
#endif
#if SYS_CLK_TRIM_150M
			clk_freq = OSC150M;
#endif
#if SYS_CLK_TRIM_160M
			clk_freq = OSC160M;
#endif	
#if (!SYS_CLK_TRIM_160M&&!SYS_CLK_TRIM_150M&&!SYS_CLK_TRIM_120M&&!SYS_CLK_TRIM_108M)
		clk_freq = OSC160M;
#endif
		
			break;
		case SYSCLK_USBPHY240M:
			clk_freq = 240*1000*1000;
			break;
		case SYSCLK_OSCEXT:
			clk_freq = 12*1000*1000;
			break;
		default:
			clk_freq = 0;
			break;
	}
	
	return ((UINT32)(clk_freq / (((CPM->CPM_SCDIVR & SYS_DIV_MASK) >> SYS_DIV_SHIFT) + 1)));
}
#endif

/*******************************************************************************
* Function Name  : ARITH_Clk_Op
* Description    : ARITHģ��ʱ�Ӳ���
*
* Input          : -div_op��
*                      DIVIDER_DISABLE����ֹ��Ƶ
*                      UPDATA_DIVIDER�����·�Ƶϵ��
*                      GET_NOW_DIVIDER����ȡ��ǰ��Ƶϵ��
*                  -op_data:
*                      ��������
* Output         : ��ǰ��Ƶϵ��
* Return         : None
******************************************************************************/
UINT32 ARITH_Clk_Op(UINT32 div_op, UINT32 op_data)
{
	UINT32 return_val;
	
	return_val = 0;
	
	switch(div_op)
	{
		case DIVIDER_DISABLE:
			CPM->CPM_CDIVENR &= ~(ARITH_DIVEN);
			break;
		case UPDATA_DIVIDER:
			CPM->CPM_CDIVENR |= ARITH_DIVEN;
			CPM->CPM_PCDIVR1 &= ~(ARITH_DIV_MASK);
			CPM->CPM_PCDIVR1 |= (op_data << ARITH_DIV_SHIFT);
			CPM->CPM_CDIVUPDR |= PERDIV_UPD|SYSDIV_UPD;
			break;
		case GET_NOW_DIVIDER:
			return_val = ((CPM->CPM_PCDIVR1 & ARITH_DIV_MASK) >> ARITH_DIV_SHIFT);
			break;
		case GET_NOW_CLKGATE:
			return_val = (CPM->CPM_ARITHCGTCR);
			break;
		case CLKGATE_RESTORE:
			CPM->CPM_ARITHCGTCR = op_data;
			break;
		default:
			break;
	}
	
	return return_val;
}

#if 0
/*******************************************************************************
* Function Name  : IPS_Clk_Op
* Description    : IPSģ��ʱ�Ӳ���
*
* Input          : -div_op��
*                      DIVIDER_DISABLE����ֹ��Ƶ
*                      UPDATA_DIVIDER�����·�Ƶϵ��
*                      GET_NOW_DIVIDER����ȡ��ǰ��Ƶϵ��
*                  -op_data:
*                      ��������
* Output         : ��ǰ��Ƶϵ��
* Return         : None
******************************************************************************/
UINT32 IPS_Clk_Op(UINT32 div_op, UINT32 op_data)
{
	UINT32 return_val;
	
	return_val = 0;
	
	if(op_data == 0)
	{
		op_data = 1;
	}
	
	switch(div_op)
	{
		case DIVIDER_DISABLE:
			CPM->CPM_CDIVENR &= ~(IPS_DIVEN);
			break;
		case UPDATA_DIVIDER:
			CPM->CPM_CDIVENR |= IPS_DIVEN;
			CPM->CPM_PCDIVR1 &= ~(IPS_DIV_MASK);
			CPM->CPM_PCDIVR1 |= (op_data << IPS_DIV_SHIFT);
			CPM->CPM_CDIVUPDR = PERDIV_UPD;
			break;
		case GET_NOW_DIVIDER:
			return_val = ((CPM->CPM_PCDIVR1 & IPS_DIV_MASK) >> IPS_DIV_SHIFT);
			break;
		case GET_NOW_CLKGATE:
			return_val = (CPM->CPM_IPSCGTCR);
			break;
		case CLKGATE_RESTORE:
			CPM->CPM_IPSCGTCR = op_data;
			break;
		default:
			break;
	}
	
	return return_val;
}
#endif

/*******************************************************************************
* Function Name  : SDRAM_Clk_Op
* Description    : SDRAMģ��ʱ�Ӳ���
*
* Input          : -div_op��
*                      DIVIDER_DISABLE����ֹ��Ƶ
*                      UPDATA_DIVIDER�����·�Ƶϵ��
*                      GET_NOW_DIVIDER����ȡ��ǰ��Ƶϵ��
*                  -op_data:
*                      ��������
* Output         : ��ǰ��Ƶϵ��
* Return         : None
******************************************************************************/
UINT32 SDRAM_Clk_Op(UINT32 div_op, UINT32 op_data)
{
	UINT32 return_val;
	
	return_val = 0;
	
	switch(div_op)
	{
		case DIVIDER_DISABLE:
			CPM->CPM_CDIVENR &= ~(SDRAM_DIVEN);
			break;
		case UPDATA_DIVIDER:
			CPM->CPM_CDIVENR |= SDRAM_DIVEN;
			CPM->CPM_PCDIVR1 &= ~(SDRAM_DIV_MASK);
			CPM->CPM_PCDIVR1 |= (op_data << SDRAM_DIV_SHIFT);
			CPM->CPM_CDIVUPDR = PERDIV_UPD;
			break;
		case GET_NOW_DIVIDER:
			return_val = ((CPM->CPM_PCDIVR1 & SDRAM_DIV_MASK) >> SDRAM_DIV_SHIFT);
			break;
		default:
			break;
	}
	
	return return_val;
}

/*******************************************************************************
* Function Name  : USBC_PHY_Init
* Description    : ��ʼ��USBC PHYʱ��
*
* Input          : -OSC_Type:
*                      0:internal oscillator
*                      1:external oscillator
* Output         : None
* Return         : None
******************************************************************************/
void USBC_PHY_Init(UINT8 OSC_Type)
{
	if (1 == OSC_Type)
	{
		//Config 12MHz Clk
		CPM->CPM_OSCESTIMER = 0x3000;
		CPM->CPM_OCSR |= OSCEXT_EN;		//Enable 12MHz Clock
	}
	
	//Enable PHY Power Switch
	CPM->CPM_CHIPCFGR |= PWRCR_PHY_PSWEN_BIT;			//enable usbphy power switch

	//delay at least 10ms, sys clk is 120MHz, in release obj, one clock_cycle is 6 clock
	//so delay(x) = (6 * x / 120)us = 0.05x us, we use 11ms here.so 11ms = (6 * x / 120)=>x=220000
	delay(220000);	
	
	//Enable PHY Regulator
	CCM->PHYPA &= ~0xFF;     //Controlled by USBC instead of by manual

	//delay at least 10us
	delay(300);
	CPM->CPM_CHIPCFGR &= ~PWRCR_PHY_I_ISOEN_BIT;		//disable input usbphy isolation
	CPM->CPM_CHIPCFGR &= ~PWRCR_PHY_O_ISOEN_BIT;		//disable output usbphy isolation
	if(1 == OSC_Type)
	{
			 while((CPM->CPM_OCSR & OSCEXT_STABLE )!= OSCEXT_STABLE);         //wait for ext 12mhz to be stable
	}
	delay(220000);		//delay at least 10ms
	CPM->CPM_CHIPCFGR &= ~USBPHY_CFG_SRM;
	delay(22000);			//delay at least 1ms
	CPM->CPM_CHIPCFGR &= ~USBPHY_PLL_SRM;
	delay(22000);			//delay at least 1ms
	CPM->CPM_CHIPCFGR &= ~PWRCR_PHY_RSTMASK_BIT;		//diable usbphy reset mask, release the reset signal
	delay(22000);			//delay at least 1ms
}

